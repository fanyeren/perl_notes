#!/bin/bash
deploy_id_list="list"
for id in `cat $deploy_id_list`
do
	perl calc_time $id
done
