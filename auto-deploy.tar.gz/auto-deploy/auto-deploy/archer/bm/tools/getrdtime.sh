#!/bin/bash
for rd in `cat log/rd/* | awk '{print $1}' |sort -u`
do
	sum=0
	for time in `grep $rd log/rd/* | awk '{print $2}'`
	do
		sum=$(($sum + $time))
	done
done

