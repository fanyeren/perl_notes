#!/usr/bin/perl
my @a = qw (1 2 3 4);
sub get
{
	foreach (@_){
		print "$_\n";
	}
}
&get(@a);
