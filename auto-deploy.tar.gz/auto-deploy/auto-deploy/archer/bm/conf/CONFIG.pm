package CONFIG;
use Exporter;
use vars qw(@ISA @EXPORT @EXPORT_OK);
BEGIN {
    @ISA = qw(Exporter);
    @EXPORT = qw (    $DEBUG 
            %LOG_INFO 
            $opt_string 
            %OPT_LONG_VALUE
            %OPT_LONG_INFO
            %OPT_LONG_CHECK
            %PROMOTION_LONG_VALUE
            %PROMOTION_LONG_INFO
            %PROMOTION_LONG_CHECK
            %EXIT_CODE        
            %IDC_CONF
            %DELIVERY_CONF
            %OP_EMAIL_PHONE_MAP
            %ALARM_CONF
            %API_DESC
            %TOTAL_STATUS
            $TOTAL_PAUSE
            $TOTAL_CANCEL
            %LEVEL_STATUS
            %IDC_STATUS
            %ARCHER_CONTROL_ACTION
            %CORE_INSTATNCE_CONTROL_DESC
            %QA_CHECK_MAP
            $WORKSPACE
            $TRIGGER_OK
            $TRIGGER_FAIL
            $AUTO_DEPLOY_WORKING_DEPLOY_QUEUE
            $AUTO_DEPLOY_MUTEX_QUEUE
            $SCAN_IDC_INTERVAL
            $IDC_DEPLOY_OK
            $LEVEL_DEPLOY_FAIL
            $LEVEL_DEPLOY_OK
            $IDC_TRIGGER_FAIL
            $IDC_TRIGGER_OK
            $IDC_TRIGGER_ING
            $LEVEL_TRIGGER_FAIL
            $ARCHER_CONTROL_TOKEN
            $LEVEL_TRIGGER_OK
            $PAUSE_ARCHER
            $SUPER_MUTEX
            $TOTAL_PROGRESS_URL
            $PAUSE_TAG
            %CORE_INSTATNCE_CONTROL_INFO
            %CORE_INSTATNCE_CONTROL_VALUE
            $CHECK_OK
            $CHECK_FAIL
            $SCAN_CHECK_RESULT_TIME
            %IDC_DEPLOY_FAIL
            %GET_SHANGXIAN_INFO_LONG_VALUE
            %GET_SHANGXIAN_INFO_LONG_INFO
            

);
    use FindBin qw($Bin);
    use File::Basename;
    use Cwd 'abs_path';
}
$PID = $$;
$CURRENT_PATH = dirname(abs_path(__FILE__));
$BIN_PATH = "$Bin";
$PROGNAME = "archer_bm";
#DEBUG ����,1Ϊ��,����ʹ��
$DEBUG = 1;


### ����ȫ�ֿ���archer���ӽ��ȵ�token
### test
#$ARCHER_CONTROL_TOKEN = "2XHasb6YFcpSOWmMgTNe1czjx3WCbvKl";
### www
$ARCHER_CONTROL_TOKEN = "nIFjqDAti8usN9Be54M7h824c5zO1dgY";

### ������Ȳ鿴ҳ��
$TOTAL_PROGRESS_URL = "http://yf-psop-deploy01.yf01.baidu.com:8080/auto-deploy/index/index.php";

### hi�������Ϣ
$HI_MASTER = "yf-psop-deploy01.yf01.baidu.com";
$HI_PORT = "14440";

### seop_robot���������
%SEOP_ROBOT = (
    "hi_group" => {
        "xpp_tmp" => "1398674",
        "seop" => "1201044",
    },
    "hi_one" => {
        "xpphihihi" => "xpphihihi",
        "xpphihi" => "xpphihi",
    },
);

### �����ó���ʶ��ı���ļ�
$PAUSE_TAG = "$Bin/../yuan/pause.tag";

### ����������״̬
$CHECK_MUTEX_ING = "check_mutex_ing";
$CHECK_MUTEX_OK = "check_mutex_ok";

### ������״̬
$LEVEL_TRIGGER_FAIL = "trigger_fail";
$LEVEL_TRIGGER_OK = "trigger_ok";
$IDC_TRIGGER_FAIL = "trigger_fail";
$IDC_TRIGGER_OK = "trigger_ok";
$IDC_TRIGGER_ING = "trigger_ing";

### �����״̬
$IDC_DEPLOY_OK = "finish";
$LEVEL_DEPLOY_OK = "deploy_ok";
$LEVEL_DEPLOY_FAIL = "deploy_fail";
%IDC_DEPLOY_FAIL = (
    "cancel" => "cancel an idc",
    "transfer_fail" => "transfer fail",
);

### ����archer
$PAUSE_ARCHER = "stop";

### QA���id��map
%QA_CHECK_MAP = (
        "ps/se/view-ui/php-ui" => [
        "340",
        "335",
        "337"
    ],
        "ps/se/us" => [
        "204"
    ],
        "ps/se/disp" => [
        "207"
    ],
        "ps/se/attr/make" => [
        "207"
    ],
        "ps/se/nginx" => [
        "242"
    ],
        "ps/se/gss/kv" => [
        "238"
    ],
    "ps/se/fe/tpl/result" => [
        "137",
        "138"
    ],
    "ps/se/fe/tpl/www" => [
        "137",
        "138"
    ],
    "ps/se/fe/tpl/dev-aladdin" => [
        "137",
        "138"
    ],
    "ps/se/fe/tpl/dev-aladdin-pad" => [
        "137",
        "138"
    ],
);


#��־�������
#printStd Ϊ1 ��ʱ����־��ͬʱ��ӡ����׼���
#log_maxSize ��־�ļ��������,��λΪ KB
#log_minLine ��־�и��ʱ��������С��־����
%LOG_INFO = (
    "logProg" => "$PROGNAME",
    "bindir" => "$Bin",
    "logdir" => "$CURRENT_PATH/../log",
    "wf" => "$CURRENT_PATH/../log/$PROGNAME.log.wf",
    "nt" => "$CURRENT_PATH/../log/$PROGNAME.log",
    "log_debug" => $DEBUG,
    "printStd" => 1,
    "log_detail" => {
        "NOTICE" => 0,
        "DEBUG" => 1,
        "WARNNING" => 2,
        "FATAL" => 3,
    },
    "log_maxSize" => 200000000,
    "log_minLine" => 10000,
);

### promotion ��Ҫ��һЩ����
%PROMOTION_LONG_VALUE = (
    "action" => "",
    "module" => "",
    "deploy_id" => "",
    "op" => "",
);
%PROMOTION_LONG_INFO = (
    "action=s" => \$PROMOTION_LONG_VALUE{action},
    "module=s" => \$PROMOTION_LONG_VALUE{module},
    "deploy_id=s" => \$PROMOTION_LONG_VALUE{deploy_id},
    "op=s" => \$PROMOTION_LONG_VALUE{op},
);
%PROMOTION_LONG_CHECK = (
    "action" => {
        "value" => {
            "get_new_version" => {
                "function" => goto_get_new_version,
            },
            "auto_archer" => {
                "function" => goto_auto_archer,
            },
            "get_old_version" => {
                "function" => goto_get_old_version,
            },
        },
    },
    "module" => {
        "value" => {
            "ps/se/us" => {
                "delivery_path" => "https://svn.baidu.com/op/psop/trunk/se/ac-archer/tmp/",
                "workspace" => "/home/work/hudson/CI/hudson/workspace/auto_ps_se_us/",
            },
            "ps/se/disp" => {
                "delivery_path" => "https://svn.baidu.com.xxxxx",
                "workspace" => "/home/work/hudson/CI/hudson/workspace/auto_ps_se_disp/",
            },
        },
    },
    "op" => {
    },
);

#�����в����������
%OPT_LONG_VALUE = (
    "deploy_id" => "",
    "cm_conf" => "",
    "level_conf" => "",
    "action" => "",
    "module" => "",
    "alarm_conf" => "",
    "last_deploy_id" => "empty",
    "small_flow" => "",
);

%OPT_LONG_INFO = (
    "deploy_id=s" => \$OPT_LONG_VALUE{deploy_id},
    "cm_conf=s" =>  \$OPT_LONG_VALUE{cm_conf},
    "level_conf=s" =>  \$OPT_LONG_VALUE{level_conf},
    "action=s" =>  \$OPT_LONG_VALUE{action},
    "module=s" =>  \$OPT_LONG_VALUE{module},
    "alarm_conf=s" =>  \$OPT_LONG_VALUE{alarm_conf},
    "last_deploy_id=s" =>  \$OPT_LONG_VALUE{last_deploy_id},
    "small_flow" => \$OPT_LONG_VALUE{small_flow},
);

%CORE_INSTATNCE_CONTROL_VALUE = (
    "action" => "",
    "type" => "",
    "deploy_id" => "",
    "module" => "",
    "comment" => "",
    "noprintlogtostdout" => 1,
);

### ����archer���߽��ȵĲ���
%CORE_INSTATNCE_CONTROL_INFO = (
    "action=s" =>  \$CORE_INSTATNCE_CONTROL_VALUE{action},
    "type=s" =>  \$CORE_INSTATNCE_CONTROL_VALUE{type},
    "deploy_id=s" =>  \$CORE_INSTATNCE_CONTROL_VALUE{deploy_id},
    "module=s" =>  \$CORE_INSTATNCE_CONTROL_VALUE{module},
    "comment=s" =>  \$CORE_INSTATNCE_CONTROL_VALUE{comment},
    "noprintlogtostdout" =>  \$CORE_INSTATNCE_CONTROL_VALUE{noprintlogtostdout},
);
%OPT_LONG_CHECK = (
    "small_flow" => {
    },
    "deploy_id" => {
        "function" => "",
    },
    "module" => {
        "function" => "set_module_alias",
    },
    "action" => {
        "function" => "check_action",
        "action_list" => {
            'deploy' => '',
            'roll_back' => '',
        },
    },
    "level_conf"    => {
        "function" => "check_level_conf",
        "desc" => {
            "conf_type" => "json",
            "split_item" => "",
            "conf_key" => "level_conf",
        },
    },
    "cm_conf" => {
        "function" => "check_cm_conf",
        "desc" => {
            "conf_type" => "json",
            "split_item" => "",
            "conf_key" => "cm_conf",
        },
    },
    "alarm_conf" => {
        "function" => "check_alarm_conf",
        "desc" => {
            "conf_type" => "ini",
            "split_item" => "",
            "conf_key" => "alarm_conf",
        },
    },
);

%CORE_INSTATNCE_CONTROL_DESC = (
    "type" => {
        "all" => {
            "desc" => "process all the idcs that are working",
            "fuction" => "goto_type_of_all",
            "to_check_item" => [
            ],
        },
        "module" => {
            "desc" => "process the idcs of specific module", 
            "function" => "goto_type_of_module",
            "to_check_item" => [
                "module"
            ],
        },
        "deploy_id" => {
            "desc" => "process the idcs of specific deploy_id",
            "function" => "goto_type_of_deploy_id",
            "to_check_item" => [
                "deploy_id"
            ],
        },
    },
    "action" => {
        "pause" => {
            "desc" => "pause the idcs",
            "function" => "pause_all_the_deploy_id",
            "pre_function" => \&archer_bm::control_archer::build_pause_tag,
        },
        "recover" => {
            "desc" => "recover all the idcs",
            "function" => "recover_all_the_deploy_id",
            "pre_function" => \&archer_bm::control_archer::remove_pause_tag,
        },
        "get_host" => {
            "desc" => "get hostlist of all the idcs",
            "function" => "get_host_of_all_the_deploy_id",
            "pre_function" => \&archer_bm::control_archer::wait_for_host,
        },
         "get_deploy_list" => {
                        "desc" => "get all the deploy id",
                        "function" => "do_get_deploy_id",
                        "pre_function" => \&archer_bm::control_archer::get_deploy_id_list,
                }

    },
);




%ARCHER_CONTROL_ACTION = (
    "goon" => {
        "desc" => "��������",    
        "function" => "trigger_goon",
    },
    "nextgroup" => {
        "desc" => "��ʼ��һ������",
        "function" => "trigger_nextgroup",
    },
    "cancel" => {
        "desc" => "����",
        "function" => "trigger_cancel",
    },
    "redo" => {
        "desc" => "����",
        "function" => "trigger_redo",
    },
    "skip" => {
        "desc" => "����",
        "function" => "trigger_skip",
    },
    "stop" =>{
        "desc" => "��ͣ",
        "function" => "trigger_stop",
    },
);




### delivery.conf 
%DELIVERY_CONF = (
    "conf_name" => "delivery.conf",
    "desc" => {
        "conf_type" => "ini",
        "split_item" => "",
        "conf_key" => "delivery_conf",
    },
);

$TOTAL_PAUSE = "pause";
$TOTAL_CANCEL = "cancel";
### deploy_id ����Ľ���״̬
%TOTAL_STATUS = (
    "TOTAL_END_STATUS" => {
        "CANCEL" => {
            "desc" => "some idc was canceled",
        },
    },
);
$CHECK_OK = "check_ok";
$CHECK_FAIL = "check_fail";
### level���𴥷����ӳɹ�/ʧ�ܵĽ���״̬
%LEVEL_STATUS = (
    "LEVEL_TRIGGER_END" => {
        $LEVEL_TRIGGER_OK => {
            "desc" => "all idc triggered ok",
            "value" => 0,
        },
        $LEVEL_TRIGGER_FAIL => {
            "desc" => "some idc triggered fail,maybe param erro",
            "value" => 1,
        },
    },
    "LEVEL_DEPLOY_END" => {
        "deploy_ok" => {
            "desc" => "all idc end with 'finish'",
            "value" => 0,
        },
        "deploy_fail" => {
            "desc" => "some idc was canceled by outside api,and can't go on anymore",
            "value" => 1,
        },
    },
    "LEVEL_CHECK_END" => {
        $CHECK_OK => {
            "desc" => "all rd/qa/op checked ok",
            "value" => 0,
        },
        $CHECK_FAIL => {
            "desc" => "maybe timed out,maybe someone checked no",
            "value" => 1,
        },
    },
    "LEVEL_ALL" => {
    }
);



%IDC_STATUS = (
    "IDC_TRIGGER_END" => {
        $IDC_TRIGGER_OK => {
            "desc" => "this idc was triggered",
            "value" => 0,
        },
        $IDC_TRIGGER_FAIL => {
            "desc" => "this idc was triggered fail, maybe archer param erro",
            "value" => 1,
        },
        
    },
    "IDC_DEPLOY_END" => {
        "finish" => {
            "desc" => "this idc finished",
            "value" => 0,
        },
        "cancel" => {
            "desc" => "this idc is canceled",
            "value" => 1,
        },
        "transfer_fail" => {
            "desc" => "this idc transfer failed",
            "value" => 1,
        },
    },
    "IDC_DEPLOY_PAUSE" => {
        "launch_exception" => {
            "desc" => "something wrong happend to this idc",
            "value" => 1,
        },
        "pause" => {
            "desc" => "this idc paused during one group deploying",
            "value" => 1,
        },
        "su_pause" => {
            "desc" => "paused at the end of the group",
            "value" => 1,
        },
        
    },
    "IDC_ALL" => {
        "finish" => "this idc finished",
        "cancel" => "this idc is canceled",
        "editing" => "",
        "launching" => "",
        "cancel" => "",
        "launch_exception" => "",
        "pause" => "",
        "su_pause" => "",
        "finish" => "",
        "transfer_fail" => "",
        "transfering" => "",
    }
); 

### archer�ĸ���api�ӿ�
%API_DESC = (
    "archer" => {
        "api" => {
            "process_url" => {
                "str" => "http://noah.baidu.com/ci-web/index.php?r=ProcessView/QueryTask",
                "egs" => "http://noah.baidu.com/ci-web/index.php?r=ProcessView/QueryTask&listid=123456",
                "param" => {
                    "listid" => "",
                },
            },
            "status_url" => {
                "str" => "http://api.noah.baidu.com/ci-web/index.php?r=api/query/getList",
                "egs" => "http://api.noah.baidu.com/ci-web/index.php?r=api/query/getList&id=2268937",
                "param" => {
                    "id" => "",
                },
            },
            "control_url" => {
                "str" => "http://noah.baidu.com/ci-web/index.php?r=ProcessView/BatchControlTask",
                "egs" => "http://noah.baidu.com/ci-web/index.php?r=ProcessView/BatchControlTask&listid=123456&action=goon&token=www",
                "param" => {
                    "listid" => "",
                    "action" => {
                        "goon" => "��������",
                        "nextgroup" => "��ʼ��һ������",
                        "cancel" => "����",
                        "redo" => "����",
                        "skip" => "����",
                        "stop" => "��ͣ",
                    },
                    "token" => "",
                },
                
            },
        },
        
    },
    "dop" => {
        "api" => {
        },
    },
    "beehive" => {
        "api" => {
        },
    },
);

%OP_EMAIL_PHONE_MAP = (
    "xuepingping" => "18201676369",
);



### �˳�״̬��
%EXIT_CODE = (
    'SERVICE_DENY' => '2',
    'RESULT_BAD' => '1',
    'RESULT_OK' => '0',
);

%GET_SHANGXIAN_INFO_LONG_VALUE = (
        "icafe_table" => "",
        "base_info" => "",
        "level_conf" => "",
        "dest_dir" => "",
);
%GET_SHANGXIAN_INFO_LONG_INFO = (
        "icafe_table=s" => \$GET_SHANGXIAN_INFO_LONG_VALUE{icafe_table},
        "base_info=s" => \$GET_SHANGXIAN_INFO_LONG_VALUE{base_info},
        "level_conf=s" => \$GET_SHANGXIAN_INFO_LONG_VALUE{level_conf},
        "dest_dir=s" => \$GET_SHANGXIAN_INFO_LONG_VALUE{dest_dir},
);


### whileѭ������idc��ʱ��
$SCAN_IDC_INTERVAL = 3;
### �����������ʱ��
$SCAN_CHECK_RESULT_TIME = 3;
$AUTO_DEPLOY_WORKING_DEPLOY_QUEUE = "auto_deploy_working_deploy_queue";
### �������ʱ��Ҫʹ�õĸ����ļ�
$WORKSPACE = "$Bin/../data/";
### ������е�meta-id
$AUTO_DEPLOY_MUTEX_QUEUE = "auto_deploy_mutex_queue";
### super mutex
$SUPER_MUTEX = "super";


1;
