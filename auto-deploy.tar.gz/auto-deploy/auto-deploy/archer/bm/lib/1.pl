#!/usr/bin/perl -w 
use POSIX;
my $start_time = 1000;
my $end_time = 500;
print "end_time = $end_time \n";
#my $det_time =  $end_time - $start_time;
my $det_time = sprintf("%.1f", 1000/60);
print "det_time = $det_time \n";
