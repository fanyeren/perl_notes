#!/usr/bin/perl -w 
use JSON::XS
my $token = "nNRZJS8VyC4EH6aQP4goK61eI9qTcfhw";
my %job_des = (
	"name" => "ui_c7_hongbao",
	"node_id" => "BAIDU_PS_www_online",
	"token" => "nNRZJS8VyC4EH6aQP4goK61eI9qTcfhw",
	"account" => "work",
	"dist_group" => "",
	"dist_hook" => "",
	"dist_done_hook" => "",
	"dist_dest" => "BAIDU_PS_www_online_ui_t11-fenji0-ui.www.cq",
	"dist_pre_cmd" => "",
	"dist_done_hook" => "",
	"dist_check" => "",
	"success_return" => "0",
	"check_cmd" => "/home/work/search/ui/bin/ui_control reload -c 7",
);
