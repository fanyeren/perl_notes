package archer_bm::promotion_bm;
BEGIN
{
	use Exporter();
	use vars qw($VERSION @ISA @EXPORT);
	use Data::Dumper;
	use File::Basename;
	use Fcntl qw(:flock);
	use FindBin qw($Bin);
	use lib "$Bin/../lib";
	use lib "$Bin/../conf";
	use lib "$Bin/../tools";
	use lib "$Bin/../../../public/alarm_api/perl/";
	use lib "$Bin/../../public/lib";

	use Time::HiRes qw(time);
#	use Smart::Comments;
	use CONFIG;
	use JSON::XS;
	use POSIX;
#	use archer_bm::Common;
	use Common;
	use Alarm;
	use strict;
	use warnings;
	use Switch;
	@ISA = qw(Exporter);
	@EXPORT = qw (
		);
}


sub new 
{
	my ($type,$logit,$param) = @_;
	$this->{logit} = $logit;
	$this->{param} = $param;
	bless $this;
	$this->{logit}->{conf}->{printStd} = 0;
	return $this;
}
sub check_if_zk_table_ok
{
	my ($this) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	$return_detail = &get_zk_attr_info_api($AUTO_DEPLOY_WORKING_DEPLOY_QUEUE,'deploy_id');
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}
	$return_detail = &get_zk_attr_info_api($AUTO_DEPLOY_WORKING_DEPLOY_QUEUE,'module');
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}else{
	        $my_return{value} = 0;
	        $my_return{desc} = "$AUTO_DEPLOY_WORKING_DEPLOY_QUEUE is ok";
	        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	        return \%my_return;
	}
	
	
}
sub check_param_before_goto_work
{
        my ($this,$input_param_list) = @_;
        my $return_detail;
        my %my_return; 
	my @to_check_item;
	my $function;
	my $param_str;
	foreach (@_){

		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	#print Dumper($this);
    	### �ȼ����Ҫ����Ĳ������Ƿ񶼸�ֵ��
        @to_check_item = keys %PROMOTION_LONG_CHECK;
        $return_detail = check_is_item_in_hash_api(\@to_check_item, $input_param_list);
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "param check fail: $return_detail->{desc}";
                $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
        }
	
	### $input_param_list

	###  ���action�Ƿ�������ȷ,����ֵ�Ƿ����������б���
	my $action = $this->{param}->{action};
	### %PROMOTION_LONG_CHECK
	my @action_list = keys %{$PROMOTION_LONG_CHECK{action}->{value}};
	### @action_list
	if(!exists $PROMOTION_LONG_CHECK{action}->{value}->{$action}){
		$my_return{value} = 1;
		$my_return{desc} = "action can only be @action_list";
                $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}
	### ��� module �����Ƿ���ȷ
	my $module = $this->{param}->{module};
	my @module_list = keys %{$PROMOTION_LONG_CHECK{module}->{value}};
	if(!exists $PROMOTION_LONG_CHECK{module}->{value}->{$module}){
		$my_return{value} = 1;
		$my_return{desc} = "module can only be @module_list";
                $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}

	### �ȼ�����op�Ƿ����
	my $op = $this->{param}->{op};
	if(!exists $OP_EMAIL_PHONE_MAP{$op}){
		$my_return{desc} = "no permission for op:$op ";
		$my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}
	### ���˾Ͳ�����������

        $my_return{value} = 0;
        $my_return{desc} = "param check ok";
        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
        return \%my_return;

}
sub goto_work
{
	my ($this) = @_;
	my $return_detail;
	my %my_return;
	my $param_str;
	foreach (@_){

		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}

	my $action = $this->{param}->{action};

	### �ȶԸ���typeֵ��function���в���
	my $function = $PROMOTION_LONG_CHECK{action}->{value}->{$action}->{function};
	### $function
	if(defined($function) && "$function" ne ""){
		$return_detail = &$function;
		### $return_detail
        	if("$return_detail->{value}" ne "0"){
        	        $my_return{value} = 1;
        	        $my_return{desc} = "[fail] $action,$return_detail->{desc}";
        	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
        	        return \%my_return;
        	}
	}

        $my_return{value} = 0;
        $my_return{desc} = "$return_detail->{desc}";
        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	return \%my_return;

}
sub goto_get_new_version
{
	my ($this) = @_;
	my $return_detail;
	my %my_return;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	$return_detail = $this->download_delivery_conf();
	if("$return_detail->{value}" ne "0"){
		$my_return{desc} = $return_detail->{desc};
		$my_return{value} = 1;
       		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}

	$return_detail = $this->get_new_delivery_alarm_conf();
	if("$return_detail->{value}" ne "0"){
		$my_return{desc} = $return_detail->{desc};
		$my_return{value} = 1;
       		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}
	$my_return{desc} = "$return_detail->{desc}";
	$my_return{value} = 0;
       	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	return \%my_return;
}
sub get_new_delivery_alarm_conf
{
	my ($this) = @_;
	my $return_detail;
	my %my_return;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my @rd_email_list;
	my @rd_phone_list;
	my @tmp_array;
	my $op = $this->{param}->{op};
	my $op_email = "$op" . "@" . "baidu.com";
	my $op_phone = $OP_EMAIL_PHONE_MAP{$op};
	my $rd_email = $this->{conf}->{delivery_conf}->{v}->{DEFAULT}->{email};
	my $rd_phone = $this->{conf}->{delivery_conf}->{v}->{DEFAULT}->{telephone};

	@tmp_array = split(/,/,$rd_email);
	push @rd_email_list,@tmp_array;

	@tmp_array = split(/,/,$rd_phone);
	push @rd_phone_list,@tmp_array;


	my $module = $this->{param}->{module};
	my $version = $this->{conf}->{delivery_conf}->{v}->{DEFAULT}->{rdversion};
	my $workspace = $PROMOTION_LONG_CHECK{module}->{value}->{$module}->{workspace};

	### ����������alarm.conf
        my $ALARM_CONF;
	my $alarm_conf = "$workspace/alarm.conf";
	`rm $alarm_conf >/dev/null`;
	### $alarm_conf
        open $ALARM_CONF,'>>',$alarm_conf;
	print $ALARM_CONF "[DEFAULT]\n";
	### prepare rd_email
	print $ALARM_CONF "rd_email=<<EOT\n";	
	foreach (@rd_email_list){
		print $ALARM_CONF "$_\n";
	}
	print $ALARM_CONF "EOT\n";	
	### prepare rd_phone
	print $ALARM_CONF "rd_phone=<<EOT\n";	
	foreach (@rd_phone_list){
		print $ALARM_CONF "$_\n";
	}
	print $ALARM_CONF "EOT\n";	
	### prepare op_email
	print $ALARM_CONF "op_email=<<EOT\n";	
	print $ALARM_CONF "$op_email\n";
	print $ALARM_CONF "EOT\n";	
	### prepare op_phone
	print $ALARM_CONF "op_phone=<<EOT\n";	
	print $ALARM_CONF "$op_phone\n";
	print $ALARM_CONF "EOT\n";	
	close $ALARM_CONF;


	### ����������delivery.conf
	my $new_delivery_conf = "$workspace/delivery.conf";
	`rm $new_delivery_conf 2>/dev/null`;
	### $new_delivery_conf
	$module = $this->{conf}->{delivery_conf}->{v}->{DEFAULT}->{rdmodule};
	$version = $this->{conf}->{delivery_conf}->{v}->{DEFAULT}->{rdversion};
	my $action = $this->{conf}->{delivery_conf}->{v}->{DEFAULT}->{action};
	my $buildplatform = $this->{conf}->{delivery_conf}->{v}->{DEFAULT}->{buildplatform};
	my $deploy_path = $this->{conf}->{delivery_conf}->{v}->{DEFAULT}->{deploy_path};
	my $ftp_or_scm = $this->{conf}->{delivery_conf}->{v}->{DEFAULT}->{ftp_or_scm};
	my $ftp_path = $this->{conf}->{delivery_conf}->{v}->{DEFAULT}->{ftp_path};
	if(!defined($deploy_path)){ $deploy_path = "";}
	if(!defined($action)){ $action = "";}
	if(!defined($buildplatform)){ $buildplatform = "";}
	if(!defined($ftp_or_scm)){ $ftp_or_scm = "scm";}
	if(!defined($ftp_path)){ $ftp_path = "";}

        open $DELIVERY_CONF,'>>',$new_delivery_conf;
	print $DELIVERY_CONF "[DEFAULT]\n";
	print $DELIVERY_CONF "module=$module\n";
	print $DELIVERY_CONF "version=$version\n";
	print $DELIVERY_CONF "action=$action\n";
	print $DELIVERY_CONF "buildplatform=$buildplatform\n";
	print $DELIVERY_CONF "deploy_path=$deploy_path\n";
	print $DELIVERY_CONF "ftp_or_scm=$ftp_or_scm\n";
	print $DELIVERY_CONF "ftp_path=$ftp_path\n";
	close $DELIVERY_CONF;
	
	print "version=$version,please check if ok\n";
	$my_return{desc} = "version=$version,please check if ok";
	$my_return{value} = 0;
       	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	return \%my_return;


}
sub download_delivery_conf
{
	my ($this) = @_;
	my $return_detail;
	my %my_return;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $module = $this->{param}->{module};
	my $delivery_path = $PROMOTION_LONG_CHECK{module}->{value}->{$module}->{delivery_path};
	my $workspace = $PROMOTION_LONG_CHECK{module}->{value}->{$module}->{workspace};
	### �������ļ�
	$return_detail = download_svn_file_api($delivery_path,$workspace);
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "svn co fail: $return_detail->{desc}";
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
	}
	### �ټ���ļ��Ƿ����
	$return_detail = check_file_exists_api("$workspace/delivery.conf");
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "no such file $workspace/delivery.conf";
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
	}

	### ����delivery.conf�ļ�
	my $conf_detail = &load_conf_ini_api("$workspace/delivery.conf");	
	$this->{conf}->{delivery_conf} = $conf_detail;

        $my_return{value} = 0;
        $my_return{desc} = "delivery.conf download ok";
	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
        return \%my_return;

}
sub goto_auto_archer
{
	my ($this) = @_;
	my $return_detail;
	my %my_return;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $param_list = "/home/work/auto-deploy/auto_deploy_bm/bin --action deploy --module_name $module_name --delivery_conf $delivery_conf --level_control $level_conf --alarm_conf $alarm_conf";
	$return_detail = call_auto_deploy_bm($action,$module_name,$delivery_conf,$level_conf,$alarm_conf);
}
sub goto_get_old_version
{
	### ��ȡ��ʷ�汾����ʷ��deploy_id���ڻع�ʹ��
}
sub goto_auto_archer_rollback
{
}
sub xpp
{
	### 13yy
	my ($this) = @_;
	my $return_detail;
	my %my_return;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	if("$return_detail->{value}" ne "0"){
		$my_return{value} = 1;
		$my_return{desc} = $return_detail->{desc};
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{
		$my_return{value} = 0;
		$my_return{desc} = "pause ok : task_id=$task";
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
		return \%my_return;
	}
}


1;
