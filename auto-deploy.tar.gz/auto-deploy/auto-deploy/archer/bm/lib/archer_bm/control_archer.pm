package archer_bm::control_archer;
BEGIN
{
	use Exporter();
	use vars qw($VERSION @ISA @EXPORT);
	use Data::Dumper;
	use File::Basename;
	use Fcntl qw(:flock);
	use FindBin qw($Bin);
	use lib "$Bin/../lib";
	use lib "$Bin/../conf";
	use lib "$Bin/../tools";
	use lib "$Bin/../../../public/alarm_api/perl/";
	use lib "$Bin/../../public/lib";

	use Time::HiRes qw(time);
	#use Smart::Comments;
	use CONFIG;
	use JSON::XS;
	use POSIX;
#	use archer_bm::Common;
	use Common;
	use Alarm;
	use strict;
	use warnings;
	use Switch;
	@ISA = qw(Exporter);
	@EXPORT = qw (
		$ARCHER_WORKSPACE
		);
}

$ARCHER_WORKSPACE="$Bin/../data/";

sub new 
{
	my ($type,$logit,$param) = @_;
	$this->{logit} = $logit;
	$this->{param} = $param;
	bless $this;
	return $this;
}

sub check_if_zk_table_ok
{
	my ($this) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}

	$return_detail = &get_zk_attr_info_api($AUTO_DEPLOY_WORKING_DEPLOY_QUEUE,'deploy_id');
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}

	$return_detail = &get_zk_attr_info_api($AUTO_DEPLOY_WORKING_DEPLOY_QUEUE,'module');
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	}else{
	        $my_return{value} = 0;
	        $my_return{desc} = "$AUTO_DEPLOY_WORKING_DEPLOY_QUEUE is ok";
	        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	}	
	return \%my_return;	
}

sub check_param_before_goto_work
{
    my ($this,$input_param_list) = @_;
    my $return_detail;
    my %my_return; 
	my @to_check_item;
	my $function;
	my $param_str;

	### �ȼ����Ҫ����Ĳ������Ƿ񶼸�ֵ��
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}

	@to_check_item = keys %CORE_INSTATNCE_CONTROL_DESC;
	$return_detail = check_is_item_in_hash_api(\@to_check_item, $input_param_list);
	if("$return_detail->{value}" ne "0"){
		$my_return{value} = 1;
		$my_return{desc} = "param check fail: $return_detail->{desc}";
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}
	
	### $input_param_list

	###  ���action�Ƿ�������ȷ,����ֵ�Ƿ����������б���
	my $action = $this->{param}->{action};
	my @action_list = keys %{$CORE_INSTATNCE_CONTROL_DESC{action}};
	if(!exists $CORE_INSTATNCE_CONTROL_DESC{action}->{$action}){
		$my_return{value} = 1;
		$my_return{desc} = "action can only be @action_list";
        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}
	###  ���type�����Ƿ���ȷ
	my $type = $this->{param}->{type};
	my @type_list = keys %{$CORE_INSTATNCE_CONTROL_DESC{type}};
	if(!exists $CORE_INSTATNCE_CONTROL_DESC{type}->{$type}){
		$my_return{value} = 1;
		$my_return{desc} = "type can only be @type_list";
        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}
	### ��type��ֵ������ȷ������£���Ҫ������ֵ��Ӧ����ֵ�Ƿ���ȷ������--action module ��Ҫ�� --module ps/se/ac/make һ�����
	@to_check_item = @{$CORE_INSTATNCE_CONTROL_DESC{type}->{$type}->{to_check_item}};
	$return_detail = check_is_item_in_hash_api(\@to_check_item, $input_param_list);

	if("$return_detail->{value}" ne "0"){
			$my_return{value} = 1;
			$my_return{desc} = "param check fail: $return_detail->{desc}";
			$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
	}
	$my_return{value} = 0;
	$my_return{desc} = "param check ok";
	#$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	return \%my_return;

}

sub goto_work
{
	my ($this) = @_;
	my $return_detail;
	my %my_return;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}

	my $type = $this->{param}->{type};
	### �ȶԸ���typeֵ��function���в���
	my $function = $CORE_INSTATNCE_CONTROL_DESC{type}->{$type}->{function};
	#if(defined($function) && "$function" ne "" && lc(ref($function)) eq "code"){
	if(defined($function) && "$function" ne ""){
		$return_detail = &$function;
		if("$return_detail->{value}" ne "0"){
			$my_return{value} = 1;
			$my_return{desc} = "[fail] $action,$return_detail->{desc}";
			$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
	}

	### �Ȼ�ȡ��Ҫִ��action��deploy_id
	$return_detail = $this->get_deploy_id_list();
	if("$return_detail->{value}" ne "0"){
		$my_return{value} = 1;
		$my_return{desc} = "fail to get deploy_id list ";
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}	
	
	### �������е�deploy_id
	$return_detail = $this->process_all_the_deploy_id();
	if("$return_detail->{value}" ne "0"){
		$my_return{value} = 1;
		$my_return{desc} = "fail to process the deploy_id: $return_detail->{desc}";
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}
	$my_return{value} = 0;
	$my_return{desc} = "$return_detail->{desc}";
	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);

	return \%my_return;

}

sub goto_type_of_all
{
	my ($this) = @_;
	my $return_detail;
	my %my_return;
	my $action = $this->{param}->{action};
	my $function = $CORE_INSTATNCE_CONTROL_DESC{action}->{$action}->{function};
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	
	$return_detail = $this->register_super_token_into_mutex_table();
	if("$return_detail->{value}" ne "0"){
		$my_return{desc} = "$return_detail->{desc}";
		$my_return{value} = 1;
        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	}else{
		$my_return{desc} = "register_super ok";
		$my_return{value} = 0;
        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	}

	return \%my_return;
}

sub register_super_token_into_mutex_table
{
	my ($this) = @_;
	my $return_detail;
	my %my_return;
	my $param_str;

	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}

	my $comment = "reason:$this->{param}->{comment}";
	$return_detail = add_zk_info_api($AUTO_DEPLOY_MUTEX_QUEUE,$SUPER_MUTEX,"$comment");
	if("$return_detail->{value}" ne "0"){
		$my_return{value} = 1;
		$my_return{desc} = $return_detail->{desc};
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	}else{
		$my_return{value} = 0;
		$my_return{desc} = "register super into mutex queue ok";
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	}
	
	return \%my_return;
}

sub unregister_super_token_from_mutex_table
{
        my ($this) = @_;
        my $return_detail;
        my %my_return;
        my $param_str;
        foreach (@_){
                if((!defined($_)) || "$_" eq ""){
                        $my_return{desc} = "input params erro,now params are :$param_str";
                        $my_return{value} = 1;
                        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                        return \%my_return;
                }
                $param_str .= "$_,";
        }
        $return_detail = del_meta_id_and_key($AUTO_DEPLOY_MUTEX_QUEUE,$SUPER_MUTEX);
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = $return_detail->{desc};
                $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
        }else{
                $my_return{value} = 0;
                $my_return{desc} = "register super into mutex queue ok";
                $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
        }
}

sub goto_type_of_module
{
	my ($this) = @_;
	my $return_detail;
	my %my_return;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}

	### �ٰ�ģ�鼶��Ļ���tokenд������ȥ
	$return_detail = $this->register_module_token_into_mutex_table();
	if("$return_detail->{value}" ne "0"){
		$my_return{desc} = "$return_detail->{desc}";
		$my_return{value} = 1;
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	}else{  
		$my_return{desc} = "register module mutex into zk ok";
		$my_return{value} = 0;
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	}
	
	return \%my_return;
}

sub register_module_token_into_mutex_table
{
	my ($this) = @_;
	my $return_detail;
	my %my_return;
	my $param_str;
	foreach (@_){
			if((!defined($_)) || "$_" eq ""){
					$my_return{desc} = "input params erro,now params are :$param_str";
					$my_return{value} = 1;
					$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
					return \%my_return;
			}
			$param_str .= "$_,";
	}
	my $module = $this->{param}->{module};
	my @tmp_array = split(/\//,$module);
	my $module_token = join(':',@tmp_array);
	my $comment = "reason:$this->{param}->{comment}";
	$return_detail = add_zk_info_api($AUTO_DEPLOY_MUTEX_QUEUE,$module_token,"$comment");
	if("$return_detail->{value}" ne "0"){
		$my_return{value} = 1;
		$my_return{desc} = "$return_detail->{desc}";
                $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{
		$my_return{value} = 0;
		$my_return{desc} = "register module_token=$module_token into zk";
                $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
		return \%my_return;
	}

}
sub goto_type_of_deploy_id
{
	my ($this) = @_;
	my $return_detail;
	my %my_return;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	$my_return{value} = 0;
	$my_return{desc} = "do nothing";
    $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);

	return \%my_return;
}

sub get_deploy_id_list
{
	my ($this) = @_;
	my $return_detail;
	my %my_return;
	my $param_str;
	#foreach (@_){
	#	if((!defined($_)) || "$_" eq ""){
	#		$my_return{desc} = "input params erro,now params are :$param_str";
	#		$my_return{value} = 1;
        #		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	#		return \%my_return;
	#	}
	#	$param_str .= "$_,";
	#}
	
	### �ȴ����ڹ����Ķ�������ȡ�����е���Ϣ,�ٸ���type��ֵ��������ȡ����
	$return_detail = get_zk_all_info_api($AUTO_DEPLOY_WORKING_DEPLOY_QUEUE);
	my $working_deploy_queue_info;

	### $return_detail
	if("$return_detail->{value}" ne "0"){
		$my_return{value} = 1;
		$my_return{desc} = "fail to get info of $AUTO_DEPLOY_WORKING_DEPLOY_QUEUE from zk";
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{
		my $json_obj = new JSON::XS;
		$working_deploy_queue_info = $json_obj->decode($return_detail->{desc});
		
		if(!defined($working_deploy_queue_info) || "$working_deploy_queue_info" eq ""){
			$my_return{value} = 1;
			$my_return{desc} = "empty content in $AUTO_DEPLOY_WORKING_DEPLOY_QUEUE";
			$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}

		$my_return{desc} = "ok, got $AUTO_DEPLOY_WORKING_DEPLOY_QUEUE from zk";
		#$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	}

	my $type = $this->{param}->{type};
	my @deploy_id_list;
	my $deploy_id;
	if("$type" eq "all"){
		@deploy_id_list = keys %{$working_deploy_queue_info->{deploy_id}};
	}elsif("$type" eq "module"){
		my $module = $this->{param}->{module};
		my @tmp_array = split(/\//,$module);
		my $module_token = join(':',@tmp_array);
		### $module_token
		print Dumper($working_deploy_queue_info->{module});
		$deploy_id = $working_deploy_queue_info->{module}->{$module_token};
		push @deploy_id_list,$deploy_id;
	}elsif("$type" eq "deploy_id"){
		$deploy_id = $this->{param}->{deploy_id};
		push @deploy_id_list,$deploy_id;
	}

	### ���õ���deploy_id д�뵽�ڴ���
	### @deploy_id_list
	$this->{data}->{deploy_id} = \@deploy_id_list;
	$my_return{desc} = "ok, got deploy_id_list";
    	#$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	my $ids = join ',', @deploy_id_list; 
	$my_return{desc} = "{\"desc\":\"$ids\", \"value\":0}";
	$my_return{value} = 0;
	return \%my_return;
}

sub process_all_the_deploy_id
{
	my ($this) = @_;
	my $return_detail;
	my %my_return;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
			$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $action = $this->{param}->{action};
	my $function = $CORE_INSTATNCE_CONTROL_DESC{action}->{$action}->{function};
	$return_detail = &$function;
	### $return_detail
	if("$return_detail->{value}" ne "0"){
               $my_return{desc} = "failed $action,$function,$return_detail->{desc}";
               $my_return{value} = 1;
               $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
               return \%my_return;
	}else{
               $my_return{desc} = "$return_detail->{desc}";
               $my_return{value} = 0;
               $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
               return \%my_return;
	}
}

sub pause_all_the_deploy_id
{
	my ($this) = @_;
	my $return_detail;
	my %my_return;
	my $param_str;

	#foreach (@_){
	#	if((!defined($_)) || "$_" eq ""){
	#		$my_return{desc} = "input params erro,now params are :$param_str";
	#		$my_return{value} = 1;
	#		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	#		return \%my_return;
	#	}
	#	$param_str .= "$_,";
	#}

	my @deploy_id_list = @{$this->{data}->{deploy_id}};
	my $not_done_count = 0;
	foreach (@deploy_id_list){
		$return_detail = $this->pause_this_deploy_id($_);
		if("$return_detail->{value}" ne "0"){
			$not_done_count++;
			$my_return{desc} .= "$_ ";
		}
	}

	if($not_done_count > 0){
		$total_if_done = "no";
		$my_return{value} = 1;
		$my_return{desc} = "these deploy_id not done:[ $my_return{desc} ]";
        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	}else{
		$total_if_done = "yes";
		$my_return{desc} = "all deploy_id done";
		$my_return{value} = 0;
        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	}

	return \%my_return;
}

sub pause_this_deploy_id
{
	my ($this,$deploy_id) = @_;
	my $return_detail;
	my %my_return;
	my $param_str;

	#foreach (@_){
	#	if((!defined($_)) || "$_" eq ""){
	#		$my_return{desc} = "input params erro,now params are :$param_str";
	#		$my_return{value} = 1;
        #	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	#		return \%my_return;
	#	}
	#	$param_str .= "$_,";
	#}

    my $json_obj = new JSON::XS;
	my $deploy_id_status_table;
	$return_detail = get_zk_all_info_api($deploy_id);
	if("$return_detail->{value}" ne "0"){
		$my_return{desc} = "$return_detail->{desc}";
		$my_return{value} = 1;
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{
		$deploy_id_status_table = $json_obj->decode($return_detail->{desc});
	}

	my @task_id_list = keys %{$deploy_id_status_table->{all_task_id}};
	my $deploy_method = $deploy_id_status_table->{deploy_method};
	# XXX
	if (!defined($deploy_method)) {
		$deploy_method = "archer";
	}
	
	my $action = $this->{param}->{action};
	my $fail_action_count = 0;
	my $task_id;
	foreach $task_id (@task_id_list){
		$return_detail = $this->do_action_to_this_task_id($task_id,$deploy_method);
		if("$return_detail->{value}" ne "0"){
			$my_return{desc} .= "$task_id ";
			$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			$fail_action_count++;
		}
	}

	if($fail_action_count > 0){
		$my_return{value} = 1;
		$my_return{desc} = "these task_id not done: [ $my_return{desc} ]";
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);	
	}else{
		$my_return{value} = 0;
		$my_return{desc} = "all task_id done";
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	}

	return \%my_return;
}

sub do_action_to_this_deploy_id
{
	my ($this,$deploy_id) = @_;
	my $return_detail;
	my %my_return;
	my $param_str;

	#foreach (@_){
	#	if((!defined($_)) || "$_" eq ""){
	#		$my_return{desc} = "input params erro,now params are :$param_str";
	#		$my_return{value} = 1;
        #	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	#		return \%my_return;
	#	}
	#	$param_str .= "$_,";
	#}

    my $json_obj = new JSON::XS;
	my $deploy_id_status_table;
	$return_detail = get_zk_all_info_api($deploy_id);
	if("$return_detail->{value}" ne "0"){
		$my_return{desc} = "$return_detail->{desc}";
		$my_return{value} = 1;
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{
		$deploy_id_status_table = $json_obj->decode($return_detail->{desc});
	}

	my @task_id_list = keys %{$deploy_id_status_table->{all_task_id}};
	my $deploy_method = $deploy_id_status_table->{deploy_method};
	# XXX
	if (!defined($deploy_method)) {
		$deploy_method = "archer";
	}
	
	my $action = $this->{param}->{action};
	my $fail_action_count = 0;
	my $task_id;
	foreach $task_id (@task_id_list){
		$return_detail = $this->do_action_to_this_task_id($task_id,$deploy_method);
		if("$return_detail->{value}" ne "0"){
			$my_return{desc} .= "$task_id ";
			$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			$fail_action_count++;
		}
	}

	if($fail_action_count > 0){
		$my_return{value} = 1;
		$my_return{desc} = "these task_id not done: [ $my_return{desc} ]";
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);	
	}else{
		$my_return{value} = 0;
		$my_return{desc} = "all task_id done";
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	}

	return \%my_return;
}

sub do_action_to_this_task_id
{
	my ($this,$task_id,$deploy_method) = @_;
	my $return_detail;
	my %my_return;
	my $param_str;
	#foreach (@_){
	#	if((!defined($_)) || "$_" eq ""){
	#		$my_return{desc} = "input params erro,now params are :$param_str";
	#		$my_return{value} = 1;
        #	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	#		return \%my_return;
	#	}
	#	$param_str .= "$_,";
	#}

	my $action = $this->{param}->{action};
	my $actstr = "";

	### $deploy_method
	if("$deploy_method" eq "archer"){
		$actstr = "$action";
		### �����archer�Ĳ���ʽ
		if("$action" eq "pause"){
			### ���actionҪ������ͣ
			$return_detail = $this->pause_archer_task($task_id);
		} elsif ("$action" eq "recover"){
			### ���actionҪ���ǻָ�
			$return_detail = $this->recover_archer_task($task_id);
		}

		if("$return_detail->{value}" ne "0"){
			$my_return{value} = 1;
			$my_return{desc} = $return_detail->{desc};
			$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		}else{
			$my_return{value} = 0;
			$my_return{desc} = "$actstr ok : task_id=$task_id";
			$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
		}
	} else {
			$my_return{value} = 1;
			$my_return{desc} = "not support deploy method $deploy_method yet.";
			$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);	
	}

	return \%my_return;
}

sub pause_archer_task
{
	my ($this,$archer_id) = @_;
	my $return_detail;
	my %my_return;
	my $param_str;

	#foreach (@_){
	#	if((!defined($_)) || "$_" eq ""){
	#		$my_return{desc} = "input params erro,now params are :$param_str";
	#		$my_return{value} = 1;
        #	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	#		return \%my_return;
	#	}
	#	$param_str .= "$_,";
	#}

	### $PAUSE_ARCHER
	$return_detail = control_archer_api($PAUSE_ARCHER,$archer_id,$ARCHER_CONTROL_TOKEN);
	if("$return_detail->{value}" ne "0"){
		$my_return{value} = 1;
		$my_return{desc} = $return_detail->{desc};
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	}else{
		$my_return{value} = 0;
		$my_return{desc} = "successfully paused $archer_id";
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	}

	return \%my_return;
}

sub build_pause_tag
{
	my ($this) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $argv_list = $this->{argv_list};
	### $argv_list
	### $PAUSE_TAG
	my $cmd = "echo $argv_list > $PAUSE_TAG";
	$return_detail = &run_cmd_api("$cmd",1);
	if("$return_detail->{value}" ne "0"){
		$my_return{value} = 1;
		$my_return{desc} = "build pause tag fail: $return_detail->{desc}";
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{  
		$my_return{value} = 0;
		$my_return{desc} = "build pause tag ok";
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	}
	
	if ($this->{param}->{type} eq "deploy_id" and $this->{param}->{deploy_id} =~ /,/) {
		my @deploy_ids = split(/,/, $this->{param}->{deploy_id});
		print "@deploy_ids\n";
		$this->{data}->{deploy_id} = \@deploy_id_list;	
	} else {
		### �Ȼ�ȡ��Ҫִ��action��deploy_id
        	$return_detail = $this->get_deploy_id_list();
        	if("$return_detail->{value}" ne "0"){
			$my_return{value} = 1;
			$my_return{desc} = "fail to get deploy_id list ";
			$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
	}
	$return_detail = $this->pause_all_the_deploy_id();

	if("$return_detail->{value}" ne "0"){
		$my_return{value} = 1;
		$my_return{desc} = "pause fail: $return_detail->{desc}";
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{  
		$my_return{value} = 0;
		$my_return{desc} = "pause ok";
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	}

	return \%my_return;
}

sub recover_archer_task
{
	my ($this,$archer_id) = @_;
	my $return_detail;
	my %my_return;
	my $param_str;
	#foreach (@_){
	#	if((!defined($_)) || "$_" eq ""){
	#		$my_return{desc} = "input params erro,now params are :$param_str";
	#		$my_return{value} = 1;
        #		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	#		return \%my_return;
	#	}
	#	$param_str .= "$_,";
	#}
	my $RECOVER_ARCHER = "goon";
	### $RECOVER_ARCHER
	$return_detail = control_archer_api($RECOVER_ARCHER,$archer_id,$ARCHER_CONTROL_TOKEN);
	if("$return_detail->{value}" ne "0"){
		$my_return{value} = 1;
		$my_return{desc} = $return_detail->{desc};
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	}else{
		$my_return{value} = 0;
		$my_return{desc} = "successfully restart $archer_id";
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	}

	return \%my_return;
}

sub remove_pause_tag
{
	my ($this) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;

	#foreach (@_){
	#	if((!defined($_)) || "$_" eq ""){
	#		$my_return{desc} = "input params erro,now params are :$param_str";
	#		$my_return{value} = 1;
        #	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	#		return \%my_return;
	#	}
	#	$param_str .= "$_,";
	#}
	my $argv_list = $this->{argv_list};
	### $argv_list
	### $PAUSE_TAG
	########################################################
	# TODO
	my $cmd = "rm $PAUSE_TAG";
	$return_detail = &run_cmd_api("$cmd",1);
	if("$return_detail->{value}" ne "0"){
		$my_return{value} = 1;
		$my_return{desc} = "remove pause tag fail: $return_detail->{desc}";
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{  
		$my_return{value} = 0;
		$my_return{desc} = "remove pause tag ok";
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	}
	
	if ($this->{param}->{type} eq "deploy_id" and $this->{param}->{deploy_id} =~ /,/) {
		my @deploy_ids = split(/,/, $this->{param}->{deploy_id});
		$this->{data}->{deploy_id} = \@deploy_id_list;	
	} else {
		### �Ȼ�ȡ��Ҫִ��action��deploy_id
        	$return_detail = $this->get_deploy_id_list();
        	if("$return_detail->{value}" ne "0"){
			$my_return{value} = 1;
			$my_return{desc} = "fail to get deploy_id list ";
			$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
	}

	$return_detail = $this->recover_all_the_deploy_id();

	if("$return_detail->{value}" ne "0"){
		$my_return{value} = 1;
		$my_return{desc} = "recover fail: $return_detail->{desc}";
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{  
		$my_return{value} = 0;
		$my_return{desc} = "recover ok";
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	}
	return \%my_return;
}

sub recover_all_the_deploy_id
{
	my ($this) = @_;
	my $return_detail;
	my %my_return;
	my $param_str;

	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
			$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}

	my @deploy_id_list = @{$this->{data}->{deploy_id}};
	my $not_done_count = 0;
	foreach (@deploy_id_list){
		$return_detail = $this->do_action_to_this_deploy_id($_);
		if("$return_detail->{value}" ne "0"){
			$not_done_count++;
			$my_return{desc} .= "$_ ";
		}
	}

	if($not_done_count > 0){
		$total_if_done = "no";
		$my_return{value} = 1;
		$my_return{desc} = "these deploy_id not done:[ $my_return{desc} ]";
        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	}else{
		$total_if_done = "yes";
		$my_return{desc} = "all deploy_id done";
		$my_return{value} = 0;
        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	}

	return \%my_return;
}
sub wait_for_host
{
	my ($this) = @_;
	my $return_detail;
	my %my_return;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}

	my $argv_list = $this->{argv_list};
	my $cmd = "$Bin/control_archer $argv_list --noprintlogtostdout 1";
	$return_detail = &run_cmd_api("$cmd",1);
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "get host list fail,$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	}else{  
	        $my_return{value} = 0;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	}

	return \%my_return;
}

sub get_host_of_all_the_deploy_id
{
	my ($this) = @_;
	my $return_detail;
	my %my_return;
	my $param_str;

	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
			$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}

    my @deploy_id_list = @{$this->{data}->{deploy_id}};
	my @old_host_list = ();
	my @new_host_list = ();
    my $not_done_count = 0;

	### �������е�deploy_id
	foreach (@deploy_id_list){
		$return_detail = $this->get_host_list_of_this_deploy_id($_);
		### $return_detail
		if("$return_detail->{value}" ne "0"){
			$not_done_count++;
			$my_return{desc} = "$_ ";
		}
		@new_host_list = @{$return_detail->{desc}};
		push @old_host_list,@new_host_list;	
    }
	### @old_host_list
	### �������б�ȥ��
	#$return_detail = uniq_array_api(\@old_host_list);
	$return_detail{value} = 0;
	$return_detail{desc} = \@old_host_list;
	if("$return_detail->{value}" eq "0"){
		@old_host_list = @{$return_detail->{desc}};
	}
	### @old_host_list
	my $host_num = scalar @old_host_list;
	if($host_num == 0){
		$my_return{value} = 1;
		$my_return{desc} = "no host list";
        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
		
	}else{
		$my_return{value} = 0;
		$my_return{desc} = join("\n",@old_host_list);
        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
		return \%my_return;
	}	
}

sub get_host_list_of_this_deploy_id
{
	my ($this,$deploy_id) = @_;
	my $return_detail;
	my %my_return;
	my $param_str;

	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}

	my $json_obj = new JSON::XS;
	my $deploy_id_status_table;
	$return_detail = get_zk_all_info_api($deploy_id);

	if("$return_detail->{value}" ne "0"){
		$my_return{desc} = "$return_detail->{desc}";
		$my_return{value} = 1;
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{  
		$deploy_id_status_table = $json_obj->decode($return_detail->{desc});
	}

	my @task_id_list = keys %{$deploy_id_status_table->{all_task_id}};
	my @old_host_list = ();
	my @new_host_list = ();
	foreach (@task_id_list){
		$return_detail = get_archer_host_api($_);
		### $return_detail
		if("$return_detail->{value}" eq "0"){
			@new_host_list = @{$return_detail->{desc}};
			push @old_host_list,@new_host_list;
		}
	}

	my $host_num = scalar @old_host_list;
	if($host_num == 0){
		$my_return{desc} = "$deploy_id has no host";
		$my_return{value} = 1;
        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	}else{
		$my_return{desc} = \@old_host_list;
		$my_return{value} = 0;
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	}

	return \%my_return;
}

sub xpp
{
	### 13yy
	my ($this) = @_;
	my $return_detail;
	my %my_return;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}

	if("$return_detail->{value}" ne "0"){
		$my_return{value} = 1;
		$my_return{desc} = $return_detail->{desc};
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{
		$my_return{value} = 0;
		$my_return{desc} = "pause ok : task_id=$task";
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
		return \%my_return;
	}
}


1;
