package archer_bm::archer_bm;
BEGIN
{
	use Exporter();
	use vars qw($VERSION @ISA @EXPORT);
	use Data::Dumper;
	use File::Basename;
	use Fcntl qw(:flock);
	use FindBin qw($Bin);
	use lib "$Bin/../lib";
	use lib "$Bin/../conf";
	use lib "$Bin/../tools";
	use lib "$Bin/../../../public/alarm_api/perl/";
	use lib "$Bin/../../public/lib";

	use Time::HiRes qw(time);
	use Smart::Comments;
	use CONFIG;
	use JSON::XS;
	use POSIX;
#	use archer_bm::Common;
	use Common;
	use Alarm;
	use strict;
	use warnings;
	use Switch;
	@ISA = qw(Exporter);
	@EXPORT = qw (
		$ARCHER_WORKSPACE
		);
}

$ARCHER_WORKSPACE="$Bin/../data/";

sub new 
{
	my ($type,$logit,$param) = @_;
	$this->{logit} = $logit;
	$this->{param} = $param;
	bless $this;
	return $this;
}
sub check_param_before_goto_work
{
        my ($this,$input_param_list) = @_;
        my $return_detail;
        my %my_return; 
	my @to_check_item;
	my $function;
	my $param_str;
	foreach (@_){

		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
    	### �ȼ����Ҫ����Ĳ������Ƿ񶼸�ֵ��
        @to_check_item = keys %OPT_LONG_VALUE;
        $return_detail = check_is_item_in_hash_api(\@to_check_item, $input_param_list);
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "param check fail: $return_detail->{desc}";
                $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
        }

	### �ٷֱ�Ը�����������ض�������м��
	@to_check_item = keys %OPT_LONG_CHECK;
	foreach (@to_check_item){
		$function = $OPT_LONG_CHECK{$_}->{function};
		### $function
		if((!defined($function)) || "$function" eq ""){
			next;
		}
		$return_detail = &$function;
        	if("$return_detail->{value}" ne "0"){
        	        $my_return{value} = 1;
        	        $my_return{desc} = "$return_detail->{desc}";
        	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
        	        return \%my_return;
        	}
	} 
        $my_return{value} = 0;
        $my_return{desc} = "all param check ok";
        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
        return \%my_return;


}
sub check_block_before_start_idc
{
        my ($this) = @_;
        my $return_detail;
        my %my_return;
	my $param_str;
	foreach (@_){

		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}

	### ����Ƿ����ȫ�ֵĻ����ź�
	$return_detail = check_super_mutex_api();
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "$return_detail->{desc}";
                $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
        }else{
                $my_return{value} = 0;
                $my_return{desc} = "$return_detail->{desc}";
                $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
                return \%my_return;
        }

	### ���ģ�鼶���Ƿ���ڻ���
	my $module_mutex_token = $this->{conf}->{cm_conf}->{basic_info}->{module_mutex_token};
	$return_detail = check_mutex_status_api($module_mutex_token);
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 0;
                $my_return{desc} = "$return_detail->{desc}";
                $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
        }else{
                $my_return{value} = 0;
                $my_return{desc} = "$return_detail->{desc}";
                $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
                return \%my_return;
        }
}
sub check_action
{
	my ($this) = @_;
        my $return_detail;
        my %my_return;
	my $action = $this->{param}->{action};
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	### ���action �ĸ�ֵ�Ƿ�Ϊָ����ֵ
	my @action_list = keys %{$OPT_LONG_CHECK{action}->{action_list}};
	if(! exists $OPT_LONG_CHECK{action}->{action_list}->{$action}){
        	$my_return{value} = 1;
        	$my_return{desc} = "action can only be : @action_list";
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
        	return \%my_return;
	}else{
	        $my_return{value} = 0;
	        $my_return{desc} = "action ok";
	        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	        return \%my_return;
	}
	
}
sub check_level_conf
{
	my ($this) = @_;
        my $return_detail;
        my %my_return;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}

	my $level_conf_desc = $OPT_LONG_CHECK{level_conf}->{desc};
	my $level_conf = $this->{param}->{level_conf};

	### �ȼ���ļ��Ƿ���� level_conf
	$return_detail = check_file_exists_api($level_conf);
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}

	### �ټ����ļ� level_conf
	$return_detail = $this->load_param_conf_detail($level_conf,$level_conf_desc);
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}else{
		$my_return{value} = 0;
		$my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
		return \%my_return;
	}
}
sub check_alarm_conf
{
	my ($this) = @_;
        my $return_detail;
        my %my_return;
        my $param_str;
        foreach (@_){
                if((!defined($_)) || "$_" eq ""){
                        $my_return{desc} = "input params erro,now params are :$param_str";
                        $my_return{value} = 1;
                        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                        return \%my_return;
                }
                $param_str .= "$_,";
        }

        my $alarm_conf = $this->{param}->{alarm_conf};
        my $alarm_conf_desc = $OPT_LONG_CHECK{alarm_conf}->{desc};

        ### �ȼ���ļ��Ƿ���� alarm_conf
        $return_detail = check_file_exists_api($alarm_conf);
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "$return_detail->{desc}";
                $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
        }
        ### �ټ����ļ� alarm_conf
        $return_detail = $this->load_param_conf_detail($alarm_conf,$alarm_conf_desc);
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "$return_detail->{desc}";
                $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
        }
        $my_return{value} = 0;
        $my_return{desc} = "successfully checked alarm_conf";
        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
        return \%my_return;
	
}
sub check_cm_conf
{
        my ($this) = @_;
        my $return_detail;
        my %my_return;
	my $param_str;
	foreach (@_){

		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}

	my $cm_conf = $this->{param}->{cm_conf};
	my $cm_conf_desc = $OPT_LONG_CHECK{cm_conf}->{desc};

	### �ȼ���ļ��Ƿ���� cm_conf
        $return_detail = check_file_exists_api($cm_conf);
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "$return_detail->{desc}";
                $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
        }
	### �ټ����ļ� cm_conf
	$return_detail = $this->load_param_conf_detail($cm_conf,$cm_conf_desc);
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}

	### ���cm.conf���level_order˳���Ƿ��ϸ���0/1/2/3...������˳������
	$return_detail = $this->check_level_order();
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}else{
		$my_return{value} = 0;
		$my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
		return \%my_return;
	}
}
sub load_param_conf_detail 
{
        my ($this, $conf_file,$conf_desc) = @_;
        my %my_return;
        my $conf_detail;
	my $param_str;
	foreach (@_){

		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}

        if("$conf_desc->{conf_type}" eq "json") {
                $return_detail = &load_conf_json_api($conf_file);
		if("$return_detail->{value}" ne "0"){
			$my_return{value} = 1;
			$my_return{desc} = "$return_detail->{desc}";
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}else{
			$conf_detail = $return_detail->{desc};
		}
		
        } elsif ("$conf_desc->{conf_type}" eq "ini") {
                $conf_detail = &load_conf_ini_api($conf_file);
		#if("$return_detail->{value}" ne "0"){
		#	$my_return{value} = 1;
		#	$my_return{desc} = "$return_detail->{desc}";
        	#	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		#	return \%my_return;
		#}else{
		#	$conf_detail = $return_detail->{desc};
		#}
		#
        } elsif ("$conf_desc->{conf_type}" eq "kv") {
                $conf_detail = &load_conf_key_value($conf_file, $conf_desc->{split_item});
		if("$return_detail->{value}" ne "0"){
			$my_return{value} = 1;
			$my_return{desc} = "$return_detail->{desc}";
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}else{
			$conf_detail = $return_detail->{desc};
		}
        } else {
		$my_return{desc} = "I can only support json|ini|kv";
		$my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
        }
        $this->{conf}->{$conf_desc->{conf_key}} = $conf_detail;
	$my_return{desc} = "successfully loaded $conf_file";
	$my_return{value} = 0;
       	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	return \%my_return;
}
sub check_level_order
{
	my ($this) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){

		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}

	
	print Dumper($this->{conf}->{cm_conf});
	my %level_order = %{$this->{conf}->{cm_conf}->{level_order}};

	my $level_order_key_num = scalar keys %level_order;
	my @tmp_array = values %level_order;

	$return_detail = uniq_array_api(\@tmp_array);
	my @level_in_level_order = @{$return_detail->{desc}};
	my $level_order_value_num = scalar  @level_in_level_order;

	my %level_in_level_control = %{$this->{conf}->{cm_conf}->{level_control}};
	my $level_control_key_num = scalar keys %level_in_level_control;
	
	my $count = 0;
	
	### �ж�level_order�Ƿ�Ϊ��
	if("$level_order_key_num" eq "0"){
		$my_return{desc} = "level_order should be like this : 0:level_0,1:level_1 .....";
		$my_return{value} = 1;
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
		
	}
	### �ж�level_order���level���Ƿ��level_control���level��һ��
	### $level_order_value_num
	### $level_control_key_num
	if("$level_order_value_num" ne "$level_control_key_num"){
		$my_return{desc} = "level_order_value_num does not equal to level_control_key_num";
		$my_return{value} = 1;
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
		
	}
	### ��0��ʼ��飬���Ƿ�����˳�����ֵ������
	while ($count < $level_order_key_num){
		if(! exists $level_order{$count}){
			### ���level order�ﲻ����ĳ��order������Ϊ������
			$my_return{desc} = "[fail] theres should be $count in level order";
			$my_return{value} = 1;
			$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$count++;
	}
	###���ټ�� level_order����ֵ�level �� level_control���level�Ƿ�һ��
	foreach (@level_in_level_order){
		print "=== $_ \n";
		if(! exists $level_in_level_control{$_}){
			$my_return{desc} = "[fail] $_ does not exist in level_control";
			$my_return{value} = 1;
			$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
	}
	$my_return{desc} = "level order check ok";
	$my_return{value} = 0;
	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	return \%my_return;


}

sub goto_work
{
	my ($this) = @_;
        my $return_detail;
        my %my_return;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}

	my $deploy_id = $this->{param}->{deploy_id};
	
	### ׼��ifdo
	$return_detail = $this->prepare_ifdo();
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "[fail] prepare_ifdo : $return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}
	
	### Ϊ���л���׼����Ҫ�������ļ�		
	$return_detail = $this->prepare_all_idc_conf();
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "[fail]prepare_all_idc_conf : $return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}
	
	### ��ʼ���ڴ�ʱ���
	$return_detail = $this->initialize_time_table();

	### ��ʼ��zk״̬��
	$return_detail = $this->initialize_status_table();
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "[fail]initialize_status_table : $return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}
	
	$return_detail = $this->register_deploy_id();
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "[fail]register_deploy_id : $return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}

	$return_detail = $this->notice_start();
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "[fail]deploy each fail : $return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}

	$return_detail = $this->deploy_each_level();
	### $return_detail
#	if("$return_detail->{value}" ne "0"){
#	        $my_return{value} = 1;
#	        $my_return{desc} = "[fail]deploy each fail : $return_detail->{desc}";
#	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
#	        return \%my_return;
#	}

	my $message;
	my $module = $this->{param}->{module};

	### �ж��Ƿ�������Ҫ�ع��Լ�����roadmap
	$return_detail = get_zk_attr_info_api($deploy_id,"overall.outside_sign");
	chomp($return_detail->{desc});
	if("$return_detail->{desc}" eq "$TOTAL_CANCEL"){
		my $if_auto_rollback = $this->{conf}->{cm_conf}->{basic_info}->{if_auto_rollback};
		if("$if_auto_rollback" eq "yes"){
			$my_return{desc} = "need to auto_rollback";
        		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
			$return_detail = $this->goto_rollback();
			### $return_detail
			chomp($return_detail->{desc});
			$my_return{desc} = "trigger rollback result: $return_detail->{desc}";
			$message = "[$module][$return_detail->{desc}]";
			send_msg_by_robot_api("$message");
        		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);

		}else{
			$message = "[$module][��ģ�������˷��Զ��ع�,�����������ֶ��ع�]";
			send_msg_by_robot_api("$message");
			$my_return{desc} = "if_auto_deploy is closed,so do it manually";
        		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
		}
	}else{

	        $return_detail = $this->update_roadmap_of_deploy_id();
	        if("$return_detail->{value}" ne "0"){
	                $message = "[$module][�������,������roadmapʧ��,��OP�ֶ��޸�][$return_detail->{desc}][$deploy_id]";
	                send_msg_by_robot_api("$message");
	                $my_return{value} = 1;
	                $my_return{desc} = "[fail]all done , but update default roadmap: $return_detail->{desc},recover the roadmap by mannually";
	                $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	                return \%my_return;
	        }else{
	        	$message = "[done][$module][$deploy_id]";
		        send_msg_by_robot_api("$message");
		}
	}

	### ע��deploy_id	
	$return_detail = $this->unregister_deploy_id();
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "[fail]unregister deploy_id fail : $return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}

	#$message = "[$module][�Ѿ�ע������deploy_id,���߳ɹ�orʧ����ǰ����ϢΪ׼][$deploy_id]";
	#send_msg_by_robot_api("$message");
		
        $my_return{value} = 0;
       	$my_return{desc} = "good,nice deploy, all done!";
        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
        return \%my_return;
}

sub notice_start
{
        my ($this) = @_;
        my $return_detail;
        my %my_return;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $deploy_id = $this->{param}->{deploy_id};
	my $module = $this->{param}->{module};
	my $message = "[start][$module][$deploy_id]";

	### �ȸ�hiȺ�����߿�ʼͨ��
	$return_detail = send_msg_by_robot_api("$message");
	
	my @rd_email_list = @{$this->{conf}->{alarm_conf}->{v}->{DEFAULT}->{rd_email}};
	my @rd_phone_list = @{$this->{conf}->{alarm_conf}->{v}->{DEFAULT}->{rd_phone}};
	my @op_email_list = @{$this->{conf}->{alarm_conf}->{v}->{DEFAULT}->{op_email}};
	my @op_phone_list = @{$this->{conf}->{alarm_conf}->{v}->{DEFAULT}->{op_phone}};
	my @to_be_mailed = ();
	my @to_be_phoned = ();

	push @to_be_mailed,@rd_email_list;
	push @to_be_mailed,@op_email_list;
	push @to_be_phoned,@rd_phone_list;
	push @to_be_phoned,@op_phone_list;
	
	$return_detail = uniq_array_api(\@to_be_mailed);
	@to_be_mailed = @{$return_detail->{desc}};
	### @to_be_mailed
	### �ٷ��ʼ���RD�Ǹ�֪�俪ʼ������
	my $check_url = "$TOTAL_PROGRESS_URL" . "?&id=$deploy_id";
	my $title = "$module [����֪ͨ]";
        $message = "[��˲鿴�������߽����Լ�Ч��ȷ��]" . '<a href=' . "\'$check_url\'>" .  "[$deploy_id]" . '</a>';

	### $message
	### $title

	$return_detail = $this->send_mail_to_member("$title","$message",\@to_be_mailed);
	### $return_detail

	### ����������RD�Ǹ�֪�俪ʼ������
	$message = "[����id��: $deploy_id][��ϸ�����Լ���������������ʼ�]";
	$return_detail = $this->send_message_to_member("$title","$message",\@to_be_phoned);
	
	$my_return{desc} = "sucessfully notice start";
	$my_return{value} = 0;
	return \%my_return;
	
}
sub send_message_to_member
{
        my ($this,$title,$message,$phone_list) = @_;
        my $return_detail;
        my %my_return;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my @tmp_array;
	my $new_phone_listi;


	$return_detail = uniq_array_api($phone_list);
	if("$return_detail->{value}" eq "0"){
		$new_phone_list = $return_detail->{desc};
	}
	### $new_phone_list
	foreach (@{$new_phone_list}){
		@tmp_array = split(/,/,$_);
		$phone = $tmp_array[0];
		$my_return{desc} .= "$phone,";
		$return_detail = send_message_api("$title","$message",$phone);
	}
	$my_return{desc} .= "[these member got message]";
	$my_return{value} = 0;
	return \%my_return;

}
sub send_mail_to_member
{
        my ($this,$title,$message,$mail_list) = @_;
        my $return_detail;
        my %my_return;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $member;
	my @tmp_array;

	### ѭ���������е�member������Щmember�����ʼ�
	### $mail_list
	### $message
	foreach (@{$mail_list}){
		@tmp_array = split(/@/,$_);
		$my_return{desc} .= "$tmp_array[0],";
		$member = "$tmp_array[0]" . "\@baidu.com";
		$return_detail = send_mail_api("$title","$message","$member");
		### $return_detail
	}
	$my_return{desc} = "@{$mail_list} [these members got email]";
	$my_return{value} = 0;
        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	return \%my_return;
	
}

sub set_module_alias
{
        my ($this) = @_;
        my $return_detail;
        my %my_return;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $module = $this->{param}->{module};
	my @tmp_array = split(/\//,$module);
	my $module_alias = join(':',@tmp_array);
	$this->{param}->{module_alias} = $module_alias;
	$my_return{value} = 0;
	$my_return{desc} = "successfully set module alias: $module_alias ";
     	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	return \%my_return;
	
}

sub unregister_deploy_id
{
        my ($this) = @_;
        my $return_detail;
        my %my_return;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $deploy_id = $this->{param}->{deploy_id};
	my $module_alias = $this->{param}->{module_alias};

	### ���������ʱ��д�뵽zk
	my $now_time = get_now_time_api();
	my $deta_time;


	### һ���Խ��ܲ���ʱ�䡢���ʱ�䡢����ʱ��д��zk
	$return_detail = add_zk_info_api($deploy_id,"overall.end_time",$now_time);
	$deta_time = $this->{time}->{total_deploy_time};
	add_zk_info_api($deploy_id,"overall.total_deploy_time",$deta_time);
	### $deta_time

	$deta_time = $this->{time}->{total_check_time};
	add_zk_info_api($deploy_id,"overall.total_check_time",$deta_time);
	### $deta_time

	$deta_time = $this->{time}->{total_block_time};
	add_zk_info_api($deploy_id,"overall.total_block_time",$deta_time);
	### $deta_time

	$deta_time = sprintf("%.1f",($this->{time}->{total_deploy_time} + $this->{time}->{total_check_time} + $this->{time}->{total_block_time}));
	add_zk_info_api($deploy_id,"overall.total_shangxian_time",$deta_time);
	### $deta_time

	### ���������߶�����ע��deploy_id
        $return_detail = del_zk_attr_api($AUTO_DEPLOY_WORKING_DEPLOY_QUEUE,"deploy_id.$deploy_id");
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "$return_detail->{desc}";
                $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
	}
	### ���������ߵĶ�����ע��ģ�����
        $return_detail = del_zk_attr_api($AUTO_DEPLOY_WORKING_DEPLOY_QUEUE,"module.$module_alias");
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "$return_detail->{desc}";
                $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
	}
       $my_return{value} = 0;
       $my_return{desc} = "unregister $deploy_id and $module_alias from zk ok";
       $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
       return \%my_return;

	
}
sub register_deploy_id
{
        my ($this) = @_;
        my $return_detail;
        my %my_return;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $module = $this->{param}->{module_alias};
	my $deploy_id = $this->{param}->{deploy_id};
	my $now_time = get_now_time_api();
	my $now_time_s = time;
	$this->{time}->{all_start_time} = $now_time_s;

	$return_detail = &add_zk_info_api($deploy_id,"overall.start_time",$now_time);
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}
	$return_detail = &add_zk_info_api($AUTO_DEPLOY_WORKING_DEPLOY_QUEUE,"deploy_id.$deploy_id",$module);
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}
	$return_detail = &add_zk_info_api($AUTO_DEPLOY_WORKING_DEPLOY_QUEUE,"module.$module",$deploy_id);
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}

        $my_return{value} = 0;
        $my_return{desc} = "[ok]successfully registered deploy_id into zk";
        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
        return \%my_return;
	
}
	
sub initialize_time_table
{
        my ($this) = @_;
        my $return_detail;
        my %my_return;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}

#        $this->{time}->{total_block_time} = 0;
#        $this->{time}->{total_deploy_time} = 0;
#        $this->{time}->{total_check_time} = 0;
#        $this->{time}->{level_control}->{$level}->{start_time} = 0;
#        $this->{time}->{level_control}->{$level}->{idc_done_time} = 0;
#        $this->{time}->{level_control}->{$level}->{end_time} = 0;
#        $this->{time}->{level_control}->{$level}->{block_end_time} = 0;
#        $this->{time}->{level_control}->{$level}->{deploy_time} = 0;
#        $this->{time}->{level_control}->{$level}->{check_time} = 0;
#        $this->{time}->{level_control}->{$level}->{idc}->{$idc}->{start_time} = 0;
#        $this->{time}->{level_control}->{$level}->{idc}->{$idc}->{block_end_time} = 0;
#        $this->{time}->{level_control}->{$level}->{idc}->{$idc}->{deploy_time} = 0;
#        $this->{time}->{level_control}->{$level}->{idc}->{$idc}->{end_time} = 0; 

	$this->{time}->{total_block_time} = 0;
	$this->{time}->{total_deploy_time} = 0;
	$this->{time}->{total_check_time} = 0;
	$this->{time}->{start_time} = 0;
	$this->{time}->{end_time} = 0;
	my $level_control = $this->{conf}->{cm_conf}->{level_control};
	my @level_array = keys %{$level_control};
	foreach my $level (@level_array){
		$this->{time}->{level_control}->{$level}->{start_time} = 0;
		$this->{time}->{level_control}->{$level}->{end_time} = 0;
		$this->{time}->{level_control}->{$level}->{block_time} = 0;
		$this->{time}->{level_control}->{$level}->{deploy_time} = 0;
		$this->{time}->{level_control}->{$level}->{check_time} = 0;
		$this->{time}->{level_control}->{$level}->{block_end_time} = 0;
		$this->{time}->{level_control}->{$level}->{idc_done_time} = 0;
		my $idc_control = $level_control->{idc};
		my @idc_array = keys %{$idc_control};
		foreach my $idc (@idc_array){
			$this->{time}->{level_control}->{$level}->{idc}->{$idc}->{start_time} = 0;
			$this->{time}->{level_control}->{$level}->{idc}->{$idc}->{block_end_time} = 0;
			$this->{time}->{level_control}->{$level}->{idc}->{$idc}->{end_time} = 0;
			$this->{time}->{level_control}->{$level}->{idc}->{$idc}->{deploy_time} = 0;
		}
	}
        $my_return{value} = 0;
        $my_return{desc} = "[ok]initialize time table";
        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
        return \%my_return;
	
}
sub initialize_status_table
{
        my ($this) = @_;
        my $return_detail;
        my %my_return;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $deploy_id = $this->{param}->{deploy_id};
	my $module = $this->{param}->{module};
	my $deploy_method = $this->{conf}->{cm_conf}->{basic_info}->{deploy_method};
	my %status_hash = (
		"overall" => {
			"deploy_method" => "$deploy_method",
			"module" => "$module",
			"now_status" => "",
			"outside_sign" => "",
			"start_time" => "",
			"end_time" => "",
			"total_shangxian_time" => "",
			"total_deploy_time" => "",
			"total_check_time" => "",
			"total_block_time" => "",
		},
		"all_task_id" => {
		},
	); 
	my ($level,$idc,$ifdo,$member)  = @_;
	my @tmp_array;
	my @idc_list;
	my $rd_email = $this->{conf}->{alarm_conf}->{v}->{DEFAULT}->{rd_email};
	my $qa_email = $this->{conf}->{alarm_conf}->{v}->{DEFAULT}->{qa_email};
	my $op_email = $this->{conf}->{alarm_conf}->{v}->{DEFAULT}->{op_email};
	### $rd_email
	#my @rd_list = $rd_email =~ m#([\w\.\-_]+)\@baidu\.com#og;
	#my @qa_list = $qa_email =~ m#([\w\.\-_]+)\@baidu\.com#og;
	#my @op_list = $op_email =~ m#([\w\.\-_]+)\@baidu\.com#og;


	my $level_order = $this->{conf}->{cm_conf}->{level_order};
	$status_hash{level_order} = $level_order;
	my $level_control = $this->{conf}->{cm_conf}->{level_control};
	foreach $level (keys %{$level_control}){
		$ifdo = $level_control->{$level}->{ifdo};
		if((!defined($ifdo)) || "$ifdo" eq "no"){
			next;
		}
		$status_hash{level_control}->{$level} = {
			"now_status" => "",
			"start_time" => "",
			"end_time" => "",
			"shangxian_time" => "",
			"deploy_time" => "",
			"check_time" => "",
			"block_time" => "",
			"check_status" => {
				"ifok" => "",
				"desc" => "",
				"member" => {
					"rd" => {
						"ifdo" => "",
						"ifok" => "",
						"desc" => "",
					},
					"qa" => {
						"ifdo" => "",
						"ifok" => "",
						"now_status" => "",
						"desc" => "",
						"status_url" => "",
						"report_list" => {
							"task_id" => {
							},
						},
					},
					"op" => {
						"ifdo" => "",
						"ifok" => "",
						"now_status" => "",
						"desc" => "",
						"status_url" => "",
						"report_url" => "",
					},
				},
			},
		};
		### ��ʼ����������Ϣ
		@idc_list = keys %{$level_control->{$level}->{idc}};	
		foreach $idc (@idc_list){
			$ifdo = $level_control->{$level}->{idc}->{$idc}->{ifdo};
			if((!defined($ifdo)) || "$ifdo" eq "no"){
				next;
			}
			$status_hash{level_control}->{$level}->{idc}->{$idc} = {
				"now_status" => "",
				"start_time" => "",
				"deploy_time" => "",
				"end_time" => "",
				"task" => {
					"id" => "",
					"version" => "",
					"process_url" => "",
					"status_url" => "",
					"redo_url" => "",
					"skip_url" => "",
					"pause_url" => "",
				},
			};
			
		}
		### ��ʼ��RD����Ϣ
		foreach (@$rd_email){
			print "rd = $_\n";
			@tmp_array = split(/@/,$_);
			$member = $tmp_array[0];
			$status_hash{level_control}->{$level}->{check_status}->{member}->{rd}->{who}->{$member} = {
                                "end_time" => "",
                                "end_time_s" => "",
				"check_time" => "",
                                "ifok" => "",
                                "desc" => "",
				"check_ok_url" => "",
				"check_fail_url" => "",
                        };
		}

	}
	### this is after new json
	my $json_obj = new JSON::XS;
	my $status_str = $json_obj->encode(\%status_hash);
	$return_detail = &initial_zk_info_api($deploy_id,$status_str);
	if("$return_detail->{value}" ne "0"){

		### initial zk fail
		$my_return{value} = 1;
		$my_return{desc} = "write status table to zk failed, $return_detail->{desc}";
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{
		### initial zk ok

		$my_return{value} = 0;
		$my_return{desc} = "$return_detail->{desc}";
        	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
		return \%my_return;
	}
}
sub prepare_ifdo
{
        my ($this) = @_;
        my $return_detail;
        my %my_return;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}

	my @level_list;
	my $level;
	my @idc_list;
	my $idc;
	my %level_control_in_level_conf = %{$this->{conf}->{level_conf}->{level_control}};
	@level_list = keys %level_control_in_level_conf;
	if(! @level_list){
		### ���level.conf��û���κ�level����ô�˳�
		$my_return{desc} = "there's no level to do";
		$my_return{value} = 1;
       		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}
	### �ȼ��level.conf���level/idc �Ƿ񶼴�����cm.conf����
	foreach $level (@level_list){
		if(! exists $this->{conf}->{cm_conf}->{level_control}->{$level}){
			### �����ǰ���levelû����cm.conf��ע��
			$my_return{desc} = "$level is not recorded in $this->{param}->{cm_conf}, first register it";
			$my_return{value} = 1;
       			$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}else{

			@idc_list = keys %{$level_control_in_level_conf{$level}->{idc}};
			if(! @idc_list){
				### ���level.conf��ĳ��levelû��idc�����˳�
				$my_return{desc} = "bad , $level has no idc in level.conf";
				$my_return{value} = 1;
       				$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
				return \%my_return;
			}
				
			### ������level����cm.conf��ע����ˣ�������level.conf��idc
			foreach $idc (@idc_list){
				if(! exists $this->{conf}->{cm_conf}->{level_control}->{$level}->{idc}->{$idc}){
					### ������idcû����cm.conf��ע��
					$my_return{desc} = "$idc does not exist in $level,first reigster it";
					$my_return{value} = 1;
       					$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
					return \%my_return;
				}
			}
		}
	}

	### �ٶ�cm.conf��ĸ�level ��ifdo���и�ֵ
	@level_list = keys %{$this->{conf}->{cm_conf}->{level_control}};
	foreach $level (@level_list){
		if(! exists $level_control_in_level_conf{$level}){
			### ���level��������level.conf�����ifdoΪno
			$this->{conf}->{cm_conf}->{level_control}->{$level}->{ifdo} = "no";
		}else{
			### ���level������level.conf�����ifdoΪyes
			$this->{conf}->{cm_conf}->{level_control}->{$level}->{ifdo} = "yes";
			### �Ե�ǰ���level��idc��ifdo������λ
			@idc_list = keys %{$this->{conf}->{cm_conf}->{level_control}->{$level}->{idc}};
			foreach $idc (@idc_list){
				if(! exists $level_control_in_level_conf{$level}->{idc}->{$idc}){
					$this->{conf}->{cm_conf}->{level_control}->{$level}->{idc}->{$idc}->{ifdo} = "no";
				}else{
					$this->{conf}->{cm_conf}->{level_control}->{$level}->{idc}->{$idc}->{ifdo} = "yes";
					
				}
			}
		}
	}
	
	$my_return{desc} = "level_control prepare ok";
	$my_return{value} = 0;
    	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	return \%my_return;
}

sub prepare_all_idc_conf
{
	my ($this) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}

	my $deploy_id = $this->{param}->{deploy_id};
	my %level_order = %{$this->{conf}->{cm_conf}->{level_order}};
	my @idc_list;
	my $level_num = scalar keys %level_order;
	my ($level,$idc,$cmd,$workspace) = ();
	### ���������level
	$level_num--;
	my %level_control_in_level_conf = %{$this->{conf}->{level_conf}->{level_control}};
	foreach (0..$level_num){
		$level = $level_order{$_};
		### $level
		@idc_list = keys %{$level_control_in_level_conf{$level}->{idc}};
		### ���������level�µĸ�idc
		foreach $idc (@idc_list){

			### $idc
			$workspace = "$WORKSPACE/$deploy_id/$level/$idc";
			$cmd = "mkdir -p $workspace";
			$return_detail = &run_cmd_api("$cmd",1);
			if("$return_detail->{value}" ne "0"){
			        $my_return{value} = 1;
			        $my_return{desc} = "$return_detail->{desc}";
			        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			        return \%my_return;
			}
			
			$return_detail = $this->prepare_a_lot_for_this_idc($level,$idc,$workspace);
			if("$return_detail->{value}" ne "0"){
			        $my_return{value} = 1;
			        $my_return{desc} = "$return_detail->{desc}";
			        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			        return \%my_return;
			}
		}

	}
	$my_return{desc} = "successfully prepared conf for all idc: $WORKSPACE/$deploy_id";
	$my_return{value} = 0;
    	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	return \%my_return;
}

sub prepare_a_lot_for_this_idc
{
	my ($this,$level,$idc,$workspace) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $deploy_id = $this->{param}->{deploy_id};
	$return_detail = $this->download_delivery_conf_for_this_idc($level,$idc,$workspace);
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}
	$return_detail = $this->load_delivery_conf_for_this_idc($level,$idc,$workspace);
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}
	### ׼��servers.des and deploy.des
	$return_detail = $this->prepare_servers_deploy_des_for_this_idc($level,$idc,$workspace);
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}
	### ׼��alertlist.des
	$return_detail = $this->prepare_alertlist_des_for_this_idc($level,$idc,$workspace);
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}
	### ׼������汾��,�е���Ҫ��3λת��4λ
	$return_detail = $this->prepare_version_for_this_idc($level,$idc);
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}
	### ׼��archer ʹ�õ�param.list
	$return_detail = $this->prepare_archer_param_list_for_this_idc($level,$idc,$workspace);
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}
	### ����action��ֵ��׼�������token
	$return_detail = $this->prepare_mutex_token_for_this_idc($level,$idc);
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}
	$my_return{desc} = "successfully prepared conf for all idc: $WORKSPACE/$deploy_id";
	$my_return{value} = 0;
    	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	return \%my_return;

}
sub prepare_version_for_this_idc
{
	my ($this,$level,$idc) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $module = $this->{param}->{module};
	my $if_three_to_four_version = $this->{conf}->{cm_conf}->{basic_info}->{if_three_to_four_version};
	my $delivery_info = $this->{conf}->{level_conf}->{level_control}->{$level}->{idc}->{$idc}->{delivery_conf}->{v}->{DEFAULT};
	my $version = $delivery_info->{version};
	my $four_version = $version;
	### �����ж������version�Ƿ�Ϊ4λ
	$return_detail = check_if_four_version_api($version);
	if("$return_detail->{value}" ne "0"){
		### ������벻��4λ�汾��
		if("$if_three_to_four_version" eq "no"){
			### �������Ҫת����4λ�汾��
			$my_return{desc} = "Ooo, archer can't use three version,give a four verions,or set if_three_to_four_version=yes";
			$my_return{value} = 1;
			$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}else{
			### �����Ҫת����4λ�汾������
			$return_detail = get_four_version_api($module,$version);
			if("$return_detail->{value}" eq "0"){
				$four_version = $return_detail->{desc};
			}else{
				$my_return{desc} = "$return_detail->{desc}";
				$my_return{value} = 1;
	        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
				return \%my_return;
			}
		}
	}
	### ��4λ�汾��д�뵽delivery.conf��ȥ
	$delivery_info->{four_version} = $four_version;
	$my_return{desc} = "four version is : $four_version ";
	$my_return{value} = 0;
	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	return \%my_return;
}

sub prepare_mutex_token_for_this_idc
{
	my ($this,$level,$idc) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	### ��̬��cm.conf���idc_token�����õģ�����Ҫ����action�������������ı��ε�idc_token
	### ͬʱ����Ҫ��mutex_token�Ĵ����Խ����ж�

	$my_return{value} = 0;
	$my_return{desc} = "xpp,todo,mutex token prepare ok";
	return \%my_return;
}

sub prepare_servers_deploy_des_for_this_idc
{
	my ($this,$level,$idc,$workspace) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $file_path = "$this->{conf}->{cm_conf}->{basic_info}->{archer_des_svn_path}/$idc";
	$return_detail = $this->download_file('svn',$file_path,$workspace);
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}

	### �ȼ��servers.des�Ĵ����Ժ�yaml��ʽ��ȷ��
	my $servers_des = "$workspace/servers.des";
	$return_detail = &check_file_exists_api($servers_des);
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}
	$return_detail = &load_conf_yaml_api($servers_des);
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}
	### �ټ�� deploy.des�Ĵ����Ժ�yaml��ʽ��ȷ��
	my $deploy_des = "$workspace/deploy.des";
	$return_detail = &check_file_exists_api($deploy_des);
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}
	$return_detail = &load_conf_yaml_api($deploy_des);
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}
        $my_return{value} = 0;
        $my_return{desc} = "servers.des and deploy.des check ok";
        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
        return \%my_return;
}
sub prepare_alertlist_des_for_this_idc
{
	my ($this,$level,$idc,$workspace) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}

	my $alertlist_des = "$workspace/alertlist.des";
	my $ALERTLIST_DES;
	my $alarm_info = $this->{conf}->{alarm_conf}->{v}->{DEFAULT};
	my $email_list = $alarm_info->{op_email};
	my $phone_list = $alarm_info->{op_phone};
	open $ALERTLIST_DES,'>>',$alertlist_des;
	my $if_rd_receive_archer_alarm = $this->{conf}->{cm_conf}->{basic_info}->{if_rd_receive_archer_alarm};
	if("$if_rd_receive_archer_alarm" eq "yes"){
		if("$alarm_info->{rd_email}" ne ""){
			$email_list .= ',' . "$alarm_info->{rd_email}";
		}

		if("$alarm_info->{rd_phone}" ne ""){
			$phone_list .= ',' . "$alarm_info->{rd_phone}";
		}
	}
	print $ALERTLIST_DES "email: $email_list\n";
	print $ALERTLIST_DES "telephone: $phone_list\n";	
	close $ALERTLIST_DES;
	$my_return{desc} = "successfully prepare alertlist.des ";
	$my_return{value} = 0;
	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	return \%my_return;

}



sub prepare_archer_param_list_for_this_idc
{
	my ($this,$level,$idc,$workspace) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	
	my $cm_info = $this->{conf}->{cm_conf};
	my $delivery_info = $this->{conf}->{level_conf}->{level_control}->{$level}->{idc}->{$idc}->{delivery_conf}->{v}->{DEFAULT};
	my $alarm_info = $this->{conf}->{alarm_conf}->{v}->{DEFAULT};
	my $param_list = "$workspace/param.list";
	$this->{conf}->{cm_conf}->{level_control}->{$level}->{idc}->{$idc}->{param_list}->{file} = $param_list;
	$this->{conf}->{cm_conf}->{level_control}->{$level}->{idc}->{$idc}->{param_list}->{content}->{servers_des} = "$workspace/servers.des";

	my $hostname = `hostname`;
	chomp($hostname);
	my $PARAM_LIST;
	open $PARAM_LIST,'>>',$param_list;
	print $PARAM_LIST "servers_des=$workspace/servers.des\n";
	print $PARAM_LIST "deploy_des=$workspace/deploy.des\n";
	print $PARAM_LIST "alertlist=$workspace/alertlist.des\n";
	print $PARAM_LIST "control=$cm_info->{basic_info}->{control}\n";
	print $PARAM_LIST "deploy_path=$delivery_info->{deploy_path}\n";
	print $PARAM_LIST "ftp_or_scm=$delivery_info->{ftp_or_scm}\n";
	print $PARAM_LIST "ftp_path=ftp://$hostname:$workspace/output.tar.gz\n";
	print $PARAM_LIST "action=$delivery_info->{action}\n";
	print $PARAM_LIST "icafe=$delivery_info->{icafe}\n";
	print $PARAM_LIST "module=$delivery_info->{module}\n";
	print $PARAM_LIST "version=$delivery_info->{version}\n";
	print $PARAM_LIST "value_or_invalue_or_no=$cm_info->{basic_info}->{value_or_invalue_or_no}\n";
	print $PARAM_LIST "invalue=$cm_info->{level_control}->{$level}->{idc}->{$idc}->{invalue}\n";
	print $PARAM_LIST "value=$cm_info->{level_control}->{$level}->{idc}->{$idc}->{value}\n";
	print $PARAM_LIST "limitrate=$cm_info->{basic_info}->{limitrate}\n";
	print $PARAM_LIST "buildplatform=$delivery_info->{buildplatform}\n";
	print $PARAM_LIST "if_diff_deploy=$cm_info->{basic_info}->{if_diff_deploy}\n";
	print $PARAM_LIST "if_p2p=$cm_info->{basic_info}->{if_p2p}\n";
	print $PARAM_LIST "machineinterval=$cm_info->{basic_info}->{machineinterval}\n";
	print $PARAM_LIST "machinetimeout=$cm_info->{basic_info}->{machinetimeout}\n";
	print $PARAM_LIST "ignore_host_num=$cm_info->{basic_info}->{ignore_host_num}\n";
	print $PARAM_LIST "token=$cm_info->{basic_info}->{archer_token}\n";
	#print $PARAM_LIST "\n";

	$my_return{desc} = "successfully prepared $param_list ";
	$my_return{value} = 0;
	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	return \%my_return;
	


}
sub download_delivery_conf_for_this_idc
{
	my ($this,$level,$idc,$workspace) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my %level_control_in_level_conf = %{$this->{conf}->{level_conf}->{level_control}};
	my $protocol = $level_control_in_level_conf{$level}->{idc}->{$idc}->{protocol};
	my $conf_path = $level_control_in_level_conf{$level}->{idc}->{$idc}->{conf_path};
	print "protocol = $protocol , conf_path = $conf_path\n";
	$return_detail = $this->download_file($protocol,$conf_path,$workspace);
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}
        $my_return{value} = 0;
        $my_return{desc} = "$return_detail->{desc}";
        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
        return \%my_return;
}

sub download_file
{
	my ($this,$protocol,$conf_path,$workspace) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}

	if("$protocol" eq "svn"){
		$return_detail = download_svn_file_api($conf_path,$workspace);	
	}elsif("$protocol" eq "ftp"){
		$return_detail = download_ftp_file_api($conf_path,$workspace);
	}elsif("$protocol" eq "local"){
		$return_detail = download_local_file_api($conf_path,$workspace);
	}else{
	        $my_return{value} = 1;
	        $my_return{desc} = "sorry, only support : svn|ftp|local";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}else{
	        $my_return{value} = 0;
	        $my_return{desc} = "download conf success";
	        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	        return \%my_return;
	}
}
sub load_delivery_conf_for_this_idc
{
	my ($this,$level,$idc,$workspace) = @_;
	print "level = $level , idc =$idc , workspace = $workspace\n";
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	
	my %level_in_level_conf = %{$this->{conf}->{level_conf}->{level_control}->{$level}};
	my $conf_name = $DELIVERY_CONF{conf_name};
	my $conf_desc = $DELIVERY_CONF{desc};
	my $conf_key = $DELIVERY_CONF{desc}->{conf_key};
	my $file_path = "$workspace/$conf_name";
	$return_detail = check_file_exists_api($file_path);
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}	
	my $conf_detail = &load_conf_ini_api($file_path);
#	if("$return_detail->{value}" ne "0"){
#		$my_return{value} = 1;
#		$my_return{desc} = $return_detail->{desc};
#        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
#		return \%my_return;
#	}else{
#		$conf_detail = $return_detail->{desc};
#	}
	if("$conf_detail->{v}->{DEFAULT}->{version}" eq "" || "$conf_detail->{v}->{DEFAULT}->{module}" eq ""){
	        $my_return{value} = 1;
	        $my_return{desc} = "bad , $conf_name should has module and version";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}else{
		$level_in_level_conf{idc}->{$idc}->{$conf_key} = $conf_detail;
	}
	$return_detail = $this->check_delivery_conf_content($level,$idc,$workspace);
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}else{	
        	$my_return{value} = 0;
        	$my_return{desc} = "successfully load delivery.conf ";
        	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
        	return \%my_return;
	}
}
sub check_delivery_conf_content
{
	my ($this,$level,$idc,$workspace) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	$delivery_info = $this->{conf}->{level_conf}->{level_control}->{$level}->{idc}->{$idc}->{delivery_conf}->{v}->{DEFAULT};
	### ���method�����ã�ftp��scm
	$return_detail = $this->check_ftp_or_scm($level,$idc,$workspace);
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}
	### ���module
	$return_detail = $this->check_module_if_match($level,$idc);
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}
        $my_return{value} = 0;
        $my_return{desc} = "delivery_conf check ok";
        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
        return \%my_return;
	
}
sub check_module_if_match
{
	my ($this,$level,$idc) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $delivery_module = $this->{conf}->{level_conf}->{level_control}->{$level}->{idc}->{$idc}->{delivery_conf}->{v}->{DEFAULT}->{module};
	my $cm_module = $this->{param}->{module};
	if("$delivery_module" ne "$cm_module"){
		$my_return{desc} = "cm_module=$cm_module,delivery_module=$delivery_module,they don't match";
		$my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{
		$my_return{desc} = "module check ok";
		$my_return{value} = 0;
        	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
		return \%my_return;
	}
}
sub check_ftp_or_scm
{
	my ($this,$level,$idc,$workspace) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $cmd;
	$delivery_info = $this->{conf}->{level_conf}->{level_control}->{$level}->{idc}->{$idc}->{delivery_conf}->{v}->{DEFAULT};
	my $ftp_or_scm = $delivery_info->{ftp_or_scm};
	if((!defined($ftp_or_scm)) || "$ftp_or_scm" ne "ftp" && "$ftp_or_scm" ne "scm"){
		$my_return{desc} = "ftp_or_scm is needed in delivery.conf";
		$my_return{value} = 1;
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{
		if("$ftp_or_scm" eq "ftp"){
			my $ftp_path = $delivery_info->{ftp_path};
			if((!defined($ftp_path)) || "$ftp_path" eq ""){
				$my_return{desc} = "ftp_path can't be empty when method=ftp";
				$my_return{value} = 1;
				$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
				return \%my_return;
			}else{
				### ���ftp_path����д
				my @tmp_array = split(/\//,$ftp_path);
				### @tmp_array
				my $output_name = $tmp_array[-1];
				if("$output_name" ne "output.tar.gz") {
					$my_return{desc} = "I can only use output.tar.gz";
					$my_return{value} = 1;
					return \%my_return;
				}

				### ����output��
				$cmd = "wget $ftp_path -P $workspace -O $workspace/output.tar.gz";
				### $cmd 
				$return_detail = run_cmd_api("$cmd",1);
				if("$return_detail->{value}" ne "0"){
					$my_return{desc} = "fail to wget $ftp_path to $worksapce";
					$my_return{value} = 1;
					$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
					return \%my_return;
				}
				### ���output���Ƿ����سɹ�
				$return_detail = check_file_exists_api("$workspace/output.tar.gz");
				if("$return_detail->{value}" ne "0"){
					$my_return{desc} = "No such $workspace/output.tar.gz";
					$my_return{value} = 1;
					$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
					return \%my_return;
				}else{
					### ����output����md5

					$cmd = "md5sum $workspace/output.tar.gz > $workspace/output.md5";
					### $cmd
					$return_detail = run_cmd_api("$cmd",1);
					if("$return_detail->{value}" ne "0"){
						$my_return{desc} = "$return_detail->{desc}";
						$my_return{value} = 1;
						$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
						return \%my_return;
					}
			
				}
				
				
			}
		}
	}
	$my_return{desc} = "ftp_or_scm check ok";
	$my_return{value} = 0;
	return \%my_return;
}
sub check_if_zk_table_ok
{
	my ($this) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	$return_detail = &get_zk_attr_info_api($AUTO_DEPLOY_WORKING_DEPLOY_QUEUE,'deploy_id');
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}
	$return_detail = &get_zk_attr_info_api($AUTO_DEPLOY_WORKING_DEPLOY_QUEUE,'module');
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}else{
	        $my_return{value} = 0;
	        $my_return{desc} = "$AUTO_DEPLOY_WORKING_DEPLOY_QUEUE is ok";
	        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	        return \%my_return;
		
	}
	
	
}
sub deploy_each_level
{
	my ($this) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $level_num = scalar keys  %{$this->{conf}->{cm_conf}->{level_order}};
	$level_num--;
	my $level_control = $this->{conf}->{cm_conf}->{level_control};
	my ($level,$ifdo,$now_time,$now_time_s,$outside_sign) = ();
	my $message;
	my $title;
	my $deploy_id = $this->{param}->{deploy_id};
	my $module = $this->{param}->{module};
	my $deta_time;
	foreach  (0..$level_num){
		$level = $this->{conf}->{cm_conf}->{level_order}->{$_};
		### ���жϵ�ǰ���level�Ƿ��б�Ҫ��
		$ifdo = $level_control->{$level}->{ifdo};
		if("$ifdo" eq "no" || "ifdo" eq ""){
			next;
		}
		### ��һ��level��ʼʱ����¼��ʱ��
		$now_time = get_now_time_api();
		$now_time_s = time;
		$this->{time}->{level_control}->{$level}->{start_time} = time;
		$return_detail = add_zk_info_api($deploy_id,"level_control.$level.start_time",$now_time);


		### ���ж����level�Ƿ�������������outside_sign���ж�
		$return_detail = $this->check_outside_sign();
		if("$return_detail->{value}" ne "0"){
			$my_return{value} = 1;
			$my_return{desc} = "$return_detail->{desc}";
		        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			$message = "[$module][$deploy_id][������ԭ���˳�����:$return_detail->{desc}][��ֵ��op��ע]";
		        send_msg_by_robot_api("$message");
			return \%my_return;
		}else{
			$now_time = get_now_time_api();
			$this->{time}->{level_control}->{$level}->{block_end_time} = time;
			$deta_time = sprintf("%.1f", ($this->{time}->{level_control}->{$level}->{block_end_time} - $this->{time}->{level_control}->{$level}->{start_time}) / 60 );
			### ���µ�ǰlevel������ʱ��
			add_zk_info_api($deploy_id,"level_control.$level.block_time",$deta_time);
			### �����ܹ�������ʱ��
			$deta_time = sprintf("%.1f",($this->{time}->{total_block_time} + $deta_time));
			$this->{time}->{total_block_time} = $deta_time;
		}



		### ������level���в���
		$return_detail = $this->trigger_and_deploy_this_level($level);
		if("$return_detail->{value}" ne "0"){
		        $my_return{value} = 1;
		        $my_return{desc} = "$return_detail->{desc}";
		        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}

		### ɨ�貿����,ֱ���ܹ��и�level��end״̬Ϊֹ
		$return_detail = $this->scan_level_deploy_status_for_this_level($level);
		$now_time = get_now_time_api();
		$this->{time}->{level_control}->{$level}->{idc_done_time} = time;
		### ���µ�ǰlevel�Ĳ���ʱ��
		$deta_time = sprintf("%.1f", ($this->{time}->{level_control}->{$level}->{idc_done_time} - $this->{time}->{level_control}->{$level}->{block_end_time}) / 60 );
		add_zk_info_api($deploy_id,"level_control.$level.deploy_time",$deta_time);

		### �����ܹ��Ĳ���ʱ��
		$deta_time = sprintf("%.1f",($this->{time}->{total_deploy_time} + $deta_time));
		$this->{time}->{total_deploy_time} = $deta_time;

		if("$return_detail->{value}" ne "0"){
		        $my_return{value} = 1;
		        $my_return{desc} = "$return_detail->{desc}";
		        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}



		### ���ݵ�ǰlevel��״̬��ִ����ض���
		$return_detail = $this->do_some_action_according_to_level_status($level);
		$now_time = get_now_time_api();
		$this->{time}->{level_control}->{$level}->{end_time} = time;
		### ���µ�ǰlevel�ļ��ʱ��
		$deta_time = sprintf("%.1f", ($this->{time}->{level_control}->{$level}->{end_time} - $this->{time}->{level_control}->{$level}->{idc_done_time}) / 60 );
		add_zk_info_api($deploy_id,"level_control.$level.check_time",$deta_time);
		### �����ܹ��ļ��ʱ��,�ܵ�level����ʱ��
		$deta_time = sprintf("%.1f",($this->{time}->{total_check_time} + $deta_time));
		$this->{time}->{total_check_time} = $deta_time;
		$deta_time = sprintf("%.1f",($this->{time}->{level_control}->{$level}->{end_time} - $this->{time}->{level_control}->{$level}->{start_time}) / 60);
		add_zk_info_api($deploy_id,"level_control.$level.shangxian_time",$deta_time);
		add_zk_info_api($deploy_id,"level_control.$level.end_time",$now_time);

		if("$return_detail->{value}" ne "0"){
		        $my_return{value} = 1;
		        $my_return{desc} = "$return_detail->{desc}";
		        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}

	}



        $my_return{value} = 0;
        $my_return{desc} = "all level deploy done";
        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	return \%my_return;
}
sub do_some_action_according_to_level_status
{
	my ($this,$level) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $deploy_id = $this->{param}->{deploy_id};

	### �����ȡ�˲�����������ݲ�������ִ����Ӧ�Ķ���
	$return_detail = get_zk_attr_info_api($deploy_id,"level_control.$level.now_status");
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "fail to get $level.now_status";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}
	### $return_detail
	my $level_now_status = $return_detail->{desc};
	chomp($level_now_status);
	if("$level_now_status" eq "$LEVEL_DEPLOY_FAIL"){
		### ����LEVEL_DEPLOY_FAIL�ǽ�������
		$return_detail = $this->do_action_when_level_deploy_fail($level);
		if("$return_detail->{value}" ne "0"){
		        $my_return{value} = 1;
		        $my_return{desc} = "$return_detail->{desc}";
		        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
	}elsif("$level_now_status" eq "$LEVEL_DEPLOY_OK"){
		### ��ʱLEVEL_DEPLOY_OKʱ��������
		$return_detail = $this->do_action_when_level_deploy_ok($level);
		if("$return_detail->{value}" ne "0"){
		        $my_return{value} = 1;
		        $my_return{desc} = "$return_detail->{desc}";
		        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
	}else{
	        $my_return{value} = 1;
        	$my_return{desc} = "no such level.now_status";
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}
        $my_return{value} = 0;
	$my_return{desc} = "$return_detail->{desc}";
	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	return \%my_return;


}
sub do_action_when_level_deploy_fail
{
	my ($this,$level) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	### ��level������ʧ��ʱ������˷�֧
	my $deploy_id = $this->{param}->{deploy_id};
	my $module = $this->{param}->{module};

	### ����roadmapΪcancel״̬
	$return_detail = $this->update_roadmap_of_each_idc($level,'cancel');
        if("$return_detail->{value}" ne "0"){
                $my_return{desc} = "$return_detail->{desc}";
                $my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
	}
	### ����outside_signΪ cancel״̬
	$return_detail = add_zk_info_api($deploy_id,'overall.outside_sign',$TOTAL_CANCEL);
	my $message = "[$module][$level][���߳���][$deploy_id]";
	send_msg_by_robot_api("$message");
        if("$return_detail->{value}" ne "0"){
                $my_return{desc} = "$return_detail->{desc}";
                $my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
	}
       $my_return{desc} = "update roadmap and outside_sign ok";
       $my_return{value} = 0;
       $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
       return \%my_return;

}
sub do_action_when_level_check_ok
{
	my ($this,$level) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}	
	my $deploy_id = $this->{param}->{deploy_id};
	$return_detail = $this->update_roadmap_of_each_idc($level,'finish');
	### $return_detail
	if("$return_detail->{value}" ne "0"){
		$my_return{desc} = "$return_detail->{desc}";
		$my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}
	$return_detail = add_zk_info_api($deploy_id,"level_control.$level.now_status","$CHECK_OK");
	if("$return_detail->{value}" ne "0"){
		$my_return{desc} = "$return_detail->{desc}";
		$my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}
	$my_return{desc} = "roadmap and level.now_status update ok";
	$my_return{value} = 0;
	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	return \%my_return;
}
sub do_action_when_level_check_fail
{
	my ($this,$level) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $deploy_id = $this->{param}->{deploy_id};
	my $module = $this->{param}->{module};
	### ����roadmap��д��cancel
	$return_detail = $this->update_roadmap_of_each_idc($level,'cancel');
	if("$return_detail->{value}" ne "0"){
		$my_return{desc} = "$return_detail->{desc}";
		$my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}
	### ��level.now_status��Ϊ���CHECK_FAIL
	$return_detail = add_zk_info_api($deploy_id,"level_control.$level.now_status","$CHECK_FAIL");
	if("$return_detail->{value}" ne "0"){
		$my_return{desc} = "$return_detail->{desc}";
		$my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}
	### ����outside_signΪcancel״̬
	$return_detail = add_zk_info_api($deploy_id,'overall.outside_sign',"$TOTAL_CANCEL");
	if("$return_detail->{value}" ne "0"){
		$my_return{desc} = "$return_detail->{desc}";
		$my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}
	my $message = "[$module][$level][Ч����鲻ͨ��][$deploy_id]";
	send_msg_by_robot_api("$message");


	$my_return{desc} = "roadmap and level.now_status update ok";
	$my_return{value} = 0;
	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	return \%my_return;
}
sub goto_rollback
{
	my ($this) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $module = $this->{param}->{module};
	my $deploy_id = $this->{param}->{deploy_id};
	$return_detail = $this->notice_rollback();
	### $return_detail
	$return_detail = call_rollback_api($module,$deploy_id);
	### $return_detail
        if("$return_detail->{value}" ne "0"){
                $my_return{desc} = "$return_detail->{desc}";
                $my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
        }else{  
                $my_return{desc} = "$return_detail->{desc}";
                $my_return{value} = 0;
        	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
                return \%my_return;
        }
	
}
sub do_action_when_level_deploy_ok
{
	my ($this,$level) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $deploy_id = $this->{param}->{deploy_id};
	### ������鵱ǰlevel�Ĳ���Ч��
	$return_detail = $this->trigger_check_for_this_level($level);
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}
	### ��ȡ��level�ļ����
	$return_detail = $this->roll_to_get_check_result_of_this_level($level);
	### $return_detail
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}
	### ����level�ļ������ִ����Ӧ�Ķ���
	$return_detail = get_zk_attr_info_api($deploy_id,"level_control.$level.check_status.ifok");
	### $return_detail
	if("$return_detail->{value}" eq "0"){
		$level_check_status = $return_detail->{desc};
		chomp($level_check_status);
		if("$level_check_status" eq "$CHECK_OK"){
			### ��Ч�����ok��ʱ�򣬽���˷�֧
			$return_detail = $this->do_action_when_level_check_ok($level);
			if("$return_detail->{value}" ne "0"){
			        $my_return{value} = 1;
			        $my_return{desc} = "$return_detail->{desc}";
			        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
				return \%my_return;
			}
		}else{
			### ��Ч����鲻ok��ʱ�򣬽���˷�֧
			$return_detail = $this->do_action_when_level_check_fail($level);
			if("$return_detail->{value}" ne "0"){
			        $my_return{value} = 1;
			        $my_return{desc} = "$return_detail->{desc}";
			        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
				return \%my_return;
			}
		}
	}
        $my_return{value} = 0;
        $my_return{desc} = "$return_detail->{desc}";
        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	return \%my_return;

}
sub update_roadmap_of_deploy_id
{
	my ($this) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}

	$my_return{value} = 0;
        $my_return{desc} = "xpp,todo";
        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	return \%my_return;



	my $deploy_id = $this->{param}->{deploy_id};
	my $action = $this->{param}->{action};
	my $module = $this->{param}->{module};
	my $last_deploy_id = $this->{param}->{last_deploy_id}; 
	if("$last_deploy_id" eq "empty" || "$last_deploy_id" eq ""){ 
		$last_deploy_id = "";
	}
	my ($level_unit,$ifdo,$data_str,$version) = ();
	my $zk_info;
	my $json_obj = new JSON::XS;
	$return_detail = get_zk_attr_info_api($deploy_id,"level_control");
	if("$return_detail->{value}" ne "0"){
		$my_return{value} = 1;
		$my_return{desc} = "$return_detail->{desc}";
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{
		chomp($return_detail->{desc});
		$return_detail = json_decode_api($return_detail->{desc});
		if("$return_detail->{value}" ne "0"){
			$my_return{value} = 1;
			$my_return{desc} = "$return_detail->{desc}";
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}else{
			$zk_info = $return_detail->{desc};
		}
	}
	my @level_array = keys %{$zk_info};
	### @level_array
	my $one_level = $level_array[0];
	### $one_level
	my @idc_array = keys %{$zk_info->{$one_level}->{idc}};
	### @idc_array
	my $one_idc = $idc_array[0];
	### $one_idc
	$version = $this->{conf}->{level_conf}->{level_control}->{$one_level}->{idc}->{$one_idc}->{delivery_conf}->{v}->{DEFAULT}->{version};
	### $version
	my %data_hash = (
		"current_deploy_id" => "$deploy_id",
		"action" => "$action",
		"status" => "finish",
		"last_deploy_id" => "$last_deploy_id",
		"module_version" => "$version",
		
	);
	### %data_hash
	$data_str = $json_obj->encode(\%data_hash);
	### $data_str
	$return_detail = set_default_roadmap_api("$module","$data_str");
	### $return_detail
	if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "$return_detail->{desc}";
                $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
	}
	$my_return{value} = 0;
        $my_return{desc} = "$return_detail->{desc}";
        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	return \%my_return;
}
sub update_roadmap_of_each_idc
{
	my ($this,$level,$finish_or_cancel) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}

	$my_return{value} = 0;
        $my_return{desc} = "xpp,todo";
        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	return \%my_return;


	my $deploy_id = $this->{param}->{deploy_id}; 
	my $last_deploy_id = $this->{param}->{last_deploy_id}; 
	if("$last_deploy_id" eq "empty" || "$last_deploy_id" eq ""){ 
		$last_deploy_id = "";
	}
	my $action = $this->{param}->{action};
	my $module = $this->{param}->{module};
	my $idc_info = $this->{conf}->{cm_conf}->{level_control}->{$level}->{idc};
	my @idc_array = keys %{$idc_info};
	my ($level_unit,$ifdo,$data_str,$version) = ();
	my %data_hash;
	my $json_obj = new JSON::XS;
	foreach (@idc_array){
		$ifdo = $idc_info->{$_}->{ifdo};
		if("$ifdo" eq "no"){ 
			next;
		 }

		$level_unit = "$level.idc.$_";
		$version = $this->{conf}->{level_conf}->{level_control}->{$level}->{idc}->{$_}->{delivery_conf}->{v}->{DEFAULT}->{version};
		### $version
		%data_hash = (
			"current_deploy_id" => "$deploy_id",
			"action" => "$action",
			"status" => "$finish_or_cancel",
			"last_deploy_id" => "$last_deploy_id",
			"module_version" => "$version",
		);
		$data_str = $json_obj->encode(\%data_hash);
		$return_detail = add_roadmap_api("$module","$level_unit",$data_str);
		### $return_detail
		if("$return_detail->{value}" ne "0"){
                        $my_return{value} = 1;
                        $my_return{desc} = "$return_detail->{desc}";
                        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                        return \%my_return;
		}
	}
	$my_return{value} = 0;
        $my_return{desc} = "$return_detail->{desc}";
        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
        return \%my_return;

}
sub check_outside_sign
{
	my ($this) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $outside_sign;
	my $deploy_id = $this->{param}->{deploy_id};
        $return_detail = get_zk_attr_info_api($deploy_id,'overall.outside_sign');
        if("$return_detail->{value}" eq "0"){
                $outside_sign = $return_detail->{desc};
		chomp($outside_sign);
		if("$outside_sign" eq "$TOTAL_CANCEL"){
			### ���ж��Ƿ�ΪCANCLE
                	$my_return{value} = 1;
                	$my_return{desc} = "not allowed to do";
                	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                	return \%my_return;
		}
        }else{
                $my_return{value} = 1;
                $my_return{desc} = "fail to check outside sign ,I don't know if go on or not";
                $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
        }

	while("$outside_sign" eq "$TOTAL_PAUSE"){
		### ���ж��Ƿ���pause�ź�
                sleep($SCAN_IDC_INTERVAL);
                $return_detail = get_zk_attr_info_api($deploy_id,'overall.outside_sign');
                if("$return_detail->{value}" eq "0"){
                        $outside_sign = $return_detail->{desc};
                }else{
                        $my_return{value} = 1;
                        $my_return{desc} = "fail to check outside sign ,I don't know if go on or not";
                        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                        return \%my_return;
                }
	}
        $my_return{value} = 0;
        $my_return{desc} = "allowed to go on";
        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
        return \%my_return;

}
sub roll_to_get_check_result_of_this_level
{
	my ($this,$level) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}

	my $deploy_id = $this->{param}->{deploy_id};
	### ��ʼ��ʱ
        my ($max_time,$remind_time) = ();
        my $tmp_time1 = $this->{conf}->{cm_conf}->{level_control}->{$level}->{max_time};
        $max_time = $tmp_time1 * 60;
        my $tmp_time2 = $this->{conf}->{cm_conf}->{level_control}->{$level}->{remind_time};
        $remind_time = $tmp_time2 *60;
        my $remain_time = $tmp_time1 - $tmp_time2;
	my $start_time = time;
	my $deta_time = 0;
	my $end_time;
	my $check_ok_count;
	my $check_member_num = 2;
	my $json_obj = new JSON::XS;
	my $level_ifok;
        while($deta_time < $remind_time){
		### ��ȥ����������ɫrd��op�ļ����
                $return_detail = $this->scan_check_result_of_rd_qa_op($level);
		### $return_detail

		### Ȼ��ȡ��zk����Ϣ
		### $deploy_id
		### $level
	        $return_detail = get_zk_attr_info_api("$deploy_id","level_control.$level.check_status");
		### $return_detail
        	if("$return_detail->{value}" ne "0"){
                	$my_return{value} = 1;
	                $my_return{desc} = "fail to get check_status of $level,$return_detail->{desc}";
        	        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                	return \%my_return;
	        }else{
			chomp($return_detail->{desc});
			$return_detail = json_decode_api($return_detail->{desc});
			if("$return_detail->{value}" ne "0"){
				$my_return{desc} = $return_detail->{desc};
				$my_return{value} = 1;
				$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
				return \%my_return;
			}else{
				$level_zk_info = $return_detail->{desc};
			}
			$level_ifok = $level_zk_info->{ifok};
			### $level_ifok
			if(exists $LEVEL_STATUS{LEVEL_CHECK_END}->{$level_ifok}){
	                        $my_return{desc} = "level check status has an end";
	                        $my_return{value} = 0;
	                        $this->{logit}->printLog($this->{logit}->{NOTICE},\%retstr);
	                        return \%my_return;
	                }else{
				### �������������������ѭ��
		                sleep($SCAN_CHECK_RESULT_TIME);
	        	        $end_time = time;
	                	$deta_time = sprintf("%.1f", $end_time - $start_time);
			}
		}
	}
	### ����������ʱ��,�����Ŵߴٽ���Ч��ȷ��
	$deploy_id = $this->{param}->{deploy_id};
	my $module = $this->{param}->{module};
	my $message = "[������ʱ����]��ʣ $remain_time ����,��ʱ��ȷ��Ч�������Զ��ع�����icafe��[$deploy_id]";
	my $title = "$module [����֪ͨ]";
        my @rd_phone_list = @{$this->{conf}->{alarm_conf}->{v}->{DEFAULT}->{rd_phone}};
	my @to_be_phoned;
	my $level_check_status;
	push @to_be_phoned,@rd_phone_list;
        $return_detail = $this->send_message_to_member("$title","$message",\@to_be_phoned);

	$my_return{desc} = "remind rd to check";
        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);

	### �ٴο�ʼ��ʱ
        while($deta_time < $max_time){
                ### ��ȥ����������ɫrd��op�ļ����
                $return_detail = $this->scan_check_result_of_rd_qa_op($level);
                ### $return_detail

                ### Ȼ��ȡ��zk����Ϣ
                ### $deploy_id
                ### $level
                $return_detail = get_zk_attr_info_api("$deploy_id","level_control.$level.check_status");
                ### $return_detail
                if("$return_detail->{value}" ne "0"){
                        $my_return{value} = 1;
                        $my_return{desc} = "fail to get check_status of $level,$return_detail->{desc}";
                        $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                        return \%my_return;
                }else{
                        chomp($return_detail->{desc});
			$return_detail = json_decode_api($return_detail->{desc});
			if("$return_detail->{value}" ne "0"){
				$my_return{desc} = $return_detail->{desc};
				$my_return{value} = 1;
                        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
				return \%my_return;
			}else{
                        	$level_zk_info = $return_detail->{desc};
			}
                        $level_ifok = $level_zk_info->{ifok};
                        ### $level_ifok
                        if(exists $LEVEL_STATUS{LEVEL_CHECK_END}->{$level_ifok}){
                                $my_return{desc} = "level check status has an end";
                                $my_return{value} = 0;
                                $this->{logit}->printLog($this->{logit}->{NOTICE},\%retstr);
                                return \%my_return;
                        }else{
                                ### �������������������ѭ��
                                sleep($SCAN_CHECK_RESULT_TIME);
                                $end_time = time;
                                $deta_time = sprintf("%.1f", $end_time - $start_time);
                        }
                }
        }
	### ����������ʱ��,�����Ŵߴٽ���Ч��ȷ��
	$message = "[$module][�ȴ���鳬�� $tmp_time1 ����][��ֵ��op��ע,����ع�,���ֶ�����][$deploy_id]";
        $return_detail = send_msg_by_robot_api("$message");

	### ����check_status��desc�ֶ�Ϊtimed out
	$return_detail = add_zk_info_api($deploy_id,"$level_check_status.desc","timed out");
	$return_detail = add_zk_info_api($deploy_id,"$level_check_status.ifok","$CHECK_FAIL");
	if("$return_detail->{value}" ne "0"){
		$my_return{value} = 1;
		$my_return{desc} = "fail to update level_check_status";
                $this->{logit}->printLog($this->{logit}->{FATAL},\%my_return);
		return \%my_return;
	}else{
		$my_return{value} = 0;
		$my_return{desc} = "successfully roll to get ";
                $this->{logit}->printLog($this->{logit}->{NOTICE},\%my_return);
		return \%my_return;
	}
}
sub notice_rollback
{
	my ($this,$level) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}

	### ���������ʱ��	
	my $module = $this->{param}->{module};
	my $title = "[$module][�Զ��ع�֪ͨ]";
	my $message = "��Ч��ȷ�ϲ�ok��ʱ��Ҫ�ع�";

        ### �ȸ�hiȺ�����߳�ʱ����ͨ��
        $return_detail = send_msg_by_robot_api("[$message]");
	my @to_be_phoned;
	my @to_be_mailed;
	my @op_phone_list = @{$this->{conf}->{alarm_conf}->{v}->{DEFAULT}->{op_phone}};
	my @op_manage_phone_list = @{$this->{conf}->{alarm_conf}->{v}->{DEFAULT}->{op_manager_phone}};
	my @rd_manage_phone_list = @{$this->{conf}->{alarm_conf}->{v}->{DEFAULT}->{rd_manager_phone}};
	push @to_be_phoned,@op_phone_list;
        $return_detail = $this->send_message_to_member("$title","$message",\@to_be_phoned);

	### �����ʼ�ͨ��
	my @op_manage_email_list = @{$this->{conf}->{alarm_conf}->{v}->{DEFAULT}->{op_manager_email}};
	my @rd_manage_email_list = @{$this->{conf}->{alarm_conf}->{v}->{DEFAULT}->{rd_manager_email}};
	my @rd_email_list = @{$this->{conf}->{alarm_conf}->{v}->{DEFAULT}->{rd_email}};
	my @op_email_list = @{$this->{conf}->{alarm_conf}->{v}->{DEFAULT}->{op_email}};

	push @to_be_mailed,@rd_manage_email_list;
	push @to_be_mailed,@op_manage_email_list;
	push @to_be_mailed,@rd_email_list;
	push @to_be_mailed,@op_email_list;
	$return_detail = uniq_array_api(\@to_be_mailed);
	@to_be_mailed = @{$return_detail->{desc}};

	$title = "$module [�ع�ͨ��]";
	$message = "��Ч��ȷ�ϲ�ok��ʱ��Ҫ�ع�";
	### �����ʼ��������Ա
	### @to_be_mailed
        $return_detail = $this->send_mail_to_member("$title","$message",\@to_be_mailed);
	### $return_detail

}
sub scan_check_result_of_rd_qa_op 
{
	my ($this,$level) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $deploy_id = $this->{param}->{deploy_id};
	$return_detail = $this->scan_check_result_or_rd($level);
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}
	$return_detail = $this->scan_check_result_or_op($level);
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}
	my $json_obj = new JSON::XS;

	### ��ȡ����level��check_status��Ϣ
	$return_detail = get_zk_attr_info_api("$deploy_id","level_control.$level.check_status");

	my $level_check_status;
        chomp($return_detail->{desc});
	$return_detail = json_decode_api($return_detail->{desc});
	if("$return_detail->{value}" ne "0"){
		$my_return{desc} = $return_detail->{desc};
		$my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{
		$level_check_status = $return_detail->{desc};
	}
	my $op_ifok = $level_check_status->{member}->{op}->{ifok};
	my $rd_ifok = $level_check_status->{member}->{rd}->{ifok};
	if("$op_ifok" eq "$CHECK_OK" && "$rd_ifok" eq "$CHECK_OK"){
		$return_detail = add_zk_info_api("$deploy_id","level_control.$level.check_status.ifok","$CHECK_OK");
		### $return_detail
	}
	if("$op_ifok" eq "$CHECK_FAIL" || "$rd_ifok" eq "$CHECK_FAIL"){
		$return_detail = add_zk_info_api("$deploy_id","level_control.$level.check_status.ifok","$CHECK_FAIL");
		### $return_detail
	}
        $my_return{value} = 0;
        $my_return{desc} = "$return_detail->{desc}";
	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
        return \%my_return;
}
sub scan_check_result_or_rd
{
	my ($this,$level) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $json_obj = new JSON::XS;
	my $deploy_id = $this->{param}->{deploy_id};
	$return_detail = get_zk_attr_info_api($deploy_id,"level_control.$level.check_status");
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "$return_detail->{desc}";
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}

        chomp($return_detail->{desc});
	$return_detail = json_decode_api($return_detail->{desc});
	if("$return_detail->{value}" ne "0"){
		$my_return{desc} = $return_detail->{desc};
		$my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{
		$level_check_status = $return_detail->{desc};
	}


	### $level_check_status
	my @rd_list = keys %{$level_check_status->{member}->{rd}->{who}};
	### @rd_list
	my $rd_num = scalar @rd_list;
	my $total_if_ok = $level_check_status->{member}->{rd}->{ifok};
	my $member_if_ok;
	my $check_ok_count = 0;
	my $check_done_count = 0;
	foreach (@rd_list){
		$member_if_ok = $level_check_status->{member}->{rd}->{who}->{$_}->{ifok};
		if("$member_if_ok" eq ""){
			next;
		}elsif("$member_if_ok" eq "$CHECK_OK"){
			### �����ǰ��member���ok���������+1
			$check_ok_count++;
			$check_done_count++;
		}elsif("$member_if_ok" eq "$CHECK_FAIL"){
			$check_done_count++;
		}
	}
	if($check_ok_count == $rd_num){
		### ���RD����Ŀ���ڼ��ok��rd��Ŀ������Ϊ�����ok
		$return_detail = add_zk_info_api($deploy_id,"level_control.$level.check_status.member.rd.ifok",$CHECK_OK);
		if("$return_detail->{value}" ne "0"){
		        $my_return{value} = 1;
		        $my_return{desc} = "fail to update rd.ifok,$return_detail->{desc}";
			$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		        return \%my_return;
		}else{
			$my_return{value} = 0;
			$my_return{desc} = "got rd check result,$CHECK_OK";
			$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
			return \%my_return;
		}
	}
	if($check_done_count == $rd_num){
		if($check_ok_count == $rd_num){
			### ���RD����Ŀ���ڼ��ok��rd��Ŀ������Ϊ�����ok
			$return_detail = add_zk_info_api($deploy_id,"level_control.$level.check_status.member.rd.ifok",$CHECK_OK);
			if("$return_detail->{value}" ne "0"){
			        $my_return{value} = 1;
			        $my_return{desc} = "fail to update rd.ifok,$return_detail->{desc}";
				$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			        return \%my_return;
			}
		}else{
			### ������ڼ��ʧ�ܵ���Ŀ������Ϊrd�Ǽ��ʧ��
			$return_detail = add_zk_info_api($deploy_id,"level_control.$level.check_status.member.rd.ifok",$CHECK_FAIL);
			if("$return_detail->{value}" ne "0"){
			        $my_return{value} = 1;
			        $my_return{desc} = "fail to update rd.ifok,$return_detail->{desc}";
				$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			        return \%my_return;
			}
		}	
		$my_return{value} = 0;
		$my_return{desc} = "got rd check result";
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
		return \%my_return;
		
	}else{
		$my_return{value} = 1;
		$my_return{desc} = "not all rd checked";
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}
		
}
sub scan_check_result_or_op
{
	my ($this,$level) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $deploy_id = $this->{param}->{deploy_id};
	### 
	#$return_detail = get_check_result_from_dk_api($deploy_id,$level);
	#my $xpp_url = "http://cq01-archer.cq01.baidu.com:8080/auto-deploy/index/xpp.php?&id=$deploy_id";
	my $xpp_url = "http://cq01-archer.cq01.baidu.com:8374/op-check.res.json";
	$return_detail = add_zk_info_api($deploy_id,"level_control.$level.check_status.member.op.report_url","$xpp_url");
	$return_detail = add_zk_info_api($deploy_id,"level_control.$level.check_status.member.op.ifok",$CHECK_OK);
	$my_return{desc} = "xpp,to get dk result";
	$my_return{value} = 0;
	return \%my_return;
}
sub scan_level_deploy_status_for_this_level
{
	my ($this,$level) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $deploy_id = $this->{param}->{deploy_id};
	my $idc_control = $this->{conf}->{cm_conf}->{level_control}->{$level}->{idc};
	my ($idc,$ifdo,$level_status,$idc_status,$count,$idc_num) = ();
	my $level_end_status = $LEVEL_STATUS{LEVEL_DEPLOY_END};
	my $idc_end_status = $IDC_STATUS{IDC_DEPLOY_END};
	my $level_zk_info;
	my $json_obj = new JSON::XS;
	my @idc_array;
	$return_detail = get_zk_attr_info_api("$deploy_id","level_control.$level");
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "fail to get now_status of $idc,$return_detail->{desc}";
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}else{

	        chomp($return_detail->{desc});
		$return_detail = json_decode_api($return_detail->{desc});
		if("$return_detail->{value}" ne "0"){
			$my_return{desc} = $return_detail->{desc};
			$my_return{value} = 1;
	        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}else{
			$level_zk_info = $return_detail->{desc};
		}



		@idc_array = keys %{$level_zk_info->{idc}};
		$level_status = $level_zk_info->{now_status};
	}
	

	my $now_time;
	my $deta_time;
	$idc_num = scalar @idc_array;
	my %done_idc;
	my $deploy_end_count = 0;
	my $deploy_fail_count = 0;
	while($deploy_end_count < $idc_num){
		### ֻҪ���л�����û�������finish or cancle,��һֱѭ��
		### �����������
		foreach $idc (@idc_array){
			if(exists $done_idc{$idc}){
				next;
			}
			$idc_status = $level_zk_info->{idc}->{$idc}->{now_status};
			$taskid = $level_zk_info->{idc}->{$idc}->{task}->{id};
			
			if(!exists $idc_end_status->{$idc_status}){
				### �����ǰ������û������ϣ���ȥ�����ִ��״̬
				$return_detail = $this->check_and_update_deploy_status_for_this_idc($level,$idc,$taskid);
			}else{
				### �����ǰ������������ˣ��򽫵�ǰ�������뵽done��hash��
				$done_idc{$idc} = "$idc_status";

				### ��һ�������������֮�󣬼�¼ʱ��
				$now_time = get_now_time_api();
				$this->{time}->{level_control}->{$level}->{idc}->{$idc}->{end_time} = time;
				$deta_time = sprintf("%.1f", ($this->{time}->{level_control}->{$level}->{idc}->{$idc}->{end_time} - $this->{time}->{level_control}->{$level}->{idc}->{$idc}->{start_time}) / 60);
				add_zk_info_api($deploy_id,"level_control.$level.idc.$idc.deploy_time","$deta_time");
				add_zk_info_api($deploy_id,"level_control.$level.idc.$idc.end_time","$now_time");

				### ���Ϊ����������תʧ��״̬���������+1
				if(exists $IDC_DEPLOY_FAIL{$idc_status}){
					$deploy_fail_count++;
				}
				### ����ǰ�������������
				$return_detail = $this->check_out_mutex_token_for_this_idc($level,$idc);
				if("$return_detail->{value}" ne "0"){
					$my_return{desc} = "failed to check out mutex_token for $level.$idc,$return_detail->{desc}";
        				$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
				}else{
					$my_return{desc} = "check out mutex token for $level.$idc ok";
        				$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
				}
			}
		
		}
		$deploy_end_count = scalar keys %done_idc;
		sleep($SCAN_IDC_INTERVAL);
		$return_detail = get_zk_attr_info_api("$deploy_id","level_control.$level");
		if("$return_detail->{value}" ne "0"){
		        $my_return{value} = 1;
		        $my_return{desc} = "fail to get now_status of $idc,$return_detail->{desc}";
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		        return \%my_return;
		}else{
	        	chomp($return_detail->{desc});
			$return_detail = json_decode_api($return_detail->{desc});
			if("$return_detail->{value}" ne "0"){
				$my_return{desc} = $return_detail->{desc};
				$my_return{value} = 1;
	        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
				return \%my_return;
			}else{
				$level_zk_info = $return_detail->{desc};
				$level_status = $level_zk_info->{now_status};
			}

		}

	}
	if($deploy_fail_count == 0){
		$level_status = $LEVEL_DEPLOY_OK;
	}else{
		$level_status = $LEVEL_DEPLOY_FAIL;
		
	}
	$return_detail = &add_zk_info_api($deploy_id,"level_control.$level.now_status","$level_status");
	if("$return_detail->{value}" ne "0"){
		$my_return{value} = 1;
		$my_return{desc} = "fail to update $level.now_status,$return_detail->{desc}";
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{
		$my_return{value} = 0;
		$my_return{desc} = "successfully updated $level.now_status";
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
		return \%my_return;
	}
	
}
sub check_and_update_deploy_status_for_this_idc
{
	my ($this,$level,$idc,$taskid) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $deploy_id = $this->{param}->{deploy_id};
	$return_detail = check_archer_status_api($taskid);
	if("$return_detail->{value}" ne "0"){
		$my_return{desc} = "$return_detail->{desc}";
		$my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{
		my $now_status = $return_detail->{desc};
		chomp($now_status);
		$return_detail = &add_zk_info_api($deploy_id,"level_control.$level.idc.$idc.now_status","$now_status");
		if("$return_detail->{value}" ne "0"){
			$my_return{desc} = "fail to write $level.idc.$idc.now_status=$now_status,$return_detail->{desc} ";
			$my_return{value} = 1;
	        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}else{
			$my_return{desc} = "successfully updated $level.now_status=$now_status";
			$my_return{value} = 0;
		        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
			return \%my_return;
		}
	}

}

sub trigger_and_deploy_this_level
{
	my ($this,$level) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $deploy_id = $this->{param}->{deploy_id};
	my $idc_control = $this->{conf}->{cm_conf}->{level_control}->{$level}->{idc};
	my @idc_array = keys %$idc_control;
	my ($idc,$ifdo,$level_status,$idc_status,$idc_mutex_token,$module_mutex_token,$count,$idc_num) = ();
	my $level_end_status = $LEVEL_STATUS{LEVEL_TRIGGER_END};

	my $level_zk_info;
	my $json_obj = new JSON::XS;
	$module_mutex_token = $this->{conf}->{cm_conf}->{basic_info}->{module_mutex_token};

	$return_detail = get_zk_attr_info_api("$deploy_id","level_control.$level");
	if("$return_detail->{value}" ne "0"){
	        $my_return{value} = 1;
	        $my_return{desc} = "fail to get now_status of $idc,$return_detail->{desc}";
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
	        return \%my_return;
	}else{

        	chomp($return_detail->{desc});
		$return_detail = json_decode_api($return_detail->{desc});
		if("$return_detail->{value}" ne "0"){
			$my_return{desc} = $return_detail->{desc};
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}else{
			$level_zk_info = $return_detail->{desc};
			$level_status = $level_zk_info->{now_status};
		}


	}
	
	while(!exists $level_end_status->{$level_status}){
		### ֻҪ��ǰlevel��û�е��ﴥ��������״̬����ô�ͼ�������
		$idc_num = scalar @idc_array;
		$count = 0;
		### �����������
		foreach $idc (@idc_array){
			$ifdo = $idc_control->{$idc}->{ifdo};
			if("$ifdo" eq "no" || "ifdo" eq ""){ 
				### ���ifdoΪno������Ҫ�����˻������������һ��,�Ҹû������������
				$count++;
				next;
			}

			$idc_status = $level_zk_info->{idc}->{$idc}->{now_status};
			
			if(exists $IDC_STATUS{IDC_TRIGGER_END}->{$idc_status}){
				### ���������״̬���ڴ���END��״̬����ô��ѽ�ٷֱ��ж�����fail����ȫ����
				### $idc_status
				if("$idc_status" eq "$IDC_TRIGGER_FAIL"){
					### һ����һ����������ʧ�ܣ���ô�Ͳ��ܼ�����,��Ҫдlevel.now_statusΪtrigger_fail
					$level_status = $LEVEL_TRIGGER_FAIL;
					$return_detail = &add_zk_info_api($deploy_id,"level_control.$level.now_status",$level_status);
					if("$return_detail->{value}" ne "0"){
						$my_return{value} = 1;
						$my_return{desc} = "failed to write $level.now_status=$LEVEL_TRIGGER_FAIL,$return_detail->{desc}";
	        				$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
						return \%my_return;
					}else{
						$my_return{desc} = "$idc.now_status=$IDC_TRIGGER_FAIL";
	        				$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
						#last;
					}
					### ͬʱ��Ҫ����ǰ�������������,�ڴ���ʧ�ܵ�������Ҫ������������
					$return_detail = $this->check_out_mutex_token_for_this_idc($level,$idc);
					if("$return_detail->{value}" ne "0"){
						$my_return{desc} = "failed to check out mutex_token for $level.$idc,$return_detail->{desc}";
	        				$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
					}else{
						$my_return{desc} = "check out mutex token for $level.$idc ok";
	        				$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
					}
				}
				if("$idc_status" eq "$IDC_TRIGGER_OK"){
					### ���������������ɹ�����ô�Ͱѳɹ�������+1,������һ������
					$count++;
					next;
				}
				
			}else{
				### ֻҪ�ú����Լ�ȥд״̬�����ɣ�����һ��ѭ�����ڻ�ȡһ�μ���
				$return_detail = $this->check_in_mutex_and_trigger_this_idc($level,$idc);
				### $return_detail

			}
		
		}
		if($count == $idc_num){
			$return_detail = &add_zk_info_api($deploy_id,"level_control.$level.now_status","$LEVEL_TRIGGER_OK");
			if("$return_detail->{value}" ne "0"){
				$my_return{value} = 1;
				$my_return{desc} = "fail to update $level.now_status,$return_detail->{desc}";
        			$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
				return \%my_return;
			}else{
				$my_return{desc} = "all idc triggered ok,and write zk success";
        			$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
				#last;
			}
		}
		sleep($SCAN_IDC_INTERVAL);

		$return_detail = get_zk_attr_info_api("$deploy_id","level_control.$level");
		if("$return_detail->{value}" ne "0"){
		        $my_return{value} = 1;
		        $my_return{desc} = "fail to get $idc.now_status,$return_detail->{desc}";
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		        return \%my_return;
		}else{
        		chomp($return_detail->{desc});
			$return_detail = json_decode_api($return_detail->{desc});
			if("$return_detail->{value}" ne "0"){
				$my_return{desc} = $return_detail->{desc};
				$my_return{value} = 1;
        			$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
				return \%my_return;
			}else{
				$level_zk_info = $return_detail->{desc};
				$level_status = $level_zk_info->{now_status};
			}
		}
	}
	### ��ǰlevelΪ����END״̬
	$my_return{value} = $level_end_status->{$level_status}->{value};
	$my_return{desc} .= "$level_end_status->{$level_status}->{desc}";
        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	return \%my_return;
}
sub check_out_mutex_token_for_this_idc
{
	my ($this,$level,$idc) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $idc_mutex_token = $this->{conf}->{cm_conf}->{level_control}->{$level}->{idc}->{$idc}->{idc_mutex_token};
	$return_detail = check_out_mutex_token_api($idc_mutex_token);
	if("$return_detail->{value}" ne "0"){
		$my_return{value} = 1;
		$my_return{desc} = $return_detail->{desc};
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{
		$my_return{value} = 0;
		$my_return{desc} = $return_detail->{desc};
        	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
		return \%my_return;
	}
}
sub check_in_mutex_and_trigger_this_idc
{
	my ($this,$level,$idc) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	my $now_time;
	my $now_time_s;
	my $data_time;
	my $time_info = $this->{time}->{level_control}->{$level}->{idc}->{$idc};
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $idc_mutex_token = $this->{conf}->{cm_conf}->{level_control}->{$level}->{idc}->{$idc}->{idc_mutex_token};
	my $deploy_id = $this->{param}->{deploy_id};

	### ȥΪ��ǰ��idc��������
	### $idc_mutex_token
	### $deploy_id
        $return_detail = check_in_mutex_token_api($idc_mutex_token,$idc_mutex_token,$deploy_id);
        if("$return_detail->{value}" ne "0"){
		### �������������ֱ�ӷ���
		$my_return{value} = 1;
		$my_return{desc} = "$return_detail->{desc}";
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}
	### $return_detail

	### ��������֮�󣬼�¼ʱ��
	$now_time = get_now_time_api();
	$now_time_s = time;
	$this->{time}->{level_control}->{$level}->{idc}->{$idc}->{start_time} = time;
	add_zk_info_api($deploy_id,"level_control.$level.idc.$idc.start_time","$now_time");	


	### �ߵ��ⲽ˵����������,�Ƚ���ǰ������now_status��Ϊtrigger_ing״̬
	$return_detail = &add_zk_info_api($deploy_id,"level_control.$level.idc.$idc.now_status","$IDC_TRIGGER_ING");
	if("$return_detail->{value}" ne "0"){
		$my_return{desc} = $return_detail->{desc};
		$my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{
		$my_return{desc} = "set $level.idc.$idc.now_status=$IDC_TRIGGER_ING";
        	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	}
	my $param_list = $this->{conf}->{cm_conf}->{level_control}->{$level}->{idc}->{$idc}->{param_list}->{file};

	### �޳����ϻ���,֮���Էŵ��ⲽ,��Ϊ�˱��������޳����ϻ���֮���һ��ʱ���ڹ��ϻ����ָ���
	my $servers_des = $this->{conf}->{cm_conf}->{level_control}->{$level}->{idc}->{$idc}->{param_list}->{content}->{servers_des};
	$return_detail = $this->delete_badhost($level,$idc,$servers_des);
	%my_return = %{$return_detail};
	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);

	### ����archer����
	$return_detail = trigger_archer_api($param_list);
	if("$return_detail->{value}" ne "0"){
		### �������ʧ�ܣ�����д״̬������trigger_failд��ȥ
		$return_detail = &add_zk_info_api($deploy_id,"level_control.$level.idc.$idc.now_status","$IDC_TRIGGER_FAIL");
	}else{
		### ��������ɹ�����trigger_okд��ȥ,ͬʱ��¼taskid
		my $taskid = $return_detail->{desc};
		$return_detail = $this->update_info_after_trigger_ok_for_this_idc($level,$idc,$taskid);
		$my_return{desc} = "$idc trigger ok";
	        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	}

	if("$return_detail->{value}" ne "0"){
		$my_return{desc} = "$return_detail->{desc}";
		$my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}
	$my_return{desc} = "$return_detail->{desc}";
	$my_return{value} = 0;
        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	return \%my_return;
}	

sub delete_badhost
{
	my ($this,$level,$idc,$servers_des) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $deploy_id = $this->{param}->{deploy_id};
	#my $if_check_badhost_service = $this->{conf}->{cm_conf}->{basic_info}->{if_check_badhost_service};
	my $if_check_badhost_service = $this->{conf}->{cm_conf}->{basic_info}->{check_badhost_service};
	my $badhost_idc = $this->{conf}->{cm_conf}->{level_control}->{$level}->{idc}->{$idc}->{badhost_idc};
	my $badhost_module = $this->{conf}->{cm_conf}->{basic_info}->{badhost_module};
	### $if_check_badhost_service
	### $badhost_idc
	### $badhost_module
	$return_detail = call_delete_badhost_api($badhost_module,$badhost_idc,$if_check_badhost_service,$servers_des);
	if("$return_detail->{value}" ne "0"){
		$my_return{value} = 1;
		$my_return{desc} = "$return_detail->{desc}";
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{
		$my_return{value} = 0;
		$my_return{desc} = "$return_detail->{desc}";
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
		return \%my_return;
	}
}

sub update_info_after_trigger_ok_for_this_idc
{
	my ($this,$level,$idc,$taskid) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $deploy_id = $this->{param}->{deploy_id};
	my $deploy_method = $this->{conf}->{cm_conf}->{basic_info}->{deploy_method};
	my $api_list = $API_DESC{$deploy_method}->{api};
	my $process_url = "$api_list->{process_url}->{str}" . "&listid=$taskid";
	my $status_url = "$api_list->{status_url}->{str}" . "&id=$taskid";
	my $redo_url = "http://yf-psop-deploy01.yf01.baidu.com:8080/auto-deploy/index/control_archer.php?" . "&id=$taskid" . "&action=redo";
	my $skip_url = "http://yf-psop-deploy01.yf01.baidu.com:8080/auto-deploy/index/control_archer.php?" . "&id=$taskid" . "&action=skip";
	my $pause_url = "http://yf-psop-deploy01.yf01.baidu.com:8080/auto-deploy/index/control_archer.php?" . "&id=$taskid" . "&action=pause";

	### ����ǰ��archer����push��all_task_id��ȥ,�Ա�����api���Ա�ݵػ�ȡ����
	$return_detail = &add_zk_info_api($deploy_id,"all_task_id.$taskid",$idc);
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "$return_detail->{desc}";
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
        }

	### ����ǰ������now_status��Ϊtrigger_ok
	$return_detail = &add_zk_info_api($deploy_id,"level_control.$level.idc.$idc.now_status","$IDC_TRIGGER_OK");
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "$return_detail->{desc}";
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
        }
	### ��archer����д�뵽task.id��
	$return_detail = &add_zk_info_api($deploy_id,"level_control.$level.idc.$idc.task.id",$taskid);
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "$return_detail->{desc}";
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
        }
	### ��archer�Ľ���urlд�뵽task.process_url��
	$return_detail = &add_zk_info_api($deploy_id,"level_control.$level.idc.$idc.task.process_url",$process_url);
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "$return_detail->{desc}";
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
        }
	$return_detail = &add_zk_info_api($deploy_id,"level_control.$level.idc.$idc.task.status_url",$status_url);
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "$return_detail->{desc}";
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
        }
	$return_detail = &add_zk_info_api($deploy_id,"level_control.$level.idc.$idc.task.redo_url",$redo_url);
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "$return_detail->{desc}";
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
        }
	$return_detail = &add_zk_info_api($deploy_id,"level_control.$level.idc.$idc.task.skip_url",$skip_url);
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "$return_detail->{desc}";
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
        }
	$return_detail = &add_zk_info_api($deploy_id,"level_control.$level.idc.$idc.task.pause_url",$pause_url);
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "$return_detail->{desc}";
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
        }
        $my_return{value} = 0;
        $my_return{desc} = "successfully updated info after trigger ok for $level.$idc";
        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
        return \%my_return;
	
}
sub trigger_check_for_this_level
{
	my ($this,$level) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $deploy_id = $this->{param}->{deploy_id};
	my $module = $this->{param}->{module};
        my @rd_phone_list = @{$this->{conf}->{alarm_conf}->{v}->{DEFAULT}->{rd_phone}};
        my @to_be_phoned = (); 
        push @to_be_phoned,@rd_phone_list;
	my $title = "[$module]";
	my $message = "[$level ���,����ȫ�ֽ��������ϵ��ȷ��Ч��][$deploy_id]";

	my $check_ok_url = "level_control";
	### ѭ����ʼ�����url
	my $rd_email = $this->{conf}->{alarm_conf}->{v}->{DEFAULT}->{rd_email};
	my $check_ok_url;
	my $check_fail_url;
	my @tmp_array;
	foreach (@$rd_email){
                @tmp_array = split(/@/,$_);
                $member = $tmp_array[0];
		$check_ok_url = "http://yf-psop-deploy01.yf01.baidu.com:8080/auto-deploy/index/check_result/check.php?deploy_id=$deploy_id&deploy_key=level_control.$level.check_status.member.rd.who.$member&deploy_result=$CHECK_OK&username=$member";
		$check_fail_url = "http://yf-psop-deploy01.yf01.baidu.com:8080/auto-deploy/index/check_result/check.php?deploy_id=$deploy_id&deploy_key=level_control.$level.check_status.member.rd.who.$member&deploy_result=$CHECK_FAIL&username=$member";
		$return_detail = add_zk_info_api($deploy_id,"level_control.$level.check_status.member.rd.who.$member.check_ok_url","$check_ok_url");
		$return_detail = add_zk_info_api($deploy_id,"level_control.$level.check_status.member.rd.who.$member.check_fail_url","$check_fail_url");
	}

	### ����ֻ��Ҫ����Ӧ��RD���ͼ��֪ͨ
	$return_detail = $this->send_message_to_member("$title","$message",\@to_be_phoned);

	### ����QA�ļ��ӿ�
	$return_detail = $this->trigger_qa_check($level);
	### $return_detail

	### ����OP�ļ��ӿ�
	### $return_detail = $this->trigger_op_check($level);
	$my_return{desc} = "trigger check ok";
	$my_return{value} = 0;
        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	return \%my_return;
	
}
sub trigger_op_check
{
	my ($this,$level) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	print "xpp,todo\n";
	$my_return{value} = 0;
	$my_return{desc} = "successfully triggered op check";
	return \%my_return;
}
sub trigger_qa_check
{
	my ($this,$level) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $deploy_id = $this->{param}->{deploy_id};
	my $json_obj = new JSON::XS;
	my $return_hash;
	my $module = $this->{param}->{module};
	my $task_id_list = $QA_CHECK_MAP{$module};
	### $task_id_list
	### trigger_all_qa_task
	$return_detail = $this->trigger_all_qa_task($level,$task_id_list);
	if("$return_detail" ne "0"){
		$my_return{desc} = $return_detail->{desc};
		$my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{
		$my_return{desc} = $return_detail->{desc};
		$my_return{value} = 0;
        	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
		return \%my_return;
	}
}
sub trigger_all_qa_task
{
	my ($this,$level,$task_id_list) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	### ѭ���������е�taskid
	my $fail_task_count = 0;
	my $return_hash;
	my $deploy_id = $this->{param}->{deploy_id};
	foreach my $task_id (@{$task_id_list}){
		### ����qa�ļ��api
		$return_detail = call_qa_check_api($task_id);
		### $return_detail
		if("$return_detail->{value}" ne "0"){
			### $task_id
			### ��id���ʧ��
			$fail_task_count++;
			next;
		}
		chomp($return_detail->{desc});
		$return_hash = $return_detail->{desc};
		### �鿴 call_qa_check_api���صĽ��
		print Dumper($return_detail->{desc});
		#$return_detail = json_decode_api($return_detail->{desc});
#		if("$return_detail->{value}" ne "0"){
#			$my_return{desc} = $return_detail->{desc};
#			$my_return{value} = 1;
#			$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
#			return \%my_return;
#		}else{
#			$return_hash = $return_detail->{desc};
#		}

		### $return_hash
		my $group_id = $return_hash->{result}->{group_id};
		my $group_report_id = $return_hash->{result}->{group_report_id};
		my $group_report_page = "$return_hash->{result}->{group_report_page}";

		### �Ƚ�taskidд��zk��
		my $key_str = "level_control.$level.check_status.member.qa.report_list.task_id.$task_id";
		$return_detail = add_zk_info_api($deploy_id,"$key_str",'{}');
		if("$return_detail->{value}" ne "0"){
			$my_return{desc} = "failed to write taskid into zk,$return_detail->{desc}";
			$my_return{value} = 1;
			$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		
		}else{
			$my_return{desc} = "successfully added taskid";
			$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
		}


		### �ٽ�groupidд�뵽zk��
		$return_detail = add_zk_info_api($deploy_id,"$key_str.group_id",$group_id);
		if("$return_detail->{value}" ne "0"){
			$my_return{desc} = "failed to update group_id of qa check,$return_detail->{desc}";
			$my_return{value} = 1;
			$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		### �ٽ�group_report_idд�뵽zk��
		$return_detail = add_zk_info_api($deploy_id,"$key_str.group_report_id",$group_report_id);	
		if("$return_detail->{value}" ne "0"){
			$my_return{desc} = "failed to update group_report_id of qa check,$return_detail->{desc}";
			$my_return{value} = 1;
			$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		### �ٽ�group_report_pageд�뵽zk��
		$return_detail = add_zk_info_api($deploy_id,"$key_str.group_report_page",$group_report_page);	
		if("$return_detail->{value}" ne "0"){
			$my_return{desc} = "failed to update group_report_page of qa check,$return_detail->{desc}";
			$my_return{value} = 1;
			$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
	}
	if($fail_task_count > 0){
		$my_return{desc} = "failed to trigger some task trigger";
		$my_return{value} = 1;
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{
		$my_return{desc} = "trigger qa check ok";
		$my_return{value} = 0;
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
		return \%my_return;
	}
}
sub xpp
{
	my ($this) = @_;
	my %my_return;
	my $return_detail;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
}


1;
