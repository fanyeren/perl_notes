package archer_bm::get_shangxian_info_bm;
BEGIN
{
	use Exporter();
	use vars qw($VERSION @ISA @EXPORT);
	use Data::Dumper;
	use File::Basename;
	use Fcntl qw(:flock);
	use FindBin qw($Bin);
	use lib "$Bin/../lib";
	use lib "$Bin/../conf";
	use lib "$Bin/../tools";
	use lib "$Bin/../../../public/alarm_api/perl/";
	use lib "$Bin/../../public/lib";

	use Time::HiRes qw(time);
#	use Smart::Comments;
	use CONFIG;
	use JSON::XS;
	use POSIX;
#	use archer_bm::Common;
	use Common;
	use Alarm;
	use strict;
	use warnings;
	use Switch;
	@ISA = qw(Exporter);
	@EXPORT = qw (
		);
}


sub new 
{
	my ($type,$logit,$param) = @_;
	$this->{logit} = $logit;
	$this->{param} = $param;
	bless $this;
	$this->{logit}->{conf}->{printStd} = 0;
	return $this;
}
sub goto_work
{
        my ($this,$input_param_list) = @_;
        my $return_detail;
        my %my_return; 
	my @to_check_item;
	my $function;
	my $param_str;
	foreach (@_){

		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	#print "this is in goto work \n";
	### �Ƚ��в������
	$return_detail = $this->check_param_before_goto_work($input_param_list);
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "param check fail: $return_detail->{desc}";
                $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
        }else{
                $my_return{value} = 0;
                $my_return{desc} = "param check ok: $return_detail->{desc}";
                $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	}
	### �ٶ� icafe_table �� base_info ������װ��������Ҫʹ�õ� delivery.conf �� alarm.conf
	$return_detail = $this->get_conf_file_and_trigger_BM();
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "$return_detail->{desc}";
                $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
        }else{
                $my_return{value} = 0;
                $my_return{desc} = "$return_detail->{desc}";
                $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
                return \%my_return;
	}

}
sub get_conf_file_and_trigger_BM
{
        my ($this) = @_;
        my $return_detail;
        my %my_return; 
	my $param_str;
	foreach (@_){

		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $dest_dir = $this->{param}->{dest_dir};
	my $base_info = $this->{param}->{base_info};
	my $icafe_table = $this->{param}->{icafe_table};
	my $module_of_base_info = $this->{conf}->{base_info}->{v}->{DEFAULT}->{module};
	### xpp this is to see base_info
	#print Dumper($this->{conf}->{base_info});
	my $module_of_icafe_table;
	my $version;

	### ���ģ���Ƿ�ƥ��
	my $module_list = $this->{conf}->{icafe_table}->{msg}->{module_list};
	my $processId = $this->{conf}->{icafe_table}->{msg}->{processId};
	#print Dumper($module_list);
	my $module_num = scalar @{$module_list};
	#print "module_num = $module_num\n";
	if("$module_num" ne "1"){
		$my_return{desc} = "I can only process 1 module";
		$my_return{value} = 1;
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{
		foreach my $module_and_version (@{$module_list}){
			#print Dumper($module_and_version);
			$module_of_icafe_table = $module_and_version->{module};
			$version = $module_and_version->{module_version};
			#print "module_of_icafe_table=$module_of_icafe_table , module_of_base_info=$module_of_base_info \n";
			if("$module_of_icafe_table" ne "$module_of_base_info"){
				$my_return{desc} = "sorry,module does not equal";
				$my_return{value} = 1;
				$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
				return \%my_return;
			}

		}
	}
	### ��������ʹ�õ� delivery.conf
	my $version_dir = "$dest_dir/shangxian/$version";
	my $now_dir = "$dest_dir/shangxian/now";
	`mkdir -p $now_dir`;
	`mkdir -p $version_dir`;
	my $delivery_conf = "$version_dir/delivery.conf";
	`cp $base_info $delivery_conf`;
	`echo "version=$version" >> $delivery_conf`;
	`echo "icafe=$processId" >> $delivery_conf`;
	$my_return{desc} = "successfully build the delivery.conf";
	$my_return{value} = 0;
	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);

	### ��������ʹ�õ� alarm.conf
	my $alarm_conf = "$version_dir/alarm.conf";
	my $processUsers = $this->{conf}->{icafe_table}->{msg}->{processUsers};
	my $users;
	my $rd_name;
	my $rd_phone;
	my @rd_name_list;
	my @rd_phone_list;
	foreach my $processUser (@{$processUsers}){
		if("$processUser->{activityName}" eq "tianxiebiaodan"){
			$users = $processUser->{users};
			foreach my $user (@${users}){
				$rd_name = $user->{name};
				$rd_phone = $user->{phone};
				push @rd_name_list,$rd_name;
				push @rd_phone_list,$rd_phone;
			}
		
		}
	}
	`echo "[DEFAULT]" > $alarm_conf`;
	`echo "rd_email=<<EOT" >> $alarm_conf`;
	foreach (@rd_name_list){
		`echo "$_\@baidu.com" >> $alarm_conf`;
	}
	`echo "EOT" >> $alarm_conf`;

	`echo "rd_phone=<<EOT" >> $alarm_conf`;
	foreach (@rd_phone_list){
		`echo "$_" >> $alarm_conf`;
	}
	`echo "EOT" >> $alarm_conf`;
	$my_return{desc} = "successfully build the alarm.conf";
	$my_return{value} = 0;
	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);

	### ��level.confŲ����version_dir����
	my $level_conf = $this->{param}->{level_conf};
	`cp $level_conf $version_dir`;

	$my_return{desc} = "successfully build all the conf files for archer";
	$my_return{value} = 0;
	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);

	`cp -rf $version_dir/* $now_dir`;
	### ���ô�BM
	my $cm_conf = $this->{param}->{cm_conf};
	#$return_detail = &call_BM_deploy_api($module_of_icafe_table,$delivery_conf,$level_conf,$alarm_conf);
	#$return_detail = &call_archer_bm_deploy_api($module_of_icafe_table,$delivery_conf,$level_conf,$alarm_conf,$cm_conf);
	$return_detail = $this->call_archer_bm_deploy($module_of_icafe_table,$level_conf,$alarm_conf,$cm_conf);
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "$return_detail->{desc}";
                $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
        }else{
                $my_return{value} = 0;
                $my_return{desc} = "trigger BM ok";
                $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
                return \%my_return;
	}



}
sub call_archer_bm_deploy
{
	my ($this,$module,$level_conf,$alarm_conf,$cm_conf) = @_;
        my $return_detail;
        my %my_return; 
	my @to_check_item;
	my $function;
	my $param_str;
	foreach (@_){

		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $processId = $this->{conf}->{icafe_table}->{msg}->{processId};
	#my $deploy_id = `date +%s`;
	my $deploy_id = $processId;
	chomp $deploy_id;
	print "check this url : \n";
	print "http://yf-psop-deploy01.yf01.baidu.com:8080/auto-deploy/index/index.php?&id=$deploy_id \n";
	print "log path is : yf-psop-deploy01.yf01:/home/work/auto-deploy/archer/bm/log/log.$deploy_id \n";
	$return_detail = &call_archer_bm_deploy_api($deploy_id,$module,$level_conf,$alarm_conf,$cm_conf);
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "$return_detail->{desc}";
                $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
        }else{
                $my_return{value} = 0;
                $my_return{desc} = "trigger BM ok";
                $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
                return \%my_return;
	}
}
sub check_param_before_goto_work
{
        my ($this,$input_param_list) = @_;
        my $return_detail;
        my %my_return; 
	my @to_check_item;
	my $function;
	my $param_str;
	foreach (@_){

		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}

	#print Dumper($this);
    	### �ȼ����Ҫ����Ĳ������Ƿ񶼸�ֵ��
        @to_check_item = keys %GET_SHANGXIAN_INFO_LONG_VALUE;
        $return_detail = check_is_item_in_hash_api(\@to_check_item, $input_param_list);
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "param check fail: $return_detail->{desc}";
                $this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
                return \%my_return;
        }
	
	my $cm_conf = $this->{param}->{cm_conf};
	$return_detail = $this->check_cm_conf($cm_conf);
	if("$return_detail->{value}" ne "0"){
	        $my_return{desc} = "fail to check $cm_conf,$return_detail->{desc}";
	        $my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}
	
	### ��� icafe_table �Լ����صĹ���
	my $icafe_table = $this->{param}->{icafe_table};
	$return_detail = $this->check_icafe_table($icafe_table);
	if("$return_detail->{value}" ne "0"){
	        $my_return{desc} = "fail to check $icafe_table,$return_detail->{desc}";
	        $my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
		
	}

	### ��� base_info �Լ����صĹ���
	my $base_info = $this->{param}->{base_info};
	$return_detail = $this->check_base_info($base_info);
	if("$return_detail->{value}" ne "0"){
	        $my_return{desc} = "fail to check $base_info,$return_detail->{desc}";
	        $my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}

	### ��� level.conf �Ĵ�����
	my $level_conf = $this->{param}->{level_conf};
	$return_detail = &check_file_exists_api($level_conf);
	if("$return_detail->{value}" ne "0"){
	        $my_return{desc} = "$return_detail->{desc}";
	        $my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}
	
	

	### ��� dest_dir �Ƿ����
	my $dest_dir = $this->{param}->{dest_dir};
	$return_detail = $this->check_dest_dir($dest_dir);
	if("$return_detail->{value}" ne "0"){
	        $my_return{desc} = "$return_detail->{desc}";
	        $my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}
	

        $my_return{value} = 0;
        $my_return{desc} = "param check ok";
        $this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
        return \%my_return;

}
sub check_dest_dir
{
	my ($this,$dest_dir) = @_;
	my $return_detail;
	my %my_return;
	my $param_str;
	foreach (@_){

		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	my $cmd = "mkdir -p $dest_dir";
	$return_detail = &run_cmd_api("$cmd",1);
	if("$return_detail->{value}" ne "0"){
	        $my_return{desc} = "$return_detail->{desc}";
	        $my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{
	        $my_return{desc} = "ok, $dest_dir exists";
	        $my_return{value} = 0;
        	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
		return \%my_return;
	}
	

}
sub check_cm_conf
{
	my ($this,$cm_conf) = @_;
	my $return_detail;
	my %my_return;
	my $param_str;
	foreach (@_){

		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	### �ȼ���ļ��Ƿ����
	$return_detail = &check_file_exists_api($cm_conf);
	if("$return_detail->{value}" ne "0"){
	        $my_return{desc} = "No such $cm_conf";
	        $my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{
	        $my_return{desc} = "ok, there is $cm_conf";
	        $my_return{value} = 0;
        	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
		return \%my_return;
	}

}
sub check_icafe_table
{
	my ($this,$icafe_table) = @_;
	my $return_detail;
	my %my_return;
	my $param_str;
	foreach (@_){

		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	### �ȼ���ļ��Ƿ����
	$return_detail = &check_file_exists_api($icafe_table);
	if("$return_detail->{value}" ne "0"){
	        $my_return{desc} = "No such $icafe_table";
	        $my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}

	### ��ȡ�ļ�����
	my $cmd = "cat $icafe_table";
	my $icafe_content;
	$return_detail = &run_cmd_api("$cmd",1);
	if("$return_detail->{value}" ne "0"){
	        $my_return{desc} = $return_detail->{desc};
	        $my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{
	        chomp($return_detail->{desc});
	        $icafe_content = $return_detail->{desc};
	        $my_return{desc} = "get icafe content ok";
	        $my_return{value} = 0;
        	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
	
	}
	### ����jsonת��
	$return_detail = &json_decode_api($icafe_content);
	if("$return_detail->{value}" ne "0"){
	        $my_return{desc} = $return_detail->{desc};
	        $my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{
		$this->{conf}->{icafe_table} = $return_detail->{desc};
	        $my_return{desc} = "load icafe_table ok";
	        $my_return{value} = 0;
        	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
		return \%my_return;
	}


}
sub check_base_info
{
	my ($this,$base_info) = @_;
	my $return_detail;
	my %my_return;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	### ��� base_info�Ƿ����
	$return_detail = &check_file_exists_api($base_info);
	if("$return_detail->{value}" ne "0"){
	        $my_return{desc} = "No such $base_info";
	        $my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}
	
	### ���� base info �ļ�
	$return_detail = &new_load_conf_ini_api($base_info);
	if("$return_detail->{value}" ne "0"){
	        $my_return{desc} = "$return->{desc}";
	        $my_return{value} = 1;
        	$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{
		$this->{conf}->{base_info} = $return_detail->{desc};
		### $return_detail
		#print Dumper($this->{conf}->{base_info});
		### hiahiahia
	        $my_return{desc} = "load base_info ok";
	        $my_return{value} = 0;
        	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
		return \%my_return;
	}

}

sub xpp
{
	### 13yy
	my ($this) = @_;
	my $return_detail;
	my %my_return;
	my $param_str;
	foreach (@_){
		if((!defined($_)) || "$_" eq ""){
			$my_return{desc} = "input params erro,now params are :$param_str";
			$my_return{value} = 1;
        		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
			return \%my_return;
		}
		$param_str .= "$_,";
	}
	if("$return_detail->{value}" ne "0"){
		$my_return{value} = 1;
		$my_return{desc} = $return_detail->{desc};
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%my_return);
		return \%my_return;
	}else{
		$my_return{value} = 0;
		$my_return{desc} = "pause ok : task_id=$task";
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%my_return);
		return \%my_return;
	}
}


1;
