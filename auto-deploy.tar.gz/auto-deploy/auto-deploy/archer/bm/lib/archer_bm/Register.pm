package Task::Register;
BEGIN
{
	use Exporter();
	use vars qw($VERSION @ISA @EXPORT);
	use Data::Dumper;
	use File::Basename;
	use Fcntl qw(:flock);
	use FindBin qw($Bin);
	use lib "$Bin/../lib";
	use lib "$Bin/../conf";
	use Time::HiRes qw(time);
	use CONFIG;
	use Task::Common;
	use JSON;
	@ISA = qw(Exporter);
	@EXPORT = qw();
}

sub new {
	my ($type, $logit)    =   @_;
	my %param   =   @_; 	
	my $current_date = `date +%Y%m%d`;

	chomp($current_date);

	$this->{logit} = $logit;
	$this->{bin_path} = "$Bin";
	$this->{top_path} = "$Bin/../";
	$this->{data_path} = "$Bin/../data";
	$this->{history_path} = "$this->{data_path}/history/$current_date";
	$this->{lock_path} = "$Bin/../lock";
	$this->{dyndata_meta_path} = "$this->{bin_path}/../dyndata_meta";

	bless $this;
	`mkdir -p $this->{data_path}`;
	`mkdir -p $this->{history_path}`;
	`mkdir -p $this->{lock_path}`;

	return $this;
}

sub loadConf
{
	my ($this, $confFile) = @_;
	my %result_tmp;
	my %logstr;
	my $result;
	my $funcName = (caller(0))[3];

	$logstr{desc} = "start load the conf:$confFile";
	$logstr{cmd} = "$funcName";
	$logstr{ret} = 0;
	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);

	my $fh;
	if (!open($fh,$confFile)) {
		$logstr{desc} = "open the conf file failed for:$!";
		$logstr{cmd} = "$funcName";
		$logstr{ret} = $ERR_NUM{AOS_LOAD_CONF_FAILED};

		$this->{logit}->printLog($this->{logit}->{FATAL}, \%logstr);
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
		return (\%logstr);
	}

	my $line;
	$logstr{desc} = "load result:";
	while ($line = <$fh>) {
		if($line =~ m/^\s*#.*/ || $line =~ /^\s+$/) {
			next;
		} else {
			$line =~ s/^\s+//g;
			$line =~ s/\s+$//g;
		}
		my ($key, $value) = split("=", $line);
		$value =~ s/\"//g;
		$value =~ s/\'//g;
		$this->{conf}->{$key} = $value;
		$logstr{desc} .= " $key=$value ";
	}
	close($fh);
	$this->{conf}->{confFile} = $confFile;
	$logstr{cmd} = "$funcName";
	$logstr{ret} = $ERR_NUM{AOS_OK};
	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
	return \%logstr;
}

sub load_dyndata_meta
{
	my ($this) = @_;
	my %result_tmp;
	my %logstr;
	my $result;
	my $funcName = (caller(0))[3];
	my $json_obj = new JSON;
	
	$logstr{desc} = "start load the dyndata meta for $this->{conf}->{DATA_NAME}";
	$logstr{cmd} = "$funcName";
	$logstr{ret} = 0;
	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
	
	my $confFile = "$this->{dyndata_meta_path}/$this->{conf}->{DATA_NAME}.$this->{conf}->{IDC_REGION}";

	#�жϵ���Ӧ�Ĵʵ���ļ���meta�����ڵ�ʱ����Ҫ��zk��dumpһ��
	if (! -e $confFile) {
		$result = $this->get_the_dict_meta_file($confFile);
		if($result->{ret} != 0) {
			$logstr{desc} = "get the dict meta failed for:$result->{desc}";
			$logstr{ret} = $ERR_NUM{AOS_LOAD_CONF_FAILED};
			$logstr{cmd} = "$funcName";
			$this->{logit}->printLog($this->{logit}->{FATAL}, \%logstr);
			$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
			return \%logstr;
		} else {
			$logstr{desc} = "get the dict meta success dictname=$this->{conf}->{DATA_NAME}";
			$logstr{ret} = $ERR_NUM{AOS_LOAD_CONF_FAILED};
			$logstr{cmd} = "$funcName";
			$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
		}
	}
	my $fh;
	if (!open($fh,$confFile)) {
		$logstr{desc} = "open the conf file failed for:$!";
		$logstr{cmd} = "$funcName";
		$logstr{ret} = $ERR_NUM{AOS_LOAD_CONF_FAILED};

		$this->{logit}->printLog($this->{logit}->{FATAL}, \%logstr);
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
		return (\%logstr);
	}
	my $line;
	while ($line = <$fh>) {
		last;
	}
	close($fh);
	$this->{dyndata_meta_detail} = $json_obj->decode($line);
	$logstr{desc} = "load the dyndata meta succ";
	$logstr{cmd} = "$funcName";
	$logstr{ret} = $ERR_NUM{AOS_OK};
	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
	return \%logstr;
}

#
#����
sub get_locks
{
	my ($this) = @_;
	my $lock_num=0;
	my $lock_path = "$this->{lock_path}/../lock";
	my $lock_name = "";
	my %logstr;
	my $desc;
	while ($lock_num < $LOCK_NUM) {
		$lock_name = "$lock_path/lock.$lock_num";
		if ( ! -e "$lock_name") {
			`touch $lock_name`;
		}
		open (FD, "< $lock_name");
		if (flock(FD, LOCK_EX|LOCK_NB)) {
			$logstr{desc} = "get the lock success the lock file is:lock.$lock_num";
			$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
			`touch $lock_path/lock.get.$$`;
			return (0);     #�����ɹ�
		} else {
			close(FD);      #����ʧ�ܣ��ر��ļ�
		}
		$lock_num++;
	}
	return (1);
}

sub deploy_dyndata_all
{
	my ($this) = @_;
	my $remote_path="";
	my %result_tmp;
	my %logstr;
	my $result;
	my $funcName = (caller(0))[3];

	my @instances;
	my $try_time = 0;
	while($try_time < 3) {
		@instances=$this->deploy_dyndata_single();
		if ($instances[0] ne "FAILED") {
			$logstr{desc} = "deploy $this->{conf}->{DATA_NAME} successed try_time=$try_time";
			$logstr{ret} = $ERR_NUM{AOS_OK};
			$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
			last;
		} else {
			$logstr{desc} = "deploy $this->{conf}->{DATA_NAME} failed try_time=$try_time";
			$logstr{ret} = $ERR_NUM{AOS_DEPLOY_FAILED};
			$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
			$this->{logit}->printLog($this->{logit}->{WARNNING}, \%logstr);
			$sleep_time=int(rand(60));
			$sleep_time++;
			$try_time++;
			$sleep_time *= $try_time;	#sleepʱ��ͷ�
			sleep($sleep_time);
			next;
		}
	}
	
	foreach (@instances) {
		push(@{$logstr{detail}}, $_);
	}
	return \%logstr;
}

sub get_reload_cmd
{
	my ($this) = @_;
	my $reload_cmd;
	if("$this->{conf}->{DATA_NAME}" eq "newbrief") {
		$reload_cmd = " -t bt -r $this->{conf}->{ID} -o 60";
	} else {
		$reload_cmd = "$this->{dyndata_meta_detail}->{reload_cmd}";
	}
	return "$reload_cmd";
}
sub deploy_dyndata_single
{
	my ($this) = @_;
	my $remote_path="";
	my %result_tmp;
	my %logstr;
	my $result;
	my $funcName = (caller(0))[3];
	my $cmd;
	my @instances;

	if($this->{dyndata_meta_detail}->{protocol} eq "misdata") {
		$remote_path = $this->{conf}->{DATA_NAME};
	} else {
		$remote_path = $this->{conf}->{DATA_FILE_LIST};
	}
	my $reload_cmd = "";
	$reload_cmd = $this->get_reload_cmd();
	$cmd = "$ZKBIN -s dyndata push\\\
		--service-id=\'$this->{conf}->{TARGET_SERVICE_ID}\'\\\
		--timestamp=\'$this->{conf}->{DATA_TIMESTAMP}\'\\\
		--data-name=\'$this->{dyndata_meta_detail}->{online_name}\'\\\
		--local-path=\'$this->{dyndata_meta_detail}->{relative_path}\'\\\
		--pre-work=\'$this->{dyndata_meta_detail}->{pre_work}\'\\\
		--reload-cmd=\'$reload_cmd\'\\\
		--hdfs-path=\'$remote_path\'\\\
		--cluster-id=$this->{conf}->{IDC_REGION}";
	
	my @tmp_instance;
	eval {
		@tmp_instance=`$cmd`;
		$ret = $?>>8;
	};
	if(0 != $ret) {
		$logstr{desc} = "deploy failed for: $@. cmd=$cmd";
		$this->{logit}->printLog($this->{logit}->{WARNNING}, \%logstr);
		@instances=("FAILED");
		return @instances;
	} else {
		$logstr{desc} = "deploy succc";
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);

		foreach my $tmpstr (@tmp_instance) {
			chomp($tmpstr);
			if($tmpstr) {
				push (@instances, $tmpstr);
			}
		}
		return @instances;
	}
}


sub set_service_default_planned_state 
{
	my ($this) = @_;
	my $service_id="$this->{conf}->{TARGET_SERVICE_ID}";
	my $remote_path;

	if($this->{dyndata_meta_detail}->{protocol} eq "misdata") {
		$remote_path = $this->{conf}->{DATA_NAME};
	} else {
		$remote_path = $this->{conf}->{DATA_FILE_LIST};
	}
	my $reload_cmd = "";
	$reload_cmd = $this->get_reload_cmd();
	my $cmd = "${ZKBIN} -s service set-default-planned-state-attr\\\
			--service-id=$service_id\\\
			--key=dyndata.$this->{dyndata_meta_detail}->{online_name}.location\\\
			--value=\'$remote_path\'\\\
			--key=dyndata.$this->{dyndata_meta_detail}->{online_name}.prework\\\
			--value=\'$this->{dyndata_meta_detail}->{pre_work}\'\\\
			--key=dyndata.$this->{dyndata_meta_detail}->{online_name}.relativepath\\\
			--value=\'$this->{dyndata_meta_detail}->{relative_path}\'\\\
			--key=dyndata.$this->{dyndata_meta_detail}->{online_name}.reloadcmd\\\
			--value=\'$reload_cmd\'\\\
			--key=dyndata.$this->{dyndata_meta_detail}->{online_name}.timestamp\\\
			--value=\'$this->{conf}->{DATA_TIMESTAMP}\'\\\
			--cluster-id=$this->{conf}->{IDC_REGION}";
	my $result;
	my %logstr;
	$result = $this->runCmd("$cmd", 3);
	if (!defined($result->{ret}) || (0 != $result->{ret})) {
		chomp($result->{desc});
		$logstr{desc} = "set service default  failed for:$result->{desc}. the cmd return $result->{ret}";
		chomp($logstr{desc});
		$logstr{ret} = $ERR_NUM{AOS_SET_SERVICE_DEFAULT_FAILED};
		$logstr{cmd} = $result->{cmd};

		$this->{logit}->printLog($this->{logit}->{FATAL}, \%logstr);
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
		return \%logstr;
	} else {
		$logstr{desc} = "set service default succ";
		$logstr{ret} = $ERR_NUM{AOS_OK};
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
	}
	return \%logstr;
}


sub add_job
{
	my ($this, $data) = @_;
	my %logstr;
	my $result;
	my $funcName = (caller(0))[3];

	my $task_id = $this->get_job_id();

	my %task_data;
	my $json_obj = new JSON;
	my $task_data_string;

	#������task����
	my $task_create_time = $this->get_current_time();
	$task_data{dop_job_create_time} = $task_create_time;

	$task_data{dop_job_current_doing_num} = 0;
	$task_data{dop_job_failed_num} = 0;
	$task_data{dop_job_skip_num} = 0;
	$task_data{dop_job_success_num} = 0;
	
	my $task_dop_job_total_num = @{$data->{detail}};
	$task_data{dop_job_total_num} = $task_dop_job_total_num;

	my $task_dop_job_retister_host = $this->get_hostname();
	$task_data{dop_job_register_host} = $task_dop_job_retister_host;

	$task_data{dop_job_register_pid} = $PID;
	$task_data{dop_job_monitor_host} = "undef";
	$task_data{dop_job_monitor_host} = "undef";
	$task_data{dop_job_register_id} = "$task_id";
	
	#����ִ�еĳ�ʱʱ��,��Ҫ��Բ�ͬ�����񵥶�����
	my $task_dop_job_exec_timeout = $this->get_exec_timeout();
	$task_data{dop_job_exec_timeout} = $task_dop_job_exec_timeout;

	#����ȴ��ĳ�ʱʱ��,��Ҫ��Բ�ͬ�����񵥶�����
	my $task_dop_job_wait_timeout = $this->get_wait_timeout();
	$task_data{dop_job_wait_timeout} = $task_dop_job_wait_timeout;

	my $task_dop_job_alarm_num_limit = $this->get_alarm_num_limit();
	$task_data{dop_job_alarm_num_limit} = $task_dop_job_alarm_num_limit;

	my $task_dop_job_alarm_failed_ratio = $this->get_alarm_failed_ratio();
	$task_data{dop_job_alarm_failed_ratio} = $task_dop_job_alarm_failed_ratio;

	#����ִ�����֮��ĺ��ö���,���ڴ��⻻�ⶼ��Ҫ���ã������Ǵ��������ʱ��
	my $task_dop_job_post_action = $this->get_job_post_action();
	$task_data{dop_job_post_action} = $task_dop_job_post_action;

	$task_data{dop_job_register_additional} = "$this->{conf}->{DATA_NAME}";

	$task_data_string = $json_obj->encode(\%task_data);
	my $table_id="";
	$table_id = $JOB{job_dyndata_trans_table_id};

	my $cmd = "$ZKBIN -s task del --task-table-id=$table_id --task-id=$task_id --cluster-id=$this->{conf}->{IDC_REGION}";
	$this->runCmd("$cmd", 3);
	$cmd = "$ZKBIN -s task add --task-table-id=$table_id --task-id=$task_id --data=\'$task_data_string\' --cluster-id=$this->{conf}->{IDC_REGION}";
	$result = $this->runCmd("$cmd", 3);
	if (!defined($result->{ret}) || (0 != $result->{ret})) {
		chomp($result->{desc});
		$logstr{desc} = "add job failed for:$result->{desc}. the cmd return $result->{ret}";
		chomp($logstr{desc});
		$logstr{ret} = $ERR_NUM{AOS_ADD_JOB_FAILED};
		$logstr{cmd} = "$result->{cmd}";
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%logstr);
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
		return \%logstr;
	} else {
		$logstr{desc} = "add job $task_id succ";
		$logstr{ret} = $ERR_NUM{AOS_OK};
		$logstr{cmd} = $result->{cmd};

		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
	}
	return \%logstr;
}

sub add_job_detail
{
	my ($this, $data) = @_;
	my %result_tmp;
	my %logstr;
	my $result;
	my $funcName = (caller(0))[3];

	my $task_id = $this->get_job_id();

	my %task_data;
	my $json_obj = new JSON;
	my $task_data_string;

	my $task_register_time;
	my $task_create_time;
	my $cmd;
	my $instance;

	my $dump_data = $this->get_instance_dump(@{$data->{detail}});
	my %additional_data;
	my $additional_string;
	my $agent_task_name;
	#@{$data->{detail}} ��������еķ���ʵ��
	for (@{$data->{detail}}) {
		$instance = $_;
		$task_data{dop_job_register_id} = $task_id;

		$task_data{dop_job_service_instance_id} = $instance;
		$task_data{dop_job_can_skip} = "off";
		$task_data{dop_job_continue_time} = 0;
		$task_data{dop_job_current_status} = "waitting";
		
		$task_register_time = $this->get_register_time();
		$task_data{dop_job_finished_time} = "";
		$task_data{dop_job_register_time} = "$task_register_time";
		$task_data{dop_job_start_time} = "";
		$task_data{dop_job_exec_detail} = "undef";

		$task_create_time = $this->get_current_time();
		$task_data{dop_job_create_time} = $task_create_time;

		$additional_data{dump_data} = $dump_data->{$instance};
		$additional_string = $json_obj->encode(\%additional_data);
		$task_data{dop_job_additional} = "undef";

		#��¼�������ڵ����ϵ���������
		$agent_task_name = $this->get_agent_task_name($instance, \%additional_data);
		$task_data{dop_job_agent_task_name} = $agent_task_name;

		#��¼����ִ�еĻ�����
		$task_data{dop_job_exec_host} = $additional_data{dump_data}->{meta}->{slavenode_id};
		#no ��ʾ��ʵ��û�б���
		$task_data{dop_job_monitor_status} = "no";

		$task_data_string = $json_obj->encode(\%task_data);
		
		my $table_id="";
		$table_id = $JOB{job_dyndata_trans_detail_table_id};

		$cmd = "$ZKBIN -s task add --task-table-id=$table_id --task-id=$task_id --data=\'$task_data_string\' --cluster-id=$this->{conf}->{IDC_REGION}" ;
		$result = $this->runCmd("$cmd", 3);
		if (!defined($result->{ret}) || (0 != $result->{ret})) {
			chomp($result->{desc});
			$logstr{desc} = "add job_detail $task_id-$instance failed for:$result->{desc}. the cmd return $result->{ret}";
			chomp($logstr{desc});
			$logstr{ret} = $ERR_NUM{AOS_ADD_JOB_FAILED};
			$logstr{cmd} = $result->{cmd};

			$this->{logit}->printLog($this->{logit}->{FATAL}, \%logstr);
			$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
			return \%logstr;
		} else {
			$logstr{desc} = "add job $task_id-$instance succ";
			$logstr{ret} = $ERR_NUM{AOS_OK};
			$logstr{cmd} = $result->{cmd};
			$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
		}
	
	}
	return \%logstr;
}

sub add_job_monitor
{
	my ($this, $data) = @_;
	my %logstr;
	my $result;
	my $funcName = (caller(0))[3];

	my $task_id = $this->get_job_id();

	my %task_data;
	my $json_obj = new JSON;
	my $task_data_string;

	#������task����
	my $task_create_time = $this->get_current_time();
	$task_data{dop_job_create_time} = $task_create_time;

	$task_data{dop_job_register_id} = $task_id;
	
        #20120823103510-1345689310
        #��ʼ������ע���ʱ�䣬��ʼע���ʱ�����������,����ֶ��ڼ������ַ���ʱ�����
        my $dop_job_last_modify_time = "19871105101010-0";
        $task_data{dop_job_last_modify_time} = $dop_job_last_modify_time;

	$task_data{dop_job_protocol} = $JOB{job_protocol};
	$task_data{dop_monitor_key_primary} = $this->get_key_primary();
	$task_data{dop_monitor_key_sub} = $this->get_key_sub();
	$task_data{dop_job_additional} = "$this->{conf}->{IDC_REGION}";

	$task_data_string = $json_obj->encode(\%task_data);

	my $table_id="";
	$table_id = $JOB{job_dyndata_trans_monitor_table_id};

	my $cmd = "$ZKBIN -s task del --task-table-id=$table_id --task-id=$task_id --cluster-id=$this->{conf}->{IDC_REGION}";
	$this->runCmd("$cmd", 3);
	$cmd = "$ZKBIN -s task add --task-table-id=$table_id --task-id=$task_id --data=\'$task_data_string\' --cluster-id=$this->{conf}->{IDC_REGION}";

	$result = $this->runCmd("$cmd", 3);
	if (!defined($result->{ret}) || (0 != $result->{ret})) {
		chomp($result->{desc});
		$logstr{desc} = "add monitor job failed for:$result->{desc}. the cmd return $result->{ret}";
		chomp($logstr{desc});
		$logstr{ret} = $ERR_NUM{AOS_ADD_JOB_FAILED};
		$logstr{cmd} = $result->{cmd};

		$this->{logit}->printLog($this->{logit}->{FATAL}, \%logstr);
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
		return \%logstr;
	} else {
		$logstr{desc} = "add monitor job $task_id succ";
		$logstr{ret} = $ERR_NUM{AOS_OK};
		$logstr{cmd} = $result->{cmd};

		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
	}
	return \%logstr;
}



sub get_job_id
{
	my ($this) = @_;
	my $job_id;

	$job_id = "$JOB{job_class}/$this->{conf}->{IDC_REGION}/$this->{dyndata_meta_detail}->{online_name}/$this->{conf}->{TARGET_SERVICE_ID}/$this->{conf}->{DATA_TIMESTAMP}";
	return $job_id;
}
#
#exec a command and return 
#format: ($command, $try_times)
sub runCmd {
	my ($this,$cmd, $max)   =   @_;
	my $ret_str =   "";
	my $ret     =   1;
	my $start   =   0;
	my %logstr;
	my $start_time;
	my $end_time;
	my $con_time;
	while ($start < $max) {
	    $start_time = time;
	    $ret_str    =   `$cmd`;
	    $ret        =   $?>>8;
	    $end_time = time;
	    $con_time = sprintf("%.3f", $end_time - $start_time);
	    if ($ret != 0) {
		$logstr{desc} = "exec the cmd failed";
		$logstr{cmd} = "$cmd";
		$logstr{ret} = $ret;
		$logstr{tm} = $con_time;
		$logstr{try_time} = $start;
		$this->{logit}->printLog($this->{logit}->{WARNNING}, \%logstr);
		sleep(3);
		print "start $start";
		$start++;
	    } else {
		$logstr{desc} = "exec the cmd success";
		$logstr{cmd} = "$cmd";
		$logstr{ret} = $ret;
		$logstr{tm} = $con_time;
		$logstr{try_time} = $start;
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
		last;
	    }
	}
	return {
	    "cmd"   =>  "$cmd",
	    "desc"  =>  "$ret_str",
	    "detail" => "$ret_str",
	    "ret"   =>  "$ret"
	};
}

#
#hash����
#
sub cp_hash
{
	my ($this, $source, $dest) = @_;
	my %logstr;
	my $str;

	if(1 == $DEBUG) {
		$str = $this->hash_to_str($source);
		$logstr{desc} = "i'm in cp_hash the dest hash is : $str";
		$this->{logit}->printLog($this->{logit}->{DEBUG},\%logstr);
	}
	while (my ($key, $value) = each (%{$source})) {
		chomp($value);
		$dest->{$key} = $source->{$key};
	}
}

#
#
sub hash_to_str
{
	my ($this, $hash) = @_;
	my $str;
	while (my ($key, $value) = each (%{$hash})) {
		chomp($value);
		$str .= "$key=$value ";
	}
	return $str;
}

sub print_line_to_file
{
	my ($this, $line, $file)  =  @_;
	my $funcName = (caller(0))[3];
	my %result;
	my $fh;
	if (!open($fh, ">>$file")) {
		$result{ret}     =   $ERR_NUM{AOS_OPEN_FILE_FAILED};
		$result{desc}    =   "open $file failed for :$!";
		$result{cmd}     =   "$funcName";

		$this->{logit}->printLog($this->{logit}->{WARNNING}, \%result);
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%result);
		return \%result;
	}

	print $fh "$line";
	$result{ret}     =   0;
	$result{desc}    =   "print history success";
	$result{cmd}     =   "$funcName";
	return \%result;
}

sub get_current_time
{
	my ($this) = @_;
	my $current_time = `date +%Y-%m-%d-%H:%M:%S`;
	chomp($current_time);
	return $current_time;
}
sub get_register_time
{
	my ($this) = @_;
	my $current_time = `date +%Y%m%d%H%M%S-%s`;
	chomp($current_time);
	return $current_time;
}

sub get_hostname
{
	my ($this) = @_;
	my $host_name = `hostname`;
	chomp($host_name);
	return $host_name;
}

#��ȡ����ִ�еĳ�ʱʱ��
sub get_exec_timeout
{
	my ($this) = @_;
	my $data_name = $this->{conf}->{DATA_NAME};
	my $timeout;
	if(defined($TASK_LIMIT{$data_name}->{dop_job_exec_timeout})) {
		$timeout = $TASK_LIMIT{$data_name}->{dop_job_exec_timeout};
	} else {
		$timeout = $TASK_LIMIT{default}->{dop_job_exec_timeout};
	}
	return "$timeout";
}

#��ȡ����ȴ��ĳ�ʱʱ��
sub get_wait_timeout
{
	my ($this) = @_;
	my $data_name = $this->{conf}->{DATA_NAME};
	my $timeout;
	if(defined($TASK_LIMIT{$data_name}->{dop_job_wait_timeout})) {
		$timeout = $TASK_LIMIT{$data_name}->{dop_job_wait_timeout};
	} else {
		$timeout = $TASK_LIMIT{default}->{dop_job_wait_timeout};
	}
	return "$timeout";

}
sub get_alarm_num_limit
{
	my ($this) = @_;
	my $alarm_limit;
	if(defined($TASK_LIMIT{$this->{dyndata_meta_detail}->{online_name}}->{dop_job_alarm_num_limit})) {
		$alarm_limit = $TASK_LIMIT{$this->{dyndata_meta_detail}->{online_name}}->{dop_job_alarm_num_limit};
	} else {
		$alarm_limit = $TASK_LIMIT{default}->{dop_job_alarm_num_limit};
	}
	return $failed_ratio;
}

sub get_alarm_failed_ratio
{
	my ($this) = @_;
	my $failed_ratio;
	if(defined($TASK_LIMIT{$this->{dyndata_meta_detail}->{online_name}}->{dop_job_alarm_failed_ratio})) {
		$failed_ratio = $TASK_LIMIT{$this->{dyndata_meta_detail}->{online_name}}->{dop_job_alarm_failed_ratio};
	} else {
		$failed_ratio = $TASK_LIMIT{default}->{dop_job_alarm_failed_ratio};
	}
	return $failed_ratio;
}

sub get_key_primary
{
	my ($this) = @_;
	my %keys;
	my $json_obj = new JSON;
	my $return_string;
	my $dict_name = $this->{dyndata_meta_detail}->{online_name};
	$keys{"dyndata#$dict_name#timestamp"} = $this->{conf}->{DATA_TIMESTAMP};
	
	$return_string = $json_obj->encode(\%keys);
	return $return_string;
}

sub get_key_sub
{
	my ($this) = @_;
	my %keys;
	my $json_obj = new JSON;
	my $return_string;

	$keys{"undef"} = "undef";
	$return_string = $json_obj->encode(\%keys);
	return $return_string;
}

#��������ע���ʱ���index-id
sub get_index_id
{
	my ($this) = @_;
	my $return_string;
	
	$return_string = "$this->{conf}->{INDEX_TYPE}_$this->{conf}->{TARGET_PARTITION}_$this->{conf}->{BUILD_TIME}";
	return $return_string;
}

#��ȡһ������ʵ����dump��Ϣ
sub get_instance_dump
{
	my ($this, @instance_all) = @_;
	my %keys;
	my $json_obj = new JSON;
	my $return_string;
	my $instance;

	#����������ѡ��,һ����ȫdump�����ֶ�zk�ķ���Ƶ��С��������������
	#һ���Ƿַ���ʵ����ȡָ�����ֶ�,����Ƶ�ʴ�,����������С
	#��ǰѡ���õڶ��ַ���,������С

	my $result;
	my $slavenode_id;
	my %dump;
	
	for $instance (@instance_all) {
		$result = $this->get_instance_meta_attr($instance, "slavenode_id");
		if(0 == $result->{ret}) {
			$dump{$instance}->{meta}->{slavenode_id} = $result->{detail};
		} else {
			$dump{$instance}->{meta}->{slavenode_id} = "undef";
		}
		$result = $this->get_instance_current_attr($instance, "dyndata#$this->{dyndata_meta_detail}->{online_name}#timestamp");
		if (0 == $result->{ret}) {
			$dump{$instance}->{"current-state-all"}->{timestamp} = $result->{detail};
		} else {
			$dump{$instance}->{"current-state-all"}->{timestamp} = "undef";
		}
	}
	return \%dump;
}

sub get_instance_meta_attr
{
	my ($this, $instance, $key) = @_;
	chomp($instance);
	my $CMD = "$ZKBIN -s service-instance get-meta-attr --service-instance-id=$instance --key=$key --cluster-id=$this->{conf}->{IDC_REGION}";
	my $result;
	
	$result = $this->runCmd("$CMD", 3);
	chomp($result->{detail});
	return $result;
}

sub get_instance_current_attr
{
	my ($this, $instance, $key) = @_;
	chomp($instance);

	$key =~ s/#/./g;
	my $CMD = "$ZKBIN -s service-instance get-current-state-attr --service-instance-id=$instance --key=$key --cluster-id=$this->{conf}->{IDC_REGION}";
	my $result;

	$result = $this->runCmd("$CMD", 3);
	chomp($result->{detail});
	return $result;
}
sub get_instance_planned_attr
{
	my ($this, $instance, $key) = @_;
	chomp($instance);
	my $CMD = "$ZKBIN -s service-instance get-planned-state-attr --service-instance-id=$instance --key=$key --cluster-id=$this->{conf}->{IDC_REGION}";
	my $result;

	$result = $this->runCmd("$CMD", 3);
	chomp($result->{detail});
	return $result;
}
sub get_agent_task_name
{
	my ($this, $instance, $dump_data) = @_;
	my $result;
	my $cmd_name;
	if ($this->{conf}->{TARGET_SERVICE_ID} =~ /bs_.*/) {
		$cmd_name = "BS_CMD_DYNDATA";
	} else {
		$cmd_name = "BC_CMD_DYNDATA";
	}
	$return_string = "$instance+$cmd_name+$this->{dyndata_meta_detail}->{online_name}+$this->{conf}->{DATA_TIMESTAMP}+$dump_data->{dump_data}->{'current-state-all'}->{timestamp}";
	return $return_string;
}
sub get_job_post_action
{
	my ($this) = @_;

	my $service_name = "$this->{conf}->{TARGET_SERVICE_ID}";
	my $CMD;
	chomp($service_name);
	my $current_time;
	$CMD = "";
}

sub get_the_dict_meta_file
{
	my ($this, $confFile) = @_;
	my %result_tmp;
	my %logstr;
	my $result;
	my $funcName = (caller(0))[3];
	my $json_obj = new JSON;

	my $CMD = "$ZKBIN -s dyndata-meta get-meta-all --dyndata-meta-id=$this->{conf}->{DATA_NAME} --cluster-id=$this->{conf}->{IDC_REGION}";
	$result = $this->runCmd("$CMD", 3);

	if($result->{ret} != 0) {
		$logstr{desc} = "get the $this->{conf}->{DATA_NAME} meta failed for:$result->{desc}";
		$logstr{cmd} = "$CMD";
		$logstr{ret} = $ERR_NUM{AOS_GET_DYNDATA_META_FAILED};
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%logstr);
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
	} else {
		$this->print_line_to_file("$result->{desc}", $confFile);
		$logstr{desc} = "get the $this->{conf}->{DATA_NAME} meta success";
		$logstr{cmd} = "$CMD";
		$logstr{ret} = $ERR_NUM{AOS_OK};
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
	}
	return \%logstr;
}
1;
