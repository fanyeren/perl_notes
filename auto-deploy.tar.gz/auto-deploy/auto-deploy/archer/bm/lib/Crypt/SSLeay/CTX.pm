package Crypt::SSLeay::CTX;
require Crypt::SSLeay;
1;
