#!/usr/bin/perl -w
package Alarm;
$|=1;
use strict;

BEGIN
{
        use Exporter();
        use vars qw($VERSION @ISA @EXPORT);
        @ISA = qw(Exporter);
        @EXPORT = qw(
			&get_alarm_email_addr &get_alarm_mess_addr
			&send_alarm_email &send_alarm &send_alarm_message
                        );
        use Cwd qw/abs_path/;
        use File::Basename;
	use Data::Dumper;
}

use Data::Dumper;
use MIME::Lite;

my $currentPath=dirname(abs_path(__FILE__));
my $alarm_conf_file="$currentPath/alarm.conf";

sub get_alarm_email_addr
{
	my $dest_mail_tmp=`grep "^EMAIL_LIST=" $alarm_conf_file`;
	my ($key, $dest_mail) = split("=", $dest_mail_tmp);

	$dest_mail =~ s/\"//g;
	$dest_mail =~ s/\'//g;
	$dest_mail =~ s/,/ /g;
	chomp($dest_mail);
	return $dest_mail;
}

sub get_alarm_mess_addr
{	
	my $dest_phone_tmp=`grep "^MOBILE_LIST=" $alarm_conf_file`;
	my ($key, $dest_phone) = split("=", $dest_phone_tmp);

	$dest_phone =~ s/\"//g;
	$dest_phone =~ s/\'//g;
	chomp($dest_phone);
	return $dest_phone;
}

sub send_alarm_email
{
	my ($content, $subject) = @_;
	my $msg;
	my $ret;

	if (!$subject) {
		$subject = $content;
	}
	my $recipients = &get_alarm_email_addr;
	my $current_time = `date`;
	my $host = `hostname`;
	my $sender = "";

	chomp($host);
	chomp($current_time);
	$content .= "[$current_time][$host]";
	$msg = MIME::Lite->new( From => "$sender", To =>"$recipients",Subject =>"$subject", Type =>'multipart/related');
	$msg->attach(Type =>'text/html', Data=>"$content");
	$msg->send;
	$ret = $?>>8;
	return $ret;
}

sub send_alarm_message
{
	my ($contents) = @_;
	my $reciver = &get_alarm_mess_addr;
	my $current_time = `date`;
	my $host = `hostname`;

	chomp($host);
	chomp($current_time);
	$contents .= "[$current_time][$host]";

	my $cmd="$reciver\@\'$contents\'";
	my $ret;
	`/bin/gsmsend $cmd &>/dev/null`;
	$ret = $?>>8;
	return $ret;
}

sub send_alarm
{
	my ($alarmLevel, $content_mes, $content_mail) = @_;

	if ($alarmLevel == 1) {
		send_alarm_message("$content_mes");
	} elsif ($alarmLevel == 2) {
		send_alarm_email("$content_mail");
	} else {
		send_alarm_message("$content_mes");
		send_alarm_email("$content_mail");
	}
}
