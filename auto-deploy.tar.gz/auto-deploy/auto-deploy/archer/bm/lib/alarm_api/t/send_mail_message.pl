#!/usr/bin/perl -w
use strict;
use FindBin qw($Bin);
use lib "$Bin/../perl";
use Alarm;

my $ret=&send_alarm_email("mail_content", "mail_subject");
print "send email return:$ret\n";
$ret=&send_alarm_message("message");
print "send message return:$ret\n";

