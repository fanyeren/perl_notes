#!/bin/bash
CURRENT_PATH=`dirname $0`
cd $CURRENT_PATH
cd ../shell
source alarm.sh
cd - &>/dev/null

#send_alarm_email 
send_alarm_email "mail_content" "mail_subject"
echo "send alarm mail return $?"

#send_alarm_message
send_alarm_message "message"
echo "send message return $?"

