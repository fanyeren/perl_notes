#!/bin/bash
CURRENT_PATH_LAST=$CURRENT_PATH
CURRENT_PATH=`pwd`
CONF_ALARM_FILE="$CURRENT_PATH/alarm.conf"
CURRENT_PATH=$CURRENT_PATH_LAST

#ͳһ�˳���
function myexit_alarm
{
        local ret=$1
        [ -z $ret ] && ret=1

        exit $ret

}


#�������ͽӿ�
function get_alarm_email
{
	local email_list=`grep "^EMAIL_LIST=" $CONF_ALARM_FILE| awk -F'=' '{print $2}' | sed 's/"//g'`
	if [ -z "$email_list" ]
	then
		email_list=`grep "^DEFAULT_EMAIL_LIST" $CONF_ALARM_FILE| awk -F'=' '{print $2}' | sed 's/"//g'`
		if [ $? -ne 0 ]
		then
			email_list="psop-se@baidu.com"
		fi
	fi
	echo  $email_list
}
function get_alarm_mobile
{
	local phone_num=`grep "^MOBILE_LIST=" $CONF_ALARM_FILE| awk -F'=' '{print $2}' | sed 's/"//g'`
	if [ -z "$phone_num" ]
	then
		phone_num=`grep "^DEFAULT_MOBILE_LIST=" $CONF_ALARM_FILE| awk -F'=' '{print $2}' | sed 's/"//g'`
		if [ $? -ne 0 ]
		then
			phone_num="g_psop_seb"
		fi
	fi
	echo $phone_num
}
#send_alarm_email $content $subject
function send_alarm_email
{
	local content="$1"
	local subject="$2"
	if [ x"$subject" == x"" ]
	then
		subject="$content"
	fi
	local email_list=`get_alarm_email`
	echo "$content" | mail -s "$subject" "$email_list" &>/dev/null
	return $?;
}

function send_alarm_message
{
	local content="$1"
	local phone_num=`get_alarm_mobile`
	gsmsend $phone_num@"$content" &>/dev/null
	return $?;
}

#flag=0ֱ���ʼ���=1 ���ţ�=2�����ʼ�
function send_alarm
{
	local content=$1
	local flag=$2
	local subject="$3"

	if [ -z "$flag" ]
	then
		flag=0
	fi

	if [ $flag -eq 0 ]
	then
		send_alarm_email "$content" "$subject"
	elif [ $flag -eq 1 ]
	then
		send_alarm_message "$content"
	elif [ $flag -eq 2 ]
	then
		send_alarm_email "$content" "$subject"
		send_alarm_message "$content"
	else
		send_alarm_email "$content" "$subject"
	fi
}

