package Common;

BEGIN {
    use Exporter();
    use vars qw($VERSION @ISA @EXPORT);
    use Data::Dumper;
    use File::Basename;
    use Carp;
    use FindBin qw($Bin);
    use lib "$Bin/../lib/";
    use JSON::XS;
    use CONFIG;
    use POSIX;
    use YAML;
    use Config::IniFiles;
    @ISA = qw(Exporter);
    @EXPORT = qw (
        $AUTO_DEPLOY
        $INITIAL_VALUE
        $BADHOST_API
        &check_is_item_in_hash_api 
        &update_status_table
        &call_BM_deploy_api
        &call_archer_bm_deploy_api
        &get_check_result_from_dk_api
        &get_deploy_status
        &get_now_time_api
        &check_file_exists_api
        &check_dir_exists_api
        &get_four_version_api
        &call_archer_dm_api
        &run_cmd_api
        &read_file_content_api
        $THREE_TO_FOUR_VERSION_URL
        $ARCHER_PROCESS_URL
        $SCAN_CHECK_RESULT_TIME
        $GLOBAL_PROCESS_URL
        $HI_MASTER
        $HI_PORT
        $HI_ACCOUNT
        $HI_GROUP
        $HI_PASSWD
        $SEOP
        $XPP

        &myexit
        &my_exit
        &check_super_mutex_api
        &check_mutex_status_api
        &check_in_mutex_token_api
        &load_conf_json_api
        &new_load_conf_ini_api
        &load_conf_ini_api
        &load_conf_kv_api
        &load_conf_yaml_api
        &uniq_array_api
        &send_mail_api
        &download_svn_file_api
        &download_ftp_file_api
        &download_local_file_api
        &add_zk_info_api
        &del_zk_attr_api
        &del_zk_all_api
        &initial_zk_info_api
        &get_zk_attr_info_api
        &get_zk_all_info_api
        &check_if_four_version_api
        &check_archer_status_api
        &send_msg_by_robot_api
        &set_default_roadmap_api
        &call_delete_badhost_api
        &add_roadmap_api
        $ZKCTL_PATH
        $THREE_TO_FOUR_CMD
        $TRIGGER_ARCHER_CMD
        $CHECK_ARCHER_STATUS_CMD
        &trigger_archer_api
        &control_archer_api
        &send_message_api
        &call_qa_check_api
        &get_archer_host_api
        &call_rollback_api
        $MUTEX_SYSTEM_PATH
        &check_out_mutex_token_api
        &json_decode_api
        $ROADMAP_PATH
        $AUTO_DEPLOY_PATH
    );
}

$ZKCTL_PATH = "$Bin/../../../public/cm/zkctl";
$MUTEX_SYSTEM_PATH = "$Bin/../../../public/mutex_bm/bin/mutex_bm";
$THREE_TO_FOUR_CMD = "$Bin/../lib/";
$TRIGGER_ARCHER_CMD = "$Bin/../tools/archer_control";
$CHECK_ARCHER_STATUS_CMD = "$Bin/../tools/check_archer_status";
$ROADMAP_PATH = "/home/work/auto-deploy/public/road_map/bin/road_map";
$AUTO_DEPLOY_PATH = "/home/work/auto-deploy/auto_deploy_bm/bin/start_deploy";

$AUTO_DEPLOY = "auto_deploy";
$tmp_json_obj = new JSON::XS; 
$str{status} = "deploy_ing";
$str{outside_sign} = "deploy";
$INITIAL_VALUE = $tmp_json_obj->encode(\%str);
$BADHOST_API = "ftp://tc-psop-sys01.tc:/home/work/opbin/badMachines/archer/bad";
$THREE_TO_FOUR_VERSION_URL="http://scm.baidu.com/http/queryVersionInfo.action?cvspath";
$ARCHER_PROCESS_URL = "http://noah.baidu.com/ci-web/index.php?r=ProcessView/QueryTask";
$SCAN_CHECK_RESULT_TIME=1;
$GLOBAL_PROCESS_URL = "http://yf-psop-deploy01.yf01.baidu.com:8080/auto_deploy/index.php";
### hi�������Ϣ
$HI_MASTER = "yf-psop-deploy01.yf01.baidu.com";
$HI_PORT = "14440";
### seop
$SEOP = "1201044";
### tmp hi
$XPP = "1398674";
###fengbikaifa
$FB = "1417254";
$HI_GROUP = $SEOP;


sub myexit
{
        my ($retstring) = @_;
        my $json_obj = new JSON::XS;
        my $return_message = $json_obj->encode($retstring);
        print STDOUT "return_message:".$return_message."\n";
        print STDOUT "value:".$retstring->{value}."\n";
        if(defined($retstring->{dis_url})) {
                print STDOUT "\n";
                print STDOUT "===========================   start succ, check the url=====================\n";
                print STDOUT "<a href=\"$retstring->{dis_url}\">$retstring->{dis_url}</a>\n";
                print STDOUT "============================================================================\n";
                print STDOUT "\n";
        }
        exit($retstring->{value});
}

sub my_exit
{
    my ($retstring) = @_;
    my $return_detail;
    my %my_return;
        my $param_str;
        foreach (@_){
                if((!defined($_)) || "$_" eq ""){
                        $my_return{desc} = "input params erro,now params are :$param_str";
                        $my_return{value} = 1;
                        return \%my_return;
                }
                $param_str .= "$_,";
        }
        my $json_obj = new JSON::XS;
        my $return_message = $json_obj->encode($retstring);
        print STDOUT $return_message;
        exit($retstring->{value});
}

sub get_four_version_api
{
    my ($module,$three_version) = @_;
    my $return_detail;
    my %my_return;
        my $param_str;
        foreach (@_){
                if((!defined($_)) || "$_" eq ""){
                        $my_return{desc} = "input params erro,now params are :$param_str";
                        $my_return{value} = 1;
                        return \%my_return;
                }
                $param_str .= "$_,";
        }

    my $url = "$THREE_TO_FOUR_VERSION_URL" . "=$module" . "&version=$three_version";
    my $json_obj = new JSON::XS;
    my $cmd = "curl \'$url\' 2>/dev/null";
    my $curl_result = &run_cmd_api("$cmd",1);
    #my $version_json = $json_obj->decode($curl_result);
    my $version_json =  &json_decode_api($curl_result);
    my $four_version = $version_json->{fourversions}[0];
    if($four_version =~ /\d+.\d+.\d+.\d+/){
        $my_return{desc} = $four_version;
        $my_return{value} = 0;
    }else{  
        $my_return{desc} = "can't get four version \n";
        $my_return{value} = 1;
    }
    return \%my_return;
}
sub check_dir_exists_api
{
        my ($dir) = @_;
        my %my_return;
        my $param_str;
        foreach (@_){
                if((!defined($_)) || "$_" eq ""){
                        $my_return{desc} = "input params erro,now params are :$param_str";
                        $my_return{value} = 1;
                        return \%my_return;
                }
                $param_str .= "$_,";
        }
        if(defined($dir) && -d $dir){
                $my_return{desc} ="ok, $dir exists \n";
                $my_return{value} = 0;
        return \%my_return;
        }else{  
                $my_return{desc} = "No such file : $dir";
                $my_return{value} = 1;
        return \%my_return;
        }
}

sub check_file_exists_api
{
        my ($file) = @_;
        my %my_return;
        my $param_str;
        foreach (@_){
                if((!defined($_)) || "$_" eq ""){
                        $my_return{desc} = "input params erro,now params are :$param_str";
                        $my_return{value} = 1;
                        return \%my_return;
                }
                $param_str .= "$_,";
        }
        if(defined($file) && -e $file){
                $my_return{desc} ="ok, $file exists \n";
                $my_return{value} = 0;
        return \%my_return;
        }else{  
                $my_return{desc} = "No such file : $file ";
                $my_return{value} = 1;
        return \%my_return;
        }
}

sub run_cmd_api 
{               
        my ($cmd, $max_retry_time) = @_;
        my $retry_time = 0;
        my $start_time;
        my $end_time;
        my $con_time;
        my %my_return;
        $my_return{desc} = "";

        while ($retry_time < $max_retry_time) {
                $start_time = time;
                $my_return{desc} = `$cmd`;
                $my_return{value} = $?>>8;
                $end_time = time;
                $con_time = sprintf("%.3f", $end_time - $start_time);
                if ($my_return{value} != 0) {
                        sleep(3);
                        $retry_time++;
                } else {
                        last;
                }
        }
        return \%my_return;
}


sub call_archer_dm_api
{
        my ($trigger_dm_option) = @_;
    my $funcname = (caller(0))[3];
    my %retstr;

        my $cmd = "$Bin/../../dm/bin/archer_dm $trigger_dm_option";
    if($DEBUG){
        print "=== now in $funcname , cmd = $cmd \n";
        print STDOUT Dumper($cmd);
        print STDERR Dumper($cmd);
    }

        $ret = &run_cmd_api($cmd, 1);
        if($ret->{value} != 0) {
                $retstr{desc} = "exec $cmd failed";
        $retstr{value} = 1;
                return \%retstr;
        }

    if($DEBUG){
        print Dumper(\%retstr);
    }
    $retstr{desc} = "trigger succ";
    $retstr{value} = 0;
        return \%retstr;

}

sub get_now_time_api
{
        my $now_time = strftime("%Y-%m-%d %H:%M:%S",localtime(time));
        return $now_time;
}

sub check_is_item_in_hash_api
{
    my ($check_item,$opt_long_value) = @_;
    my %my_return;
    $my_return{value} = 0;
    $my_return{desc} = "$check_item all exist; ";
    foreach (@{$check_item}) {
        if(!defined($opt_long_value->{$_}) || "$opt_long_value->{$_}" eq "") {
            $my_return{value} = 1;
            $my_return{desc} = "$_ is null or not defined; ";
            last;
        }
    }
    return \%my_return;
}

sub get_deploy_status
{
    my ($meta_id,$key) = @_;
    my $funcname = (caller(0))[3];
    print "=== now in $funcname\n";
    print "meta_id=$meta_id key=$key\n";
    my $cmd = "$ZKCTL_PATH -s dyndata-meta get-meta-attr --dyndata-meta-id=$meta_id --key=$key";
    if($DEBUG){
        print Dumper($cmd);
    }
    my $status = `$cmd`;
    chomp($status);
    return $status;
}

sub initial_zk_info_api
{
        my ($meta_id,$data) = @_;
        my %my_return;
        my $return_detail;
        my $param_str;
        foreach (@_){
                if((!defined($_)) || "$_" eq ""){
                        $my_return{desc} = "input params erro,now params are :$param_str";
                        $my_return{value} = 1;
                        return \%my_return;
                }
                $param_str .= "$_,";
        }

    $return_detail = &get_zk_all_info_api($meta_id);
    if("$return_detail->{value}" eq "0"){
        $return_detail = &del_zk_all_api($meta_id);
    }
        my $cmd = "$ZKCTL_PATH -s dyndata-meta add --dyndata-meta-id=$meta_id --data=\'$data\'";
    $return_detail = &run_cmd_api("$cmd",1);
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "[fail] cmd = $cmd";
                return \%my_return;
        }else{  
                $my_return{value} = 0;
                $my_return{desc} = "[ok] cmd = $cmd";
                return \%my_return;
        }

    
}

sub get_zk_all_info_api
{
        my ($meta_id) = @_;
        my %my_return;
        my $return_detail;
        my $param_str;
        foreach (@_){
                if((!defined($_)) || "$_" eq ""){
                        $my_return{desc} = "input params erro,now params are :$param_str";
                        $my_return{value} = 1;
                        return \%my_return;
                }
                $param_str .= "$_,";
        }
        my $cmd = "$ZKCTL_PATH -s dyndata-meta get-meta-all --dyndata-meta-id=$meta_id \n";
        $return_detail = &run_cmd_api("$cmd",1);
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "[fail] cmd = $cmd";
        }else{  
                $my_return{value} = 0;
                $my_return{desc} = "$return_detail->{desc}";
        }

        return \%my_return;
}

sub get_zk_attr_info_api
{
        my ($meta_id,$key) = @_;
        my %my_return;
        my $return_detail;
        my $param_str;
        foreach (@_){
                if((!defined($_)) || "$_" eq ""){
                        $my_return{desc} = "input params erro,now params are :$param_str";
                        $my_return{value} = 1;
                        return \%my_return;
                }
                $param_str .= "$_,";
        }
        my $cmd = "$ZKCTL_PATH -s dyndata-meta get-meta-attr --dyndata-meta-id=$meta_id --key=$key \n";
    $return_detail = &run_cmd_api("$cmd",1);
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "$return_detail->{desc}";
        }else{  
                $my_return{value} = 0;
                $my_return{desc} = "$return_detail->{desc}";
        }
        
        return \%my_return;
}

sub set_zk_info_api
{
        my ($meta_id,$key,$value) = @_;
        my %my_return;
        my $return_detail;
        my $param_str;
        foreach (@_){
                if((!defined($_)) || "$_" eq ""){
                        $my_return{desc} = "input params erro,now params are :$param_str";
                        $my_return{value} = 1;
                        return \%my_return;
                }
                $param_str .= "$_,";
        }
        my $cmd = "$ZKCTL_PATH -s dyndata-meta set-meta-attr --dyndata-meta-id=$meta_id --key=$key --value=\'$value\' \n";
        $return_detail = &run_cmd_api("$cmd",1);
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "[fail] cmd = $cmd";
        }else{  
                $my_return{value} = 0;
                $my_return{desc} = "[ok] cmd = $cmd";
        }

        return \%my_return;
}

sub del_zk_all_api
{
    my ($meta_id) = @_;
    my %my_return;
    my $return_detail;
    my $param_str;
    foreach (@_){
        if((!defined($_)) || "$_" eq ""){
            $my_return{desc} = "input params erro,now params are :$param_str";
            $my_return{value} = 1;
            return \%my_return;
        }
        $param_str .= "$_,";
    }

    my $cmd = "$ZKCTL_PATH -s dyndata-meta del --dyndata-meta-id=$meta_id ";
    $return_detail = &run_cmd_api("$cmd",1);
    if("$return_detail->{value}" ne "0"){
        $my_return{value} = 1;
        $my_return{desc} = "$return_detail->{desc}";
    }else{
        $my_return{value} = 0;
        $my_return{desc} = "$return_detail->{desc}";
    }

    return \%my_return;
}

sub del_zk_attr_api
{
    my ($meta_id,$key) = @_;
    my %my_return;
    my $return_detail;
    my $param_str;
    foreach (@_){
        if((!defined($_)) || "$_" eq ""){
            $my_return{desc} = "input params erro,now params are :$param_str";
            $my_return{value} = 1;
            return \%my_return;
        }
        $param_str .= "$_,";
    }
    my $cmd = "$ZKCTL_PATH -s dyndata-meta del-meta-attr --dyndata-meta-id=$meta_id --key=$key";
    $return_detail = &run_cmd_api("$cmd",1);
    if("$return_detail->{value}" ne "0"){
        $my_return{value} = 1;
        $my_return{desc} = "$return_detail->{desc}";
    }else{
        $my_return{value} = 0;
        $my_return{desc} = "$return_detail->{desc}";
    }

    return \%my_return;
}

sub add_zk_info_api
{
    my ($meta_id,$key,$value) = @_;
    my %my_return;
    my $return_detail;
    my $param_str;
    foreach (@_){
        if((!defined($_)) || "$_" eq ""){
            $my_return{desc} = "input params erro,now params are :$param_str";
            $my_return{value} = 1;
            return \%my_return;
        }
        $param_str .= "$_,";
    }

    $return_detail = &get_zk_attr_info_api($meta_id,$key);
    if("$return_detail->{value}" eq "0"){
        ### ���zk���Ѿ���¼�ˣ���ֱ�Ӹ���
        $return_detail = &set_zk_info_api($meta_id,$key,$value);
    }else{  
        ### ���zk��û�м�¼����ֱ������
        my $cmd = "$ZKCTL_PATH -s dyndata-meta add-meta-attr --dyndata-meta-id=$meta_id --key=$key --value=\'$value\' \n";
        $return_detail = &run_cmd_api("$cmd",1);
    }

    if("$return_detail->{value}" ne "0"){
        $my_return{value} = 1;
        $my_return{desc} = "[fail]$return_detail->{desc}";
    }else{  
        $my_return{value} = 0;
        $my_return{desc} = "[ok]$return_detail->{desc}";
    }

    return \%my_return;
}

sub check_super_mutex_api
{
    my %my_return;
    my $return_detail;
    my $cmd = $CHECK_SUPER_MUTEXT_CMD;
    $return_detail = run_cmd_api("$cmd",1);
    if("$return_detail->{value}" ne "0"){
        $my_return{value} = 1;
        $my_return{desc} = "super exists in mutex queue ,I'm not allowed to work";
    }else{  
        $my_return{value} = 0;
        $my_return{desc} = "allowed to work";
    }

    return \%my_return;
}

sub check_mutex_status_api
{
    my ($this,$mutex_token)    = @_;
    my %my_return;
    my $return_detail;

    my $param_str;
    foreach (@_){
        if((!defined($_)) || "$_" eq ""){
            $my_return{desc} = "input params erro,now params are :$param_str";
            $my_return{value} = 1;
            return \%my_return;
        }
        $param_str .= "$_,";
    }
    my $cmd = "$MUTEX_SYSTEM_PATH --action get_status --mutex_token $mutex_token";
    $return_detail = run_cmd_api("$cmd",1);
    if("$return_detail->{value}" ne "0"){
        $my_return{value} = 1;
        $my_return{desc} = " $mutex_token exists in mutex queue ,forbidden to work";
    }else{  
        $my_return{value} = 0;
        $my_return{desc} = "allowed to work";
    }

    return \%my_return;
}

sub json_decode_api
{
    my ($json_str) = @_;
    my $return_detail;
    my %my_return;
    my $param_str;
    foreach (@_){
        if((!defined($_)) || "$_" eq ""){
            $my_return{desc} = "input params erro,now params are :$param_str";
            $my_return{value} = 1;
            return \%my_return;
        }
        $param_str .= "$_,";
    }
    my $json_obj = new JSON::XS;
    my $obj;
    eval {
        $obj = $json_obj->decode($json_str);
    };
        if($@) {
                $my_return{desc} = "$@";
                $my_return{value} = 1;
                return \%my_return;
        }
        $my_return{desc} = $obj;
        $my_return{value} = 0;
        return \%my_return;

}

sub load_conf_yaml_api
{
        my ($conf_file) = @_;
        my $return_detail;
        my %my_return;
        my $param_str;
        foreach (@_){
                if((!defined($_)) || "$_" eq ""){
                        $my_return{desc} = "input params erro,now params are :$param_str";
                        $my_return{value} = 1;
                        return \%my_return;
                }
                $param_str .= "$_,";
    }
    ### �ȼ���ļ��Ƿ����
        $return_detail = &check_file_exists_api($conf_file);
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "$return_detail->{desc}";
                return \%my_return;
        }
    ### �ټ����ļ�
        my $obj;
        eval {
        $obj = YAML::LoadFile($conf_file);
        };
        if($@) {
                $my_return{desc} = "$@";
                $my_return{value} = 1;
                return \%my_return;
        }
        $my_return{desc} = $obj;
        $my_return{value} = 0;
        return \%my_return;

}

sub load_conf_json_api
{
        my ($conf_file) = @_;
        my $json;
        my $return_detail;
        my %my_return;
        my $param_str;
        foreach (@_){
                if((!defined($_)) || "$_" eq ""){
                        $my_return{desc} = "input params erro,now params are :$param_str";
                        $my_return{value} = 1;
                        return \%my_return;
                }
                $param_str .= "$_,";
        }
        $return_detail = &check_file_exists_api($conf_file);
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "$return_detail->{desc}";
                return \%my_return;
        }
        open JSON_FILE,$conf_file;
        while(<JSON_FILE>)
        {
                $json.=$_;
        }

        my $js= new JSON::XS;
        my $obj;
        eval {  
                $obj = $js->decode($json);
        };
        if($@) {
                $my_return{desc} = "$@";
                $my_return{value} = 1;
                return \%my_return;
        }
        close JSON_FILE;
        $my_return{desc} = $obj;
        $my_return{value} = 0;
        return \%my_return;
}
sub new_load_conf_ini_api
{
        my ($conf_file) = @_;
    my %my_return;
    my $return_detail;
        my $param_str;
        foreach (@_){
                if((!defined($_)) || "$_" eq ""){
                        $my_return{desc} = "input params erro,now params are :$param_str";
                        $my_return{value} = 1;
                        return \%my_return;
                }
                $param_str .= "$_,";
        }

    $return_detail = &check_file_exists_api($conf_file);
    if("$return_detail->{value}" ne "0"){
        $my_return{value} = 1;
        $my_return{desc} = "$return_detail->{desc}";
        return \%my_return;
    }
        my $cfg1 = Config::IniFiles->new( -file => $conf_file );
        if (not($cfg1)){
        $my_return{value} = 1;
        $my_return{desc} = "erro format , this file should be ini";
        #print Dumper(\@Config::IniFiles::errors);
        return \%my_return;
        }else{
        $my_return{desc} = $cfg1;
        $my_return{value} = 0;
        return \%my_return;
    }
}
sub load_conf_ini_api
{
        my ($conf_file) = @_;
    my %my_return;
    my $return_detail;
        my $param_str;
        foreach (@_){
                if((!defined($_)) || "$_" eq ""){
                        $my_return{desc} = "input params erro,now params are :$param_str";
                        $my_return{value} = 1;
                        return \%my_return;
                }
                $param_str .= "$_,";
        }

    $return_detail = &check_file_exists_api($conf_file);
    if("$return_detail->{value}" ne "0"){
        $my_return{value} = 1;
        $my_return{desc} = "$return_detail->{desc}";
        return \%my_return;
    }
        my $cfg1 = Config::IniFiles->new( -file => $conf_file );
        if (not($cfg1)){
        $my_return{value} = 1;
        $my_return{desc} = "erro format , this file should be ini";
        #print Dumper(\@Config::IniFiles::errors);
        return \%my_return;
        }
        return $cfg1;
}
sub load_conf_kv_api
{
    print "xpp, todo it\n";
}
sub uniq_array_api
{
        my ($old_array) = @_;
    my $return_detail;
    my %my_return;
        my $param_str;
        foreach (@_){
                if((!defined($_)) || "$_" eq ""){
                        $my_return{desc} = "input params erro,now params are :$param_str";
                        $my_return{value} = 1;
                        return \%my_return;
                }
                $param_str .= "$_,";
        }
        my %new_hash;
        foreach (@$old_array){
                $new_hash{$_} = 'tmp_item';
        }
        my @new_array = keys %new_hash;
    $my_return{value} = 0;
        $my_return{desc} = \@new_array;
    return \%my_return;
}

sub download_svn_file_api
{
    my ($conf_path,$workspace) = @_;
    my $return_detail;
    my %my_return;
        my ($param) = @_;
        my $param_str;
        foreach (@_){
                if((!defined($_)) || "$_" eq ""){
                        $my_return{desc} = "input params erro,now params are :$param_str";
                        $my_return{value} = 1;
                        return \%my_return;
                }
                $param_str .= "$_,";
        }
    my $pid = $$;
    my $cmd = "mkdir -p $workspace/tmp.$pid && find $workspace/tmp.$pid -name .svn | xargs rm -rf ; svn co $conf_path $workspace/tmp.$pid";
    $return_detail = &run_cmd_api("$cmd",1);
    if("$return_detail->{value}" ne "0"){
        $my_return{value} = 1;
        $my_return{desc} = "svn co fail: $return_detail->{desc}";
        return \%my_return;
    }else{    
        `mv $workspace/tmp.$pid/* $workspace`;
        $my_return{value} = 0;
        $my_return{desc} = "svn co ok,$return_detail->{desc}";
        return \%my_return;
    }
}
sub  download_ftp_file_api
{
        my ($conf_path,$workspace) = @_;
        my $return_detail;
        my %my_return;

    my $pid = $$;
    my $cmd = "mkdir -p $workspace/tmp.$pid && wget $conf_path -P $workspace/tmp.$pid";
        $return_detail = &run_cmd_api("$cmd",1);
        if("$return_detail->{value}" ne "0"){
                $my_return{value} = 1;
                $my_return{desc} = "svn co fail: $return_detail->{desc}";
                return \%my_return;
        }else{          
        
                $my_return{value} = 0;
            `mv $workspace/tmp.$pid/* $workspace/`;
                $my_return{desc} = "svn co ok,$return_detail->{desc}";
                return \%my_return;
        }
}

sub download_local_file_api
{
    my ($conf_path,$workspace) = @_;
    my $return_detail;
    my %my_return;
        my $param_str;

        foreach (@_){
                if((!defined($_)) || "$_" eq ""){
                        $my_return{desc} = "input params erro,now params are :$param_str";
                        $my_return{value} = 1;
                        return \%my_return;
                }
                $param_str .= "$_,";
        }
    my $cmd;
    $return_detail = &check_file_exists_api($conf_path);
    if("$return_detail->{value}" ne "0"){
        $my_return{value} = 1;
        $my_return{desc} = "no such file : $return_detail->{desc}";
        return \%my_return;
    }
    if(-f $conf_path){
        $cmd = "cp -rf $conf_path $workspace"
    }
    if(-d $conf_path){
        $cmd = "cp -rf $conf_path/* $workspace";
    }

    $return_detail = &run_cmd_api("$cmd",1);
    if("$return_detail->{value}" ne "0"){
        $my_return{value} = 1;
        $my_return{desc} = "cp local file fail : $return_detail->{desc}";
        return \%my_return;
    }else{
        $my_return{value} = 0;
        $my_return{desc} = "cp local file ok";
        return \%my_return;
    }

}
sub check_out_mutex_token_api
{
    my ($mutex_token) = @_;
    my $return_detail;
    my %my_return;
        my $param_str;
        foreach (@_){
                if((!defined($_)) || "$_" eq ""){
                        $my_return{desc} = "input params erro,now params are :$param_str";
                        $my_return{value} = 1;
                        return \%my_return;
                }
                $param_str .= "$_,";
        }
    my $cmd = "$MUTEX_SYSTEM_PATH --action unregister --mutex_token $mutex_token";
    $return_detail = &run_cmd_api("$cmd",1);
    if("$return_detail->{value}" ne "0"){
        $my_return{value} = 1;
        $my_return{desc} = $return_detail->{desc};
        return \%my_return;
    }else{
        $my_return{value} = 0;
        $my_return{desc} = $return_detail->{desc};
        return \%my_return;
    }
}

sub check_in_mutex_token_api
{
    my ($pre_mutex_token,$mutex_token,$deploy_id) = @_;
    my $return_detail;
    my %my_return;
        my $param_str;
        foreach (@_){
                if((!defined($_)) || "$_" eq ""){
                        $my_return{desc} = "input params erro,now params are :$param_str";
                        $my_return{value} = 1;
                        return \%my_return;
                }
                $param_str .= "$_,";
        }
    my $cmd = "$MUTEX_SYSTEM_PATH --action register --pre_mutex_token $pre_mutex_token --mutex_token $mutex_token --deploy_id $deploy_id";
    $return_detail = &run_cmd_api("$cmd",1);
    if("$return_detail->{value}" ne "0"){
        $my_return{value} = 1;
        $my_return{desc} = "$return_detail->{desc},cmd=$cmd";
        return \%my_return;
    }else{
        $my_return{value} = 0;
        $my_return{desc} = "mutex check ok,pre_mutex=$pre_mutex_token,mutex=$mutex_token,deploy_id=$deploy_id";
        return \%my_return;
    }

}
sub check_if_four_version_api
{
    my ($version) = @_;
    my $return_detail;
    my %my_return;
        my $param_str;
        foreach (@_){
                if((!defined($_)) || "$_" eq ""){
                        $my_return{desc} = "input params erro,now params are :$param_str";
                        $my_return{value} = 1;
                        return \%my_return;
                }
                $param_str .= "$_,";
        }
    my @tmp_array = split(/\./,$version);
    my $array_num = scalar @tmp_array;
    if($array_num == 4){
        $my_return{value} = 0;
        $my_return{desc} = "it is $array_num version";
        return \%my_return;
    }else{
        $my_return{value} = 1;
        $my_return{desc} = "it is $array_num version";
        return \%my_return;
    }
}
sub trigger_archer_api
{
    my ($param_list) = @_;
    my $return_detail;
    my %my_return;
        my $param_str;
        foreach (@_){
                if((!defined($_)) || "$_" eq ""){
                        $my_return{desc} = "input params erro,now params are :$param_str";
                        $my_return{value} = 1;
                        return \%my_return;
                }
                $param_str .= "$_,";
        }
    $return_detail = &check_file_exists_api($param_list);
    if("$return_detail->{value}" ne "0"){
        $my_return{value} = 1;
        $my_return{desc} = "$return_detail->{desc}";
        return \%my_return;
    }

    $cmd = "$TRIGGER_ARCHER_CMD $param_list";
    print "cmd = $cmd\n";
    $return_detail = &run_cmd_api("$cmd",1);
    if("$return_detail->{value}" ne "0"){
        $my_return{value} = 1;
        $my_return{desc} = "$return_detail->{desc}";
        return \%my_return;
    }else{
        chomp($return_detail->{desc});
        $my_return{value} = 0;
        $my_return{desc} = "$return_detail->{desc}";
        return \%my_return;
    }
}
sub check_archer_status_api
{
    my ($archer_id) = @_;
    my $return_detail;
    my %my_return;
        my $param_str;
        foreach (@_){
                if((!defined($_)) || "$_" eq ""){
                        $my_return{desc} = "input params erro,now params are :$param_str";
                        $my_return{value} = 1;
                        return \%my_return;
                }
                $param_str .= "$_,";
        }
    my $url = "$API_DESC{archer}->{api}->{status_url}->{str}" ."&id=$archer_id";
    my $json_obj = new JSON::XS;
    my $cmd = "curl \'$url\' 2>/dev/null";
    $return_detail= &run_cmd_api("$cmd",1);
    if("$return_detail->{value}" eq "0"){
        chomp($return_detail->{desc});
        $return_detail = &json_decode_api($return_detail->{desc});
        my $status_json = $return_detail->{desc};
        my $status = $status_json->{data}->{status};
        $my_return{value} = 0;
        $my_return{desc} = $status;
        return \%my_return;
    }else{
        $my_return{value} = 1;
        $my_return{desc} = "get archer status fail";
        return \%my_return;
        
    }

}
sub control_archer_api
{
    my ($action,$archer_id,$token) = @_;
    my $return_detail;
    my %my_return;
        my $param_str;
        foreach (@_){
                if((!defined($_)) || "$_" eq ""){
                        $my_return{desc} = "input params erro,now params are :$param_str";
                        $my_return{value} = 1;
                        return \%my_return;
                }
                $param_str .= "$_,";
        }
    if(!exists $ARCHER_CONTROL_ACTION{$action}){
        $my_return{desc} = "No such $action in ARCHER_CONTROL_ACTION of CONFIG.pm";
        $my_return{value} = 1;
        return \%my_return;
    }
    my $json_obj = new JSON::XS;
    my $url = "$API_DESC{archer}->{api}->{control_url}->{str}" ."&listid=$archer_id&action=$action&token=$token";
    my $cmd = "curl \'$url\' 2>/dev/null";
    $return_detail= &run_cmd_api("$cmd",1);
    if("$return_detail->{value}" eq "0"){
        #print Dumper($return_detail->{desc});
        chomp($return_detail->{desc});
        $return_detail = &json_decode_api($return_detail->{desc});
        my $status_json = $return_detail->{desc};
        my $if_success = $status_json->{success};
        if("$if_success" eq "1"){
            $my_return{value} = 0;
            $my_return{desc} = $status_json->{message};
        }else{
            $my_return{value} = 1;
            $my_return{desc} = "archer_id=$archer_id,$status_json->{data}[0]->{error_msg}";
        }
        return \%my_return;
    }else{
        $my_return{value} = 1;
        $my_return{desc} = $return_detail->{desc};
        return \%my_return;
    }
}
sub read_file_content_api
{
    my ($file) = @_;
    my $return_detail;
    my %my_return;
    my $param_str;
    foreach (@_){
        if((!defined($_)) || "$_" eq ""){
                $my_return{desc} = "input params erro,now params are :$param_str";
                $my_return{value} = 1;
                return \%my_return;
        }
        $param_str .= "$_,";
    }
    my $cmd = "cat $file";
    $return_detail = &check_file_exists_api($file);
    if("$return_detail->{value}" ne "0"){
        $my_return{value} = 1;
        $my_return{desc} = "$return_detail->{desc}";
    }else{
        $return_detail = &run_cmd_api("$cmd",1);
        $my_return{desc} = $return_detail->{desc};
        $my_return{value} = 0;
    }

    return \%my_return;
}

sub get_archer_host_api
{
    my ($archer_id) = @_;
    my $return_detail;
    my %my_return;
    my $param_str;
    foreach (@_){
        if((!defined($_)) || "$_" eq ""){
            $my_return{desc} = "input params erro,now params are :$param_str";
            $my_return{value} = 1;
            return \%my_return;
        }
        $param_str .= "$_,";
    }

    my $json_obj = new JSON::XS;
    my $status_json;
    my @host_list;
    my $url = "$API_DESC{archer}->{api}->{status_url}->{str}" ."&id=$archer_id";
    my $cmd = "curl \'$url\' 2>/dev/null";

    $return_detail = &run_cmd_api("$cmd",1);
    if("$return_detail->{value}" ne "0"){
        $my_return{desc} = "get host list fail";
        $my_return{value} = 1;
        return \%my_return;
    }else{
        chomp($return_detail->{desc});
        $return_detail = &json_decode_api($return_detail->{desc});
        $status_json = $return_detail->{desc};
        my @group_list = @{$status_json->{data}->{suGroup}};
        ### �Ƚ����е�groupȡ��������
        foreach my $group (@group_list){
            ### �ٽ�group��Ļ�������ȡ����
            my @host_info_list = @{$group->{machines}};
            foreach my $host_info (@host_info_list){
                my $host = $host_info->{hostName};
                push @host_list,$host;            
            }
        }
    }

    my $host_num = scalar @host_list;
    if($host_num == 0){
        $my_return{desc} = "$archer_id has no host";
        $my_return{value} = 1;
    }else{
        $my_return{desc} = \@host_list;
        $my_return{value} = 0;
    }
    return \%my_return;
}

sub send_msg_by_robot_api
{
    my ($message) = @_;
    my $return_detail;
    my %my_return;
    my $param_str;
    foreach (@_){
        if((!defined($_)) || "$_" eq ""){
            $my_return{desc} = "input params erro,now params are :$param_str";
            $my_return{value} = 1;
            return \%my_return;
        }
        $param_str .= "$_,";
    }
    my $cmd = "echo \"send_grp_msg $HI_GROUP $message \" | nc $HI_MASTER $HI_PORT";
    $return_detail = &run_cmd_api($cmd,1);
    return \%my_return;
}

sub send_message_api
{
    my ($title,$content,$phone) = @_;
    my $return_detail;
    my %my_return;
    my $param_str;
    foreach (@_){
        if((!defined($_)) || "$_" eq ""){
            $my_return{desc} = "input params erro,now params are :$param_str";
            $my_return{value} = 1;
            return \%my_return;
        }
        $param_str .= "$_,";
    }
    my $GSM_SERVER1="tc-sys-monitor00.tc:15001";
    my $GSM_SERVER2="tc-sys-monitor01.tc:15001";
    my $cmd = "/bin/gsmsend -s $GSM_SERVER1 -s $GSM_SERVER2 *3*$phone@\" $title  $content \"";
    $return_detail = &run_cmd_api("$cmd",1);
    if("$return_detail->{value}" ne "0"){
        $my_return{desc} = "failed to send message to $phone";
        $my_return{value} = 1;
    }else{
        $my_return{desc} = "successfully to send message to $phone";
        $my_return{value} = 0;
    }

    return \%my_return;
}

sub call_archer_bm_deploy_api
{
    my ($deploy_id,$module,$level_conf,$alarm_conf,$cm_conf) = @_;
    my $return_detail;
    my %my_return;
    my $param_str;
    foreach (@_){
        if((!defined($_)) || "$_" eq ""){
            $my_return{desc} = "input params erro,now params are :$param_str";
            $my_return{value} = 1;
            return \%my_return;
        }
        $param_str .= "$_,";
    }
    my $json_obj = new JSON::XS;
    my $archer_bm_path = "/home/work/auto-deploy/archer/bm/bin/archer_bm";
    my $cmd = "$archer_bm_path --action deploy --deploy_id $deploy_id --cm_conf $cm_conf --level_conf $level_conf --alarm_conf $alarm_conf --module $module --small_flow 0 &> $Bin/../log/log.$deploy_id";
    $return_detail = &run_cmd_api("$cmd",1);
    if("$return_detail->{value}" ne "0"){
        $my_return{desc} = "����archer_bm�ӿ�ʧ��,cmd=$cmd,$return_detail->{desc}";
        $my_return{value} = 1;
        return \%my_return;
    }else{
        $my_return{desc} = "����archer_bm�ӿڳɹ�";
        $my_return{value} = 0;
        return \%my_return;
    }
}
sub call_BM_deploy_api
{
    my ($module,$delivery_conf,$level_conf,$alarm_conf) = @_;
    my $return_detail;
    my %my_return;
    my $param_str;
    foreach (@_){
        if((!defined($_)) || "$_" eq ""){
            $my_return{desc} = "input params erro,now params are :$param_str";
            $my_return{value} = 1;
            return \%my_return;
        }
        $param_str .= "$_,";
    }
    my $json_obj = new JSON::XS;
    my $cmd = "$AUTO_DEPLOY_PATH --action deploy --module_name $module --delivery_conf $delivery_conf --level_control $level_conf --alarm_conf $alarm_conf --ignore_rollback_cmd";
    $return_detail = &run_cmd_api("$cmd",1);
    if("$return_detail->{value}" ne "0"){
        $my_return{desc} = "�����ӿ�ʧ��,cmd=$cmd,$return_detail->{desc}";
        $my_return{value} = 1;
        return \%my_return;
    }else{
        $my_return{desc} = "�����ӿڳɹ�,cmd=$cmd";
        $my_return{value} = 0;
        return \%my_return;
    }

}
sub call_rollback_api
{
    my ($module,$last_deploy_id) = @_;
    my $return_detail;
    my %my_return;
    my $param_str;
    foreach (@_){
        if((!defined($_)) || "$_" eq ""){
            $my_return{desc} = "input params erro,now params are :$param_str";
            $my_return{value} = 1;
            return \%my_return;
        }
        $param_str .= "$_,";
    }
    my $json_obj = new JSON::XS;
    my $cmd = "$AUTO_DEPLOY_PATH --action rollback --module_name $module --last_deploy_id $last_deploy_id";
    $return_detail = &run_cmd_api("$cmd",1);
    if("$return_detail->{value}" ne "0"){
        $my_return{desc} = "�����ع��ӿ�ʧ��,�����ֶ��ع�,cmd=$cmd,$return_detail->{desc}";
        $my_return{value} = 1;
    }else{
        $my_return{desc} = "�����ع��ӿڳɹ�,���ע�ع�����,cmd=$cmd";
        $my_return{value} = 0;
    }

    return \%my_return;
}

sub call_qa_check_api
{
    my ($taskid) = @_;
    my $return_detail;
    my %my_return;
    my $param_str;
    foreach (@_){
        if((!defined($_)) || "$_" eq ""){
            $my_return{desc} = "input params erro,now params are :$param_str";
            $my_return{value} = 1;
            return \%my_return;
        }
        $param_str .= "$_,";
    }
    my $json_obj = new JSON::XS;
    my $return_hash;
    my $base_url = "http://cq01-testing-www2009.cq01.baidu.com:8800/json/";
    my $param_id = $taskid;
    ### �½�һ��caseִ����������params����taskid
    my $trigger_url = "\"$base_url\" -d " . "'{\"id\":\"jsonrpc\", \"params\":[$param_id], \"method\":\"task_mgr.create_task_from_requirement\", \"jsonrpc\":\"1.0\"}'";
    my $cmd = "curl $trigger_url";
    print "cmd=$cmd\n";
    $return_detail = &run_cmd_api("$cmd",1);
    if("$return_detail->{value}" ne "0"){
        $my_return{desc} = "failed to curl qa url : $trigger_url,cmd = $cmd";
        $my_return{value} = 1;
        return \%my_return;
    }else{
        chomp($return_detail->{desc});
        $return_detail = &json_decode_api($return_detail->{desc});
        $return_hash = $return_detail->{desc};

        if((!defined($return_hash->{error})) || "$return_hash->{error}" eq "null"){
            $param_id = $return_hash->{result}->{group_id};
            $my_return{desc}->{result}->{group_id} = $return_hash->{result}->{group_id};
            print "param_id = $param_id\n";
        }else{
            $my_return{desc} = "failed to build a task,$return_detail->{desc}";
            $my_return{value} = 1;
            return \%my_return;
        }

    }
    ### ������һ����ȡ��idȥ�鿴case��״̬
    my $check_status_url = "\"$base_url\" -d " . "'{\"id\":\"jsonrpc\", \"params\":[$param_id], \"method\":\"task_mgr.get_group_info\", \"jsonrpc\":\"1.0\"}'";
    print "cmd = $cmd \n";
    $cmd = "curl $check_status_url";
    $return_detail = &run_cmd_api("$cmd",1);
    if("$return_detail->{value}" ne "0"){
        $my_return{desc} = "failed to curl qa url : $check_status_url,cmd=$cmd";
        $my_return{value} = 1;
        return \%my_return;
    }else{
        chomp($return_detail->{desc});
        $return_detail =  &json_decode_api($return_detail->{desc});
        $return_hash = $return_detail->{desc};

        print Dumper($return_hash);
        if((!defined($return_hash->{error})) || "$return_hash->{error}" eq "null"){
            #$param_id = $return_hash->{result}->{group_id};
            $my_return{desc}->{result}->{group_report_id} = $return_hash->{result}->{group_report_id};
            $my_return{desc}->{result}->{group_report_page} = $return_hash->{result}->{group_report_page};
            print "param_id = $param_id\n";
            $my_return{value} = 0;
            return \%my_return;
        }else{
            $my_return{desc} = "fail to get report url";
            $my_return{value} = 1;
            return \%my_return;
        }
    }
}

sub send_mail_api
{
    my ($title,$content,$member) = @_;
    my $return_detail;
    my %my_return;
        my $param_str;
        foreach (@_){
                if((!defined($_)) || "$_" eq ""){
                        $my_return{desc} = "input params erro,now params are :$param_str";
                        $my_return{value} = 1;
                        return \%my_return;
                }
                $param_str .= "$_,";
        }
    my $cmd = "echo \"$content\" | formail -I To:$member -I From: -I MIME-Version:1.0 -I \'Content-type:text/html;charset=gb2312\' -I \'Subject:$title\' | /usr/sbin/sendmail -oi -t";

    print "cmd=$cmd\n";
    $return_detail = &run_cmd_api("$cmd",1);
    if("$return_detail->{value}" ne "0"){
        $my_return{desc} = "send mail failed,cmd=$cmd";
        $my_return{value} = 1;
        return \%my_return;
    }else{    
        $my_return{desc} = "send mail to $member ok,cmd=$cmd";
        $my_return{value} = 0;
        return \%my_return;
    }
}

sub set_default_roadmap_api
{
    my ($module,$data) = @_;
    my $return_detail;
    my %my_return;
        my $param_str;
        foreach (@_){
                if((!defined($_)) || "$_" eq ""){
                        $my_return{desc} = "input params erro,now params are :$param_str";
                        $my_return{value} = 1;
                        return \%my_return;
                }
                $param_str .= "$_,";
        }
    $my_return{value} = 0;
        $my_return{desc} = "xpp,todo";
    return \%my_return;



    my $cmd = "$ROADMAP_PATH --action set_default_release_id --module_name $module  --data \'$data\'";
    $return_detail = &run_cmd_api("$cmd",1);
    if("$return_detail->{value}" ne "0"){
        $my_return{desc} = "$return_detail->{desc},cmd=$cmd";
        $my_return{value} = 1;
        return \%my_return;
    }else{
        $my_return{desc} = "$return_detail->{desc},cmd=$cmd";
        $my_return{value} = 0;
        return \%my_return;
    }
}

sub add_roadmap_api
{
    my ($module,$level_unit,$data) = @_;
    my $return_detail;
    my %my_return;
        my $param_str;
        foreach (@_){
                if((!defined($_)) || "$_" eq ""){
                        $my_return{desc} = "input params erro,now params are :$param_str";
                        $my_return{value} = 1;
                        return \%my_return;
                }
                $param_str .= "$_,";
        }
    $my_return{desc} = "xpp,todo";
    $my_return{value} = 0;
    return \%my_return;

    my $cmd = "$ROADMAP_PATH --action add --module_name $module --level_unit $level_unit --data \'$data\'";
    $return_detail = &run_cmd_api("$cmd",1);
    if("$return_detail->{value}" ne "0"){
        $my_return{desc} = "$return_detail->{desc},cmd=$cmd";
        $my_return{value} = 1;
        return \%my_return;
    }else{
        $my_return{desc} = "$return_detail->{desc},cmd=$cmd";
        $my_return{value} = 0;
        return \%my_return;
    }

}

sub call_delete_badhost_api
{
    my ($badhost_module,$badhost_idc,$if_check_badhost_service,$servers_des) = @_;
    my $return_detail;
    my %my_return;
    my $param_str;
    foreach (@_){
        if((!defined($_)) || "$_" eq ""){
            $my_return{desc} = "input params erro,now params are :$param_str";
            $my_return{value} = 1;
            return \%my_return;
        }
        $param_str .= "$_,";
    }
    ### �ȴ������ϻ����޳�
    #my $trigger_build_badhost = "$Bin/../tools/trigger_build_badhost $badhost_module $badhost_idc $if_check_badhost_service $servers_des";
    my $trigger_build_badhost = "/home/work/auto-deploy/archer/bm/tools/trigger_build_badhost $badhost_module $badhost_idc $if_check_badhost_service $servers_des";
    print "cmd = $trigger_build_badhost\n";
    $return_detail = &run_cmd_api("$trigger_build_badhost",1);
    print Dumper($return_detail);
    if("$return_detail->{value}" ne "0"){
        $my_return{value} = 1;
        $my_return{desc} = $return_detail->{desc};
        return \%my_return;
    }

    ### �˲��ǻ�ȡԶ�̼��õĹ��ϻ����б�������,tc-psop-sys01.tc
    my $bad_host_url = "$BADHOST_API" . "_" . "$badhost_module" . '_' . "$badhost_idc";
    my $badhost_dir = "$Bin/../data/badhost/$$";
    my $badhost = "$badhost_dir/badhost";
    my $cmd = "mkdir -p $badhost_dir";
    $return_detail = &run_cmd_api("$cmd",1);

    my $wget_badhost = "wget $bad_host_url -P $badhost_dir -O $badhost ";
    print "cmd = $wget_badhost\n";
    $return_detail = &run_cmd_api("$wget_badhost",1);
    print Dumper($return_detail);
    if("$return_detail->{value}" ne "0"){
        $my_return{value} = 1;
        $my_return{desc} = $return_detail->{desc};
        return \%my_return;
    }

    ### �˲��ǽ����ϻ�����server.des�����޳�
    my $del_bad_host = "$Bin/../tools/del_bad_host $badhost $servers_des";
    print "cmd = $del_bad_host\n";
    #$return_detail = &run_cmd_api("$cmd",1);
    $return_detail = &run_cmd_api("$del_bad_host",1);
    if("$return_detail->{value}" ne "0"){
        $my_return{value} = 1;
        $my_return{desc} = $return_detail->{desc};
        return \%my_return;
    }

    $my_return{value} = 0;
    $my_return{desc} = "[ok]badhost=$badhost,new server.des= $servers_des";
    return \%my_return;
    
}

sub check_parameters
{
    my %my_return;
    my $param_str = "";

    foreach (@_){
        if((!defined($_)) || "$_" eq ""){
            $my_return{desc} = "input params erro,now params are :$param_str";
            $my_return{value} = 1;
            return \%my_return;
        }
        $param_str .= "$_,";
    }

    $param_str =~ s/,$//g;

    $my_return{desc} = "input params is ok, all params are: $param_str";
    $my_return{value} = 0;

    return \%my_return;
}
sub call_BM_api
{
    my ($param) = @_;
    my $return_detail;
    my %my_return;
    my $param_str;
    foreach (@_){
        if((!defined($_)) || "$_" eq ""){
            $my_return{desc} = "input params erro,now params are :$param_str";
            $my_return{value} = 1;
            return \%my_return;
        }
        $param_str .= "$_,";
    }
    $my_return{desc} = "xpp,this is a trick api";
    $my_return{value} = 0;
    return \%my_return;
}
sub get_check_result_from_dk_api
{
    my ($deploy_id,$level) = @_;
    my $return_detail;
    my %my_return;
    my $param_str;
    foreach (@_){
        if((!defined($_)) || "$_" eq ""){
            $my_return{desc} = "input params erro,now params are :$param_str";
            $my_return{value} = 1;
            return \%my_return;
        }
        $param_str .= "$_,";
    }
    my $cmd = "perl /home/work/opbin/dk/bin/carrier.pl -i $deploy_id -l $level ";
    $return_detail = &run_cmd_api("$cmd",1);
    if("$return_detail->{value}" ne "0"){
        $my_return{value} = 1;
        $my_return{desc} = $return_detail->{desc};
        return \%my_return;
    }else{
        $my_return{value} = 0;
        $my_return{desc} = $return_detail->{desc};
        return \%my_return;
    }

}
sub xpp
{
    my ($param) = @_;
    my $return_detail;
    my %my_return;
    my $param_str;
    foreach (@_){
        if((!defined($_)) || "$_" eq ""){
            $my_return{desc} = "input params erro,now params are :$param_str";
            $my_return{value} = 1;
            return \%my_return;
        }
        $param_str .= "$_,";
    }
}


1;
