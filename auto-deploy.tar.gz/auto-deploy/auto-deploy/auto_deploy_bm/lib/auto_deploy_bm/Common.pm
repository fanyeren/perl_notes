package auto_deploy_bm::Common;
BEGIN
{
	use Exporter();
	use vars qw($VERSION @ISA @EXPORT);
	use Data::Dumper;
	use strict;
	use File::Basename;
	use Carp;
	use FindBin qw($Bin);
	use lib "$Bin/../lib/";
	use JSON::XS;
	use CONFIG;
	use Config::IniFiles;
	@ISA = qw(Exporter);
	@EXPORT = qw (
		&usage &myexit &run_cmd_api
		&check_is_item_in_hash_api 
		&load_conf_ini_api
		&load_conf_json_api
		&update_global_status_table_api
		&load_conf_key_value
	);
}


sub usage
{
print <<EOF;
Usage: $PROGNAME [OPTION]
Description:
	Start the auto deploy

	--action=[pause|continue|stop|deploy] : Specified operation
	--delivery_conf=[deliver_conf_file_path] : Specified the dop/archer conf file
	--deploy_id=[deploy_id] : Specified the deploy id
	--module_name=[module_name] : Specified the module name
exp:
	$PROGNAME --action deploy --module_name ps/se/ac --delivery_conf ./deliver_conf_file
	$PROGNAME --action pause --module_name ps/se/ac --deploy_id 123456
EOF
}


sub myexit
{
	my ($retstring) = @_;
	my $json_obj = new JSON::XS;
	my $return_message = $json_obj->encode($retstring);
	print STDOUT "return_message:".$return_message."\n";
	print STDOUT "return_value:".$retstring->{return_value}."\n";
	if(defined($retstring->{deploy_id})) {
		print STDOUT "deploy_id:$retstring->{deploy_id}\n"
	}
	if(defined($retstring->{dis_url})) {
		print STDOUT "\n";
		print STDOUT "===========================   start succ, check the url=====================\n";
		print STDOUT "<a href=\"$retstring->{dis_url}\">$retstring->{dis_url}</a>\n";
		print STDOUT "============================================================================\n";
		print STDOUT "\n";
	}
	exit($retstring->{return_value});
}
sub check_is_item_in_hash_api
{
	my ($check_item, $opt_long_value) = @_;
	my %return_value;
	my $ret = 0;
	my $ret_desc = "check param succ"; 

	foreach my $item(@{$check_item}) {
		if(!defined($opt_long_value->{$item}) || "$opt_long_value->{$item}" eq "") {
			$ret = 1;
			$ret_desc = "$item is null or not defined; ";
			last;
		}
	}
	$return_value{return_value} = $ret;
	$return_value{desc} = "$ret_desc";
	return \%return_value;
}


sub load_conf_ini_api
{
	my ($conf_file) = @_;
	my $cfg1 = Config::IniFiles->new( -file => $conf_file );
	return $cfg1;
	
}

sub load_conf_json_api
{
	my ($conf_file)	= @_;
	my $json;
	my %return_detail;
	open JSON_FILE,$conf_file;
	while(<JSON_FILE>)
	{
	        $json.=$_;
	}

	my $js= new JSON::XS;
	my $obj;
        eval {
		$obj = $js->decode($json);
	};
	if($@) {
		$return_detail{return_desc} = "$@";
		$return_detail{return_value} = 1;
		return \%return_detail;
	}
	close JSON_FILE;
	$return_detail{return_desc} = $obj;
	$return_detail{return_value} = 0;
	return \%return_detail;
}

sub load_conf_key_value
{
	my ($conf_file, $conf_desc) = @_;
	my %logstr;
	my $result;
	my $funcName = (caller(0))[3];
	my %conf_detail;


	my $fh;
	if (!open($fh,$conf_file)) {
		$logstr{desc} = "open the conf file failed for:$!";
		$logstr{conf_file} = "$conf_file";
		$logstr{cmd} = "$funcName";
		$logstr{ret} = 1;
		return (\%logstr);
	}

	my $line;
	while ($line = <$fh>) {
		if($line =~ m/^\s*#.*/ || $line =~ /^\s+$/) {
			next;
		} else {
			##ɾ�����׺���β�Ŀ���
			$line =~ s/^\s+//g;
			$line =~ s/\s+$//g;
		}
		my ($key, $value) = split("$conf_desc", $line);
		$key =~ s/\s+//g;
		$value =~ s/\s+//g;
		## ȥ������
		$value =~ s/\"//g;
		$value =~ s/\'//g;
		$conf_detail{$key} = $value;
	}
	close($fh);

	$logstr{cmd} = "$funcName";
	$logstr{return_desc} = \%conf_detail;
	$logstr{return_value} = 0;
	return \%logstr;
}
sub run_cmd_api
{
	my ($cmd, $max_retry_time) = @_;

	my $retry_time = 0;
	my $start_time;
	my $end_time;
	my $con_time;
	my %return_hash;
	
	$return_hash{return_desc} = "";
	while ($retry_time < $max_retry_time) {
		$start_time = time;
		$return_hash{return_desc} = `$cmd`;
		$return_hash{return_value} = $?>>8;
		$end_time = time;
		$con_time = sprintf("%.3f", $end_time - $start_time);
		if ($return_hash{return_value} != 0) {
			sleep(3);
			$retry_time++;
		} else {
			last;
		}
	}
	return \%return_hash;
}
1;
