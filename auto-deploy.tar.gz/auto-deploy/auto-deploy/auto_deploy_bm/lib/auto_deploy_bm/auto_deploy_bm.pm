package auto_deploy_bm::auto_deploy_bm;
BEGIN
{
	use Exporter();
	use vars qw($VERSION @ISA @EXPORT);
	use Data::Dumper;
	use File::Basename;
	use Fcntl qw(:flock);
	use FindBin qw($Bin);
	use strict;
	use lib "$Bin/../lib";
	use lib "$Bin/../conf";
	use Time::HiRes qw(time);
	use CONFIG;
	use JSON::XS;
	use auto_deploy_bm::Common;
	@ISA = qw(Exporter);
	@EXPORT = qw();
}

sub new {
	my ($type, $logit, $json_obj, $param)    =   @_;
	$this->{logit} = $logit;
	$this->{json_obj} = $json_obj;
	$this->{param} = $param;
	$this->{top_path} = "$Bin/../";
	$this->{svn} = "$SVN_TOOL --config-dir /home/work/mengalong/svn-config --username=mengalong ";
	$this->{data_top_path} = "$this->{top_path}/data/";

	bless $this;
	
	return $this;
}


sub check_param
{
	my ($this) = @_;

	my @need_to_check_key = ("module_name", "action");
	my $return_detail;


	$return_detail = $this->check_is_item_in_hash(\@need_to_check_key, $this->{param});
	$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
	if($return_detail->{return_value} != 0) {
		return $return_detail;
	}

	$this->{module_name_alias} = $this->{param}->{module_name};
	$this->{module_name_alias} =~ s#/#:#g;
	my $action = $this->{param}->{action};
	my %return_hash = ();
	my $need_check_it_flag = 0;
	foreach($action) {
		SWITCH : {
			/prepare/ && do {
				@need_to_check_key = ("delivery_conf", "alarm_conf", "level_control");
				$need_check_it_flag = 1;
				last SWITCH;

			};
			/create_rollback_cmd/ && do {
				@need_to_check_key = ("deploy_id","small_flow");
				$need_check_it_flag = 1;
				last SWITCH;
			};
			/deploy/ && do {
				@need_to_check_key = ("deploy_id","small_flow");
				$need_check_it_flag = 1;
				last SWITCH;
			};
			/rollback/ && do {
				@need_to_check_key = ("last_deploy_id");
				$need_check_it_flag = 1;
				last SWITCH;
			};
			DEFAULT : $return_hash{return_value} = "$ERR_NUM{AOS_CHECK_PARAM_ERROR}";
				$return_hash{return_desc} = "invalid action:$action";
				$return_detail = \%return_hash;
		}
	}

	if($need_check_it_flag == 1) {
		$return_detail = $this->check_is_item_in_hash(\@need_to_check_key, $this->{param});
	}
	$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
	return $return_detail;
}

sub check_is_item_in_hash 
{
	my ($this, $need_to_check_item, $hash_detail) = @_;
	my $return_detail;
	$return_detail  = &check_is_item_in_hash_api($need_to_check_item, $hash_detail);
	return $return_detail;
}

sub get_conf_from_cm
{
	my ($this) = @_;
	my %return_hash;
	my $cm_conf_obj;

	my $module_name_alias = $this->{module_name_alias};
	my $CMD = "$CM_BIN -s dyndata-meta get-meta-all --dyndata-meta-id=$module_name_alias";
	$return_detail = $this->run_cmd("$CMD", 1);

	if($return_detail->{return_value} != 0) {
		$return_detail->{return_desc} = "exec the cmd $CMD failed";
		$this->{logit}->printLog($this->{logit}->{FATAL}, $return_detail);
		$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
		return $return_detail;
	}
	eval {
		$cm_conf_obj = $this->{json_obj}->decode($return_detail->{return_desc});
	};
	if($@) {
		$return_hash{return_desc} = "get conf from cm failed for:$@";
		$return_hash{return_value} = "$ERR_NUM{AOS_GET_CM_CONF_ERROR}";
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%return_hash);
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%return_hash);
		return \%return_hash;
	}
	$this->{conf}->{cm_conf} = $cm_conf_obj;
	#��������Ϣд���ļ�
	$this->{cm_conf_file} = "$this->{data_path}/cm.conf";
	$return_detail = $this->write_string_to_file("$return_detail->{return_desc}",$this->{cm_conf_file});
	if($return_detail->{return_value} != 0) {
		$this->{logit}->printLog($this->{logit}->{FATAL}, $return_detail);
		$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
		return $return_detail;
	}
	$return_hash{return_value} = 0;
	$return_hash{return_desc} = "write cm_conf file succ";
	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%return_hash);

	return \%return_hash;
}


sub write_string_to_file
{
	my ($this, $need_write_string, $filename) = @_;;
	my $FH;
	my %return_detail;
	my $dir_name = dirname($filename);
	`mkdir -p $dir_name`;
	if(!open($FH, ">$filename")) {
		$return_detail{return_value} = 1;
		$return_detail{return_desc} = "open file $filename failed";
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%return_detail);
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%return_detail);
		return \%return_detail;
	}
	print $FH "$need_write_string";
	close($FH);
	$return_detail{return_value} = "0";
	$return_detail{return_desc} = "write $filename succ";
	return \%return_detail;
}
sub run_cmd
{
	my ($this, $CMD, $retry_time) = @_;
	my $return_detail = &run_cmd_api("$CMD", $retry_time);
	return $return_detail;
}
#
#���������ļ�
#
sub load_conf
{
	return 0;
}

#
#���������ļ�
#
sub load_conf_detail {
	my ($this, $conf_file,$conf_desc) = @_;
	my $conf_detail;
	my %logstr;

	$logstr{return_desc} = "load conf file $conf_file succ";
	$logstr{return_value} = 0;
	if("$conf_desc->{conf_type}" eq "json") {
		$conf_detail = &load_conf_json_api($conf_file);
	} elsif ("$conf_desc->{conf_type}" eq "ini") {
		$conf_detail = &load_conf_ini_api($conf_file);
	} elsif ("$conf_desc->{conf_type}" eq "key_value") {
		$conf_detail = &load_conf_key_value($conf_file, $conf_desc->{split_item});
	} else {
		$logstr{return_desc} = "load conf file $conf_file failed for unknow conf_type.$conf_desc->{conf_type}";
		$logstr{return_value} = 1;

		$this->{logit}->printLog($this->{logit}->{FATAL}, \%logstr);
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
		return \%logstr;
	}

	if($conf_detail->{return_value} == 0) {
		$this->{conf}->{$conf_desc->{conf_key}} = $conf_detail->{return_desc};
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
	} else {
		$logstr{return_desc} = "load the conf $conf_file failed for $conf_detail->{return_desc}";
		$logstr{return_value} = $conf_detail->{return_value};
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
		$this->{logit}->printLog($this->{logit}->{FATAL}, \%logstr);
	}
	return \%logstr;
}

sub do_prepare
{
	my ($this) = @_;
	my $deploy_id;
	my $return_detail;
	my %logstr;

	#����dataĿ¼
	$return_detail = $this->prepare_data_path();
	if($return_detail->{return_value} != 0) {
		return $return_detail;
	}

	#��ȡcm_conf
	$return_detail = $this->get_conf_from_cm();
	if($return_detail->{return_value} != 0) {
		return $return_detail;
	}

	#����ָ���������ļ���dataĿ¼
	$return_detail = $this->copy_conf_file();
	if($return_detail->{return_value} != 0) {
		return $return_detail;
	}
	
	#���ݵ�ǰ��״���������յ�level.confͬʱ��ŵ�ָ��·��
	$return_detail = $this->generate_level_conf();
	if($return_detail->{return_value} != 0) {
		return $return_detail;
	}

	#�������ɵ������ļ���ŵ�svn��
	my $source_path = "$this->{data_top_path}/$this->{deploy_id}/update_conf";
	my $target_path = "$DATA_CONF_SVN_TOP_DIR/$this->{deploy_id}/update_conf";
	$return_detail = $this->put_data_path_to_svn("$source_path", "$target_path");
	if($return_detail->{return_value} != 0) {
		$return_detail->{return_desc} = "put the new conf to svn failed for: $return_detail->{return_desc}"; 
                $this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
		return $return_detail;
	} else {
		$return_detail->{return_desc} = "put the new conf to svn succ"; 
                $this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
	}
	return $return_detail;

}
sub prepare_data_path
{
	my ($this) = @_;
	my $deploy_id;
	my $return_detail;
	my %logstr;

	$deploy_id = `date +%s`;
	chomp($deploy_id);
	$this->{deploy_id} = $deploy_id;
	#$this->{data_path} = "$this->{top_path}/data/$this->{module_name_alias}/$deploy_id/update_conf/";
	#$this->{data_top_path} = "$this->{top_path}/data/";
	$this->{data_path} = "$this->{data_top_path}/$deploy_id/update_conf/";

	#���·�������ߵ�ʱ������delivery.conf ��ŵ�·��
	#�����Ҫ��deploy��ߵı���һ�£����޸�level.conf��ߵ�conf_path
	$this->{data_path_to_deploy} = "$this->{data_top_path}/deploy/$this->{deploy_id}/update_conf";

	my $CMD = "mkdir -p $this->{data_path}";
	$return_detail = $this->run_cmd($CMD, 1);
	if($return_detail->{return_value} != 0) {
		$return_detail->{desc} = "exec $CMD failed";
		$this->{logit}->printLog($this->{logit}->{FATAL}, $return_detail);
		$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
		return $return_detail;
	}


	$logstr{return_value} = 0;
	$logstr{desc} = "exec prepare_data_path succ";
	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
	return \%logstr;
}


sub prepare
{
	my ($this) = @_;
	my $deploy_id;
	my $return_detail;
	my %logstr;

	$deploy_id = `date +%s`;
	chomp($deploy_id);
	$this->{deploy_id} = $deploy_id;
	$this->{data_path} = "$this->{top_path}/data/$this->{module_name_alias}/$deploy_id";

	my $CMD = "mkdir -p $this->{data_path}";
	$return_detail = $this->run_cmd($CMD, 1);
	if($return_detail->{return_value} != 0) {
		$return_detail->{desc} = "exec $CMD failed";
		return $return_detail;
	}


	$logstr{return_value} = 0;
	$logstr{desc} = "exec $CMD succ";
	return \%logstr;
}

sub copy_conf_file()
{
	my ($this) = @_;
	my $CMD;
	my $return_detail;

	my $filename;
	my $source_file;
	my $target_file;
	foreach $filename(keys(%FILE_TO_COPY)) {
		$source_file = $this->{param}->{$filename};
		$target_file = "$this->{data_path}/$FILE_TO_COPY{$filename}";
		$return_detail = $this->copy_file_api($source_file, $target_file);
		if($return_detail->{return_value} != 0) {
			$return_detail->{return_desc} = "exec copy conf file failed";
			$this->{logit}->printLog($this->{logit}->{FATAL}, $return_detail);
			$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
			return $return_detail;
		}
	}
	$return_detail->{return_desc} = "exec copy conf file succ";
	$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
	return $return_detail;
}

sub copy_file_api()
{
	my ($this, $source_file, $target_file) = @_;
	my $CMD;
	my $return_detail;
	
	my $dir_name = dirname($target_file);
	`mkdir -p $dir_name`;
	$CMD = "cp $source_file $target_file 2>&1";
	$return_detail = $this->run_cmd($CMD, 1);
	if($return_detail->{return_value} != 0) {
		$return_detail->{return_desc} = "exec $CMD failed for:$return_detail->{return_desc}";
		$this->{logit}->printLog($this->{logit}->{FATAL}, $return_detail);
		$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
	} else {
		$return_detail->{return_desc} = "exec $CMD succ";
		$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
	}
	return $return_detail;
}

sub generate_level_conf
{
	my ($this) = @_;
	my %conf_desc = (
		"conf_type" => "json",
		"conf_key" => "level_control_conf",
	); 
	my $level_conf_from_user = "$this->{data_path}/$FILE_TO_COPY{level_control}";
	my $return_detail;

	#����ԭʼ��level.conf
	$return_detail = $this->load_conf_detail($level_conf_from_user, \%conf_desc);
	if($return_detail->{return_value} != 0) {
		$return_detail->{return_desc} = "generate the level_control failed";
		$this->{logit}->printLog($this->{logit}->{FATAL}, $return_detail);
		$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
		return $return_detail;
	} 
	
	#�޸�level.conf �����������µ�����
	my $level_name;
	my $idc_name;
	my $level_conf_obj = $this->{conf}->{level_control_conf};
	foreach $level_name (keys(%{$level_conf_obj->{level_control}})) {
		foreach $idc_name (keys(%{$level_conf_obj->{level_control}->{$level_name}->{idc}})) {
			#$level_conf_obj->{level_control}->{$level_name}->{idc}->{$idc_name}->{conf_path} = "$this->{data_path}";
			$level_conf_obj->{level_control}->{$level_name}->{idc}->{$idc_name}->{conf_path} = "$this->{data_path_to_deploy}";
			$level_conf_obj->{level_control}->{$level_name}->{idc}->{$idc_name}->{protocol} = "local";
		}
	}
	$this->{conf}->{level_control_conf} = $level_conf_obj;

	#�������ɵ�level.conf ��ʽ���洢,ͬʱ�޸�$this->{param}->{level_conf} ��·��
	my $json_pretty_str;
	$json_pretty_str = $this->{json_obj}->pretty->encode($level_conf_obj);
	$this->{param}->{level_control_final} = "$this->{data_path}/level.conf";
	$return_detail = $this->write_string_to_file("$json_pretty_str",$this->{param}->{level_control_final});
	if($return_detail->{return_value} != 0) {
		$this->{logit}->printLog($this->{logit}->{FATAL}, $return_detail);
		$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
		return $return_detail;
	} else {
		$return_detail->{return_desc} = "generate level.conf succ";
		$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
	}

	return $return_detail;
}

sub put_data_path_to_svn
{
	my ($this, $source_path, $target_path) = @_;
	#my ($this, $data_relative_path) = @_;
	#my $source_path = "$this->{data_top_path}/$data_relative_path";
	#my $target_path = "$DATA_CONF_SVN_TOP_DIR/$data_relative_path";

	#��import֮ǰ�ȳ���ɾ��һ��Զ�̵�Ŀ¼,��ʱ���Է���ֵ
	my $CMD;
	$CMD = "$this->{svn} del $target_path -m \"try to del $target_path\" &>/dev/null";
	$return_detail = $this->run_cmd("$CMD", 1);
	$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);

	$CMD = "$this->{svn} import $source_path -m \"add the $this->{param}->{module_name} data for $source_path\" $target_path | egrep \"Committed revision\"";
	my $return_detail = $this->run_cmd($CMD, 1);
	if($return_detail->{return_value} != 0) {
		$return_detail->{return_desc} = "exec $CMD failed for:$return_detail->{return_desc}";
		$this->{logit}->printLog($this->{logit}->{FATAL}, $return_detail);
		$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
	} else {
		$return_detail->{return_desc} = "exec $CMD succ for: $return_detail->{return_desc}";
		$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
	}
	return $return_detail;
}



sub do_create_rollback_cmd
{
	my ($this) = @_;
	my $return_detail;
	my %logstr;


	$this->prepare_create_rollback_cmd();

	#׼���ع���Ҫ�������ļ�
	my %conf_desc = (
                "conf_type" => "json",
                "conf_key" => "level_control_conf",
        );
        my $level_conf_final = "$this->{param}->{level_control_final}";

        #����ԭʼ��level.conf�� $this->{conf}->{level_contrl_conf}
        $return_detail = $this->load_conf_detail($level_conf_final, \%conf_desc);
        if($return_detail->{return_value} != 0) {
                $return_detail->{return_desc} = "load the level_control failed";
                $this->{logit}->printLog($this->{logit}->{FATAL}, $return_detail);
                $this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
                return $return_detail;
        }

	#��ȡlevel_control�еĸ���idc��release_id
	$return_detail = $this->generate_level_idc_release_deploy_id();
	if($return_detail->{return_value} != 0){
		return $return_detail;
	}

#print Dumper($this->{conf}->{level_control_conf});

	#����release_id��ȡ���� idc �����������ļ�
	$return_detail = $this->get_all_release_data();
	if($return_detail->{return_value} != 0){
		return $return_detail;
	}


	#���ɲ�ͬ��idc�Ļع������ļ�����һ����ȡ�������ÿ����� rollback_conf/�±�
	#ͬʱ�������ļ���ŵ�svn
	$return_detail = $this->create_rollback_conf_data();
	if($return_detail->{return_value} != 0){
		return $return_detail;
	}
	return $return_detail;
	
}


sub prepare_create_rollback_cmd
{
	my ($this) = @_;

	$this->{deploy_id} = $this->{param}->{deploy_id};
	$this->{data_path} = "$this->{data_top_path}/$this->{deploy_id}";
	$this->{rollback_data_conf_path} = "$this->{data_path}/rollback_conf"; #������ջع���Ҫ��delivery.conf��cm.conf etc..

	#���·������Ҫ��׼���ع����õ�ʱ���޸�level.conf �е�conf_path �ֶ�
	#�����ִ�лع���ʱ�������ļ�������·����Ҫ����һ��
	$this->{data_path_rollback} = "$this->{data_top_path}/deploy/$this->{deploy_id}/rollback_conf/public";	

	$this->{param}->{level_control_final} = "$this->{data_path}/update_conf/level.conf";
	$this->{param}->{alarm_conf} = "$this->{data_path}/update_conf/alarm.conf";
	$this->{param}->{delivery_conf} = "$this->{data_path}/update_conf/delivery.conf";
	$this->{param}->{cm_conf} = "$this->{data_path}/update_conf/cm.conf";
}


sub generate_level_idc_release_deploy_id
{
	my ($this) = @_;
	my $level_name;
	my $idc_name;
	
	my $level_conf_obj;
	my $level_unit;
	my $last_deploy_id;
	my $return_detail;
	my %logstr;

	$level_conf_obj = $this->{conf}->{level_control_conf};
	foreach $level_name (keys(%{$level_conf_obj->{level_control}})) {
		foreach $idc_name (keys(%{$level_conf_obj->{level_control}->{$level_name}->{idc}})) {
			$level_unit = "$level_name.idc.$idc_name";
			$return_detail = $this->get_release_id_by_unit($level_unit);	
			if($return_detail->{return_value} != 0) {
				$return_detail->{return_desc} = "get the unit $level_unit release id failed for:$return_detail->{return_desc}";
                		$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
				return $return_detail;
			} else {
				$level_conf_obj->{level_control}->{$level_name}->{idc}->{$idc_name}->{last_deploy_id} = "$this->{deploy_id}";
				chomp($return_detail->{return_id});
				$level_conf_obj->{level_control}->{$level_name}->{idc}->{$idc_name}->{current_release_id} = "$return_detail->{return_id}";
                		$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
			}
		}
	}

	$this->{conf}->{level_control_conf} = $level_conf_obj;
	$logstr{return_desc} = "generate level idc release id succ";
	$logstr{return_value} = 0;	
	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
	return \%logstr;
}

sub get_release_id_by_unit
{
	my ($this, $level_unit) = @_;
	my $return_detail;
	my %return_data;

	#���������rollback_to_deploy_id ��ʹ��ָ����rollback_to_deploy_id ��Ϊ�ع���deploy_id
	if("$this->{param}->{rollback_to_deploy_id}" ne "") {
		$return_data{return_id} =  $this->{param}->{rollback_to_deploy_id};
		$return_data{return_value} = 0;
		$return_data{return_desc} = "assign deploy_id is $this->{param}->{rollback_to_deploy_id}";
                $this->{logit}->printLog($this->{logit}->{NOTICE}, \%return_data);
		return \%return_data;
	}

	my $CMD = "$ROAD_MAP_BIN --action get_release_id --module_name $this->{param}->{module_name} --level_unit $level_unit";
	$return_detail = $this->run_cmd($CMD, 1);
        if($return_detail->{return_value} != 0) {
                $return_data{return_desc} = "exec $CMD failed for:$return_detail->{return_desc}";
		$return_data{return_value} = $return_detail->{return_value};
                $this->{logit}->printLog($this->{logit}->{FATAL}, $return_detail);
                $this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
        } else {
		$return_data{return_id} = $return_detail->{return_desc};
		$return_data{return_value} = 0;
                $return_detail->{return_desc} = "get $level_unit release id succ";
                $this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
        }
	return \%return_data;
}


sub get_all_release_data
{
	my ($this) = @_;
	my $level_name;
	my $idc_name;
	my $level_conf_obj = $this->{conf}->{level_control_conf};
	my @need_to_download_id = ();
	my $return_detail;
	my %logstr;

	#��ȡ��Щrelease_id��������Ҫ��������
	foreach $level_name (keys(%{$level_conf_obj->{level_control}})) {
		foreach $idc_name (keys(%{$level_conf_obj->{level_control}->{$level_name}->{idc}})) {
			push(@need_to_download_id,$level_conf_obj->{level_control}->{$level_name}->{idc}->{$idc_name}->{current_release_id});
		}
	}

        my %null;
        undef %null;
        @need_to_download_id = grep(!$null{$_}++, @need_to_download_id);
	my $need_to_download_num = @need_to_download_id;

	if($need_to_download_num == 0) {
		$logstr{return_value} = 1;
		$logstr{return_desc} = "get the releaseid is zero";
                $this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
		return \%logstr;

	}
	$return_detail = $this->get_remote_data_by_deploy_id(\@need_to_download_id);
	if($return_detail->{return_value} != 0) {
		$return_detail->{return_desc} = "get the remote deploy conf failed";
                $this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
		return $return_detail;
	}
	#$logstr{return_desc} = "haha";
	#$logstr{return_value} = 0;
	return $return_detail;
}

sub get_remote_data_by_deploy_id
{
	my ($this, $need_to_download) = @_;
	my $remote_id;
	my $remote_svn_path;
	my $target_data_path;
	my $return_detail;
	foreach $remote_id (@{$need_to_download}) {
		$remote_svn_path = "$DATA_CONF_SVN_TOP_DIR/$remote_id/update_conf/";
		$target_data_path = "$this->{data_path}/rollback_data/$remote_id";
		$CMD = "$this->{svn} co $remote_svn_path $target_data_path | egrep \"Checked out revision\" ";
		$return_detail = $this->run_cmd("$CMD", 1);
		if($return_detail->{return_value} != 0) {
			$return_detail->{run_cmd} = "$CMD";
                	$this->{logit}->printLog($this->{logit}->{FATAL}, $return_detail);
                	$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
			return $return_detail;
		} else {
			$return_detail->{return_desc} = "get $remote_id remote data succ for:$return_detail->{return_desc}";
                	$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
		}
	}
	return $return_detail;
}


#׼���ع�ʱ��Ҫ�������ļ�
sub create_rollback_conf_data
{
	my ($this) = @_;
	#my $this->{rollback_data_conf} = $this->{}
	my $level_name;
	my $idc_name;
	my $level_control_obj = $this->{conf}->{level_control_conf};
	my $level_unit;
	my $release_id;
	my $return_detail;

	#��ÿ��idc��Ҫ��delivery.conf ���������ʵ�λ��
	foreach $level_name (keys(%{$level_control_obj->{level_control}})) {
		foreach $idc_name (keys(%{$level_control_obj->{level_control}->{$level_name}->{idc}})) {
			$level_unit = "$level_name.idc.$idc_name";
			$release_id = "$level_control_obj->{level_control}->{$level_name}->{idc}->{$idc_name}->{current_release_id}";
			$source_file = "$this->{data_path}/rollback_data/$release_id/delivery.conf";
			$target_file = "$this->{rollback_data_conf_path}/$level_unit/delivery.conf";
			$return_detail = $this->copy_file_api($source_file, $target_file);
			if($return_detail->{return_value} != 0) {
				$return_detail->{return_desc} = "copy $level_unit delivery.conf failed";
                		$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
				return $return_detail;
			} else {
				$return_detail->{return_desc} = "generatge $level_unit delivery.conf succ";
                		$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
			}
			#$level_control_obj->{level_control}->{$level_name}->{idc}->{$idc_name}->{conf_path} = "$this->{rollback_data_conf_path}/$level_unit/";
			$level_control_obj->{level_control}->{$level_name}->{idc}->{$idc_name}->{conf_path} = "$this->{data_path_rollback}/$level_unit/"
		}
	}

	#׼���ûع���Ҫ��level.conf
	my $json_pretty_str;
	$json_pretty_str = $this->{json_obj}->pretty->encode($level_control_obj);
	$this->{param}->{level_control_final} = "$this->{rollback_data_conf_path}/public/level.conf";
	$return_detail = $this->write_string_to_file("$json_pretty_str",$this->{param}->{level_control_final});
	if($return_detail->{return_value} != 0) {
		$this->{logit}->printLog($this->{logit}->{FATAL}, $return_detail);
		$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
		return $return_detail;
	} else {
		$return_detail->{return_desc} = "generate level.conf succ";
		$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
	}


	#���ɼ�¼�ļ����������λع���ʱ���small_flow�Ŀ���
	my $small_flow_string = "small_flow : $this->{param}->{small_flow}";
	my $small_cmd_file = "$this->{rollback_data_conf_path}/public/small_flow.cmd";
	$return_detail = $this->write_string_to_file("$small_flow_string", $small_cmd_file);
	if($return_detail->{return_value} != 0) {
		$this->{logit}->printLog($this->{logit}->{FATAL}, $return_detail);
		$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
		return $return_detail;
	} else {
		$return_detail->{return_desc} = "generate small_flow.cmd file succ";
		$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
	}

	#������������ʱָ����cm.conf/alarm.conf��Ϊ�ع�ʱ�Ļ�׼�ļ�
	my %public_file = (
		"$this->{data_path}/update_conf/alarm.conf" => "$this->{rollback_data_conf_path}/public/alarm.conf",
		"$this->{data_path}/update_conf/cm.conf" => "$this->{rollback_data_conf_path}/public/cm.conf",
	);
	my $base_file_name;
	foreach $source_file(keys(%public_file)) {
		$target_file = $public_file{$source_file};
		$return_detail = $this->copy_file_api($source_file, $target_file);
		
		$base_file_name = basename($source_file);
		if($return_detail->{return_value} != 0) {
			$return_detail->{return_desc} = "generate  public $base_file_name failed";
                	$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
			return $return_detail;
		} else {

			$return_detail->{return_desc} = "generate public $base_file_name succ";
                	$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
		}
	}

	#���ع���Ҫ�������ļ��ϴ���svn
	my $source_path = "$this->{rollback_data_conf_path}";
	my $target_path = "$DATA_CONF_SVN_TOP_DIR/$this->{deploy_id}/rollback_conf";
	$return_detail	= $this->put_data_path_to_svn($source_path, $target_path);
	if($return_detail->{return_value} != 0) {
		$return_detail->{return_desc} = "put the rollback conf to svn failed for: $return_detail->{return_desc}"; 
                $this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
		return $return_detail;
	} else {
		$return_detail->{return_desc} = "put the rollback conf to svn succ"; 
                $this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
	}
	return $return_detail;
}



sub copy_delivery_conf()
{
	my ($this) = @_;
	my $CMD;
	my $return_detail;

	$this->{delivery_conf_file} = "$this->{data_path}/delivery_conf";
	$CMD = "cp $this->{param}->{delivery_conf} $this->{delivery_conf_file}";
	$return_detail = $this->run_cmd($CMD, 1);
	if($return_detail->{return_value} != 0) {
		$return_detail->{desc} = "exec $CMD failed";
		$this->{logit}->printLog($this->{logit}->{FATAL}, $return_detail);
	} else {
		$return_detail->{desc} = "copy the delivery conf succ";
		$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
	}
	return $return_detail;
}


sub do_start_deploy()
{
	my ($this) = @_;
	my $return_detail;
	my %logstr;

	#׼������,���������ļ�
	$return_detail = $this->prepare_do_deploy();
	if($return_detail->{return_value} != 0) {
		$return_detail->{return_desc} = "prepare deploy failed";
		return $return_detail;
	}

	#��������
	my $deploy_id = $this->{deploy_id};
	my $deploy_method = "$this->{conf}->{cm_conf}->{basic_info}->{deploy_method}";

	if("$deploy_method" eq "archer") {
		$bm_path = "$BM_TOOLS{archer_bm}";
		$CMD = "$bm_path --action deploy --module $this->{param}->{module_name} --cm_conf $this->{param}->{cm_conf} --alarm_conf $this->{param}->{alarm_conf} --level_conf $this->{param}->{level_control_final} --deploy_id $this->{deploy_id} --small_flow $this->{param}->{small_flow}";
		$return_detail = $this->run_cmd("$CMD", 1);
		$logstr{exec_cmd} = "$CMD";
		$logstr{return_desc} = "start deploy";
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
	} elsif ("$deploy_method" eq "dop") {
		$bm_path = "$BM_TOOLS{dop_bm}";
		$CMD = "$bm_path --action $this->{param}->{action} --deploy_id $this->{deploy_id}";
		#$result = $this->run_cmd("$CMD", $MAX_RETRY_TIME);
	} else {
		$logstr{return_desc} = "start deploy failed for:unknow deploy method $deploy_method,please check the cm.conf";
		$logstr{deploy_id} = $this->{deploy_id};
		$logstr{return_value} = 1;
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
		return \%logstr;
	}
	if($return_detail->{return_value} != 0) {
		$return_detail->{return_desc} = "start deploy failed for:$return_detail->{return_desc}";
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
		return $return_detail;
	}
	$return_detail->{dis_url} = "$PRE_URL_FOR_DIS$this->{deploy_id}";
	$return_detail->{deploy_id} = $this->{deploy_id};
	$return_detail->{return_desc} = "start deploy succ";
	$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
	return $return_detail;
}
sub get_data_from_svn
{
	my ($this, $source_path, $target_path) = @_;
	#my ($this, $data_relative_path) = @_;
	#my $source_path = "$this->{data_top_path}/$data_relative_path";
	#my $target_path = "$DATA_CONF_SVN_TOP_DIR/$data_relative_path";

	#��import֮ǰ�ȳ���ɾ��һ��Զ�̵�Ŀ¼,��ʱ���Է���ֵ
	my $CMD;
	$CMD = "$this->{svn} co $source_path $target_path  &>/dev/null";
	$return_detail = $this->run_cmd("$CMD", 1);
	if($return_detail->{return_value} != 0) {
		$return_detail->{return_desc} = "exec $CMD failed for:$return_detail->{return_desc}";
		$this->{logit}->printLog($this->{logit}->{FATAL}, $return_detail);
		$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
	} else {
		$return_detail->{return_desc} = "exec $CMD succ for: $return_detail->{return_desc}";
		$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
	}
	return $return_detail;
}

sub prepare_do_deploy
{
	my ($this) = @_;
	my $return_detail;

	$this->{deploy_id} = $this->{param}->{deploy_id};
	$this->{data_path} = "$this->{data_top_path}/deploy/$this->{deploy_id}";

	my $source_path = "$DATA_CONF_SVN_TOP_DIR/$this->{deploy_id}";
	my $target_path = "$this->{data_path}";

	$return_detail = $this->get_data_from_svn($source_path, $target_path);
	if($return_detail->{return_value} != 0) {
		$return_detail->{return_desc} = "get the deploy conf failed";
                $this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
		return $return_detail;
	}



	$this->{param}->{level_control_final} = "$this->{data_path}/update_conf/level.conf";
	$this->{param}->{alarm_conf} = "$this->{data_path}/update_conf/alarm.conf";
	$this->{param}->{delivery_conf} = "$this->{data_path}/update_conf/delivery.conf";
	$this->{param}->{cm_conf} = "$this->{data_path}/update_conf/cm.conf";

	my %conf_desc = (
                "conf_type" => "json",
                "conf_key" => "cm_conf",
        );
        my $cm_conf = "$this->{param}->{cm_conf}";

        #����ԭʼ��cm.conf �� $this->{conf}->{cm_conf}
        $return_detail = $this->load_conf_detail($cm_conf, \%conf_desc);
        if($return_detail->{return_value} != 0) {
                $return_detail->{return_desc} = "load the cm_conf failed";
                $this->{logit}->printLog($this->{logit}->{FATAL}, $return_detail);
                $this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
                return $return_detail;
        }
	return $return_detail;

}

sub do_start_rollback
{
	my ($this) = @_;
	my $return_detail;
	my %logstr;

	#׼������,���������ļ�
	$return_detail = $this->prepare_do_rollback();
	if($return_detail->{return_value} != 0) {
		$return_detail->{return_desc} = "prepare rollback failed";
		$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
		return $return_detail;
	}

	#��������
	my $deploy_id = $this->{deploy_id};
	my $deploy_method = "$this->{conf}->{cm_conf}->{basic_info}->{deploy_method}";

	my %conf_desc = (
		"conf_type" => "key_value",
		"conf_key" => "small_flow_flag",
		"split_item" => ":",
	);
	my $small_flow_cmd_file = "$this->{data_path}/rollback_conf/public/small_flow.cmd";
	#����ԭʼ��rollback.cmd ���ж�ȡ����small_flow�Ķ���
	$return_detail = $this->load_conf_detail($small_flow_cmd_file, \%conf_desc);
	if($return_detail->{return_value} != 0) {
		$return_detail->{return_desc} = "generate the small_flow file failed";
		$this->{logit}->printLog($this->{logit}->{FATAL}, $return_detail);
		$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
		return $return_detail;
	}
	my $small_flow;
	if(!defined($this->{conf}->{small_flow_flag}->{small_flow}) || 
		($this->{conf}->{small_flow_flag}->{small_flow} != 0 && 
		$this->{conf}->{small_flow_flag}->{small_flow} != 1)) {
		$small_flow = $this->{conf}->{small_flow_flag}->{small_flow};
		$logstr{return_desc} = "the small_flow defined is $small_flow ,need 0/1.start rollback failed.";
		$logstr{return_value} = 1;
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
		return \%logstr;
	} else  {
		$small_flow = $this->{conf}->{small_flow_flag}->{small_flow};
	}

	if("$deploy_method" eq "archer") {
		$bm_path = "$BM_TOOLS{archer_bm}";
		$CMD = "$bm_path --action rollback --module $this->{param}->{module_name} --cm_conf $this->{param}->{cm_conf} --alarm_conf $this->{param}->{alarm_conf}  --level_conf $this->{param}->{level_control_final} --deploy_id $this->{deploy_id} --last_deploy_id $this->{last_deploy_id} --small_flow $small_flow";
		$return_detail = $this->run_cmd("$CMD", 1);
		$logstr{exec_cmd} = "$CMD";
		$logstr{return_desc} = "start rollback";
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
	} elsif ("$deploy_method" eq "dop") {
		$bm_path = "$BM_TOOLS{dop_bm}";
		$CMD = "$bm_path --action rollback --deploy_id $this->{deploy_id}";
		#$result = $this->run_cmd("$CMD", $MAX_RETRY_TIME);
	} else {
		$logstr{return_desc} = "start rollback failed for:unknow deploy method $deploy_method,please check the cm.conf";
		$logstr{deploy_id} = $this->{deploy_id};
		$logstr{return_value} = 1;
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
		return \%logstr;
	}

	if($return_detail->{return_value} != 0) {
		$return_detail->{return_desc} = "start rollback failed for:$return_detail->{return_desc}";
		$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);
		return $return_detail;
	}
	$return_detail->{dis_url} = "$PRE_URL_FOR_DIS$this->{deploy_id}";
	$return_detail->{deploy_id} = $this->{deploy_id};
	$return_detail->{return_desc} = "start rollback succ";
	$this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
	return $return_detail;

}

sub prepare_do_rollback
{
	my ($this) = @_;
	my $deploy_id = `date +%s`;
	my $return_detail;

	chomp($deploy_id);
	$this->{deploy_id} = $deploy_id;
	$this->{last_deploy_id} = $this->{param}->{last_deploy_id};	
	$this->{data_path} = "$this->{data_top_path}/deploy/$this->{last_deploy_id}";

	my $source_path = "$DATA_CONF_SVN_TOP_DIR/$this->{last_deploy_id}";
	my $target_path = "$this->{data_path}";
	$return_detail = $this->get_data_from_svn($source_path, $target_path);
	if($return_detail->{return_value} != 0) {
		$return_detail->{return_desc} = "get the rollback conf failed";
                $this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
		return $return_detail;
	}


	$this->{param}->{level_control_final} = "$this->{data_path}/rollback_conf/public/level.conf";
	$this->{param}->{alarm_conf} = "$this->{data_path}/rollback_conf/public/alarm.conf";
	$this->{param}->{cm_conf} = "$this->{data_path}/rollback_conf/public/cm.conf";

	my %conf_desc = (
                "conf_type" => "json",
                "conf_key" => "cm_conf",
        );
        my $cm_conf = "$this->{param}->{cm_conf}";

        #����ԭʼ��cm.conf �� $this->{conf}->{cm_conf}
        $return_detail = $this->load_conf_detail($cm_conf, \%conf_desc);
        if($return_detail->{return_value} != 0) {
                $return_detail->{return_desc} = "load the cm_conf failed";
                $this->{logit}->printLog($this->{logit}->{FATAL}, $return_detail);
                $this->{logit}->printLog($this->{logit}->{NOTICE}, $return_detail);
                return $return_detail;
        }
	return $return_detail;

}



sub start_deploy()
{
	my ($this) = @_;
	my $deploy_method = "$this->{conf}->{cm_conf}->{basic_info}->{deploy_method}";
	my $bm_path;
	my %logstr;
	my $result;
	my $deploy_id = $this->{deploy_id};

	if("$deploy_method" eq "archer") {
		$bm_path = "$BM_TOOLS{archer_bm}";
		$CMD = "$bm_path --action $this->{param}->{action} --delivery_conf $this->{delivery_conf_file} --cm_conf $this->{cm_conf_file} --deploy_id $deploy_id";
		$result = $this->run_cmd("$CMD", 1);

	} elsif ("$deploy_method" eq "dop") {
		$bm_path = "$BM_TOOLS{dop_bm}";
		$CMD = "$bm_path --action $this->{param}->{action} --deploy_id $this->{deploy_id}";
		$result = $this->run_cmd("$CMD", $MAX_RETRY_TIME);
	} else {
		print "error";
	}


	if($DEBUG == 1) {
		print "#exec cmd result:\n";
		print Dumper($result);
	}
	$logstr{cmd} = "$CMD";
	$logstr{return_value} = $result->{return_value};
	$logstr{desc} = "exec the start_deploy done";
	$this->{logit}->printLog($this->{logit}->{NOTICE}, \%logstr);

	if($result->{return_value} == 0) {
		$this->{logit}->printLog($this->{logit}->{NOTICE}, $result);
	} else {
		$this->{logit}->printLog($this->{logit}->{FATAL}, $result);
	}
	$result->{deploy_id} = $this->{deploy_id};
	$result->{dis_url} = "$PRE_URL_FOR_DIS"."$result->{deploy_id}";
	return $result;
}



sub start_intervene()
{
	my($this) = @_;
	my $deploy_method = $this->{conf}->{cm_conf}->{basic_info}->{deploy_method};
	my $bm_path;
	my %logstr;
	my $result;

	if("$deploy_method" eq "archer") {
		$bm_path = $BM_TOOLS{archer_bm};
		$CMD = "$bm_path --action $this->{param}->{action} --deploy_id $this->{param}->{deploy_id}";
		$this->run_cmd("$CMD", $MAX_RETRY_TIME);

	} elsif ("$deploy_method" eq "dop") {
		$bm_path = "$BM_TOOLS{dop_bm}";
		$CMD = "$bm_path --action $this->{param}->{action} --deploy_id $this->{param}->{deploy_id}";
		$this->run_cmd("$CMD", $MAX_RETRY_TIME);
	} else {
		print "error";
	}

	
	$logstr{return_desc} = "exec intervene succ";
	$logstr{return_value} = "0";
	return \%logstr;
}














1;
