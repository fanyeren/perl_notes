#!/bin/bash

BM="./auto_deploy_bm "

ROAD_MAP="/home/work/auto-deploy/public/road_map/bin/road_map "
